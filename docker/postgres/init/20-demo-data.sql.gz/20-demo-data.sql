--
-- PostgreSQL database dump
--

\restrict datafabric_seed_snapshot

-- Dumped from database version 18.1 (Debian 18.1-1.pgdg13+2)
-- Dumped by pg_dump version 18.1 (Debian 18.1-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: core; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA core;


--
-- Name: datasets; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA datasets;


--
-- Name: delta_sharing; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA delta_sharing;


--
-- Name: equivalence; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA equivalence;


--
-- Name: metadata; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA metadata;


--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- Name: workflow; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA workflow;


--
-- Name: bronzeexecutionstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.bronzeexecutionstatus AS ENUM (
    'PENDING',
    'RUNNING',
    'SUCCESS',
    'PARTIAL',
    'FAILED'
);


--
-- Name: contenttype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.contenttype AS ENUM (
    'metadata',
    'image'
);


--
-- Name: datasetaccesslevel; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.datasetaccesslevel AS ENUM (
    'LER',
    'EDITAR',
    'ADMINISTRAR'
);


--
-- Name: ingestionstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.ingestionstatus AS ENUM (
    'PENDING',
    'RUNNING',
    'SUCCESS',
    'PARTIAL',
    'FAILED'
);


--
-- Name: joinstrategy; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.joinstrategy AS ENUM (
    'INNER',
    'LEFT',
    'RIGHT',
    'FULL'
);


--
-- Name: jointype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.jointype AS ENUM (
    'INNER',
    'LEFT',
    'RIGHT',
    'FULL'
);


--
-- Name: relationshipcardinality; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.relationshipcardinality AS ENUM (
    'ONE_TO_ONE',
    'ONE_TO_MANY',
    'MANY_TO_ONE',
    'MANY_TO_MANY'
);


--
-- Name: relationshipscope; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.relationshipscope AS ENUM (
    'INTRA_CONNECTION',
    'INTER_CONNECTION'
);


--
-- Name: relationshipsource; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.relationshipsource AS ENUM (
    'AUTO_FK',
    'AUTO_NAME',
    'AUTO_DATA',
    'MANUAL',
    'SUGGESTED'
);


--
-- Name: relationshiptype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.relationshiptype AS ENUM (
    'INTRA_DB',
    'INTER_DB'
);


--
-- Name: sharestatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sharestatus AS ENUM (
    'ACTIVE',
    'INACTIVE',
    'PENDING'
);


--
-- Name: sharetablesourcetype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.sharetablesourcetype AS ENUM (
    'DELTA',
    'BRONZE',
    'SILVER',
    'BRONZE_VIRTUALIZED',
    'SILVER_VIRTUALIZED'
);


--
-- Name: silverwritemode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.silverwritemode AS ENUM (
    'OVERWRITE',
    'APPEND',
    'MERGE'
);


--
-- Name: tablesharestatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.tablesharestatus AS ENUM (
    'ACTIVE',
    'INACTIVE'
);


--
-- Name: transformstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.transformstatus AS ENUM (
    'PENDING',
    'RUNNING',
    'SUCCESS',
    'FAILED'
);


--
-- Name: writemode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.writemode AS ENUM (
    'OVERWRITE',
    'APPEND',
    'MERGE'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: connection_types; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.connection_types (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description character varying,
    icon character varying,
    color_hex character varying(7),
    connection_params_schema json NOT NULL,
    metadata_extraction_method character varying NOT NULL
);


--
-- Name: connection_types_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

CREATE SEQUENCE core.connection_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: connection_types_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: -
--

ALTER SEQUENCE core.connection_types_id_seq OWNED BY core.connection_types.id;


--
-- Name: data_connections; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.data_connections (
    id integer NOT NULL,
    organization_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying,
    connection_type_id integer NOT NULL,
    connection_params json NOT NULL,
    content_type public.contenttype NOT NULL,
    status character varying NOT NULL,
    sync_status character varying NOT NULL,
    sync_progress integer NOT NULL,
    sync_progress_details json,
    last_sync_time timestamp with time zone,
    next_sync_time timestamp with time zone,
    cron_expression character varying,
    sync_settings json NOT NULL
);


--
-- Name: data_connections_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

CREATE SEQUENCE core.data_connections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: data_connections_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: -
--

ALTER SEQUENCE core.data_connections_id_seq OWNED BY core.data_connections.id;


--
-- Name: dataset_column_sources; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.dataset_column_sources (
    id integer NOT NULL,
    dataset_column_id integer NOT NULL,
    source_column_id integer,
    transformation_type character varying(50),
    transformation_expression character varying,
    is_primary_source boolean
);


--
-- Name: dataset_column_sources_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

CREATE SEQUENCE core.dataset_column_sources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dataset_column_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: -
--

ALTER SEQUENCE core.dataset_column_sources_id_seq OWNED BY core.dataset_column_sources.id;


--
-- Name: dataset_columns; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.dataset_columns (
    id integer NOT NULL,
    dataset_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying,
    data_type character varying(50) NOT NULL,
    is_nullable boolean NOT NULL,
    column_position integer NOT NULL,
    transformation_expression character varying,
    is_visible boolean NOT NULL,
    format_pattern character varying(100),
    properties json
);


--
-- Name: dataset_columns_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

CREATE SEQUENCE core.dataset_columns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dataset_columns_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: -
--

ALTER SEQUENCE core.dataset_columns_id_seq OWNED BY core.dataset_columns.id;


--
-- Name: dataset_sources; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.dataset_sources (
    id integer NOT NULL,
    dataset_id integer NOT NULL,
    table_id integer NOT NULL,
    join_type character varying(50),
    join_condition character varying,
    filter_condition character varying
);


--
-- Name: dataset_sources_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

CREATE SEQUENCE core.dataset_sources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dataset_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: -
--

ALTER SEQUENCE core.dataset_sources_id_seq OWNED BY core.dataset_sources.id;


--
-- Name: dataset_versions; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.dataset_versions (
    id integer NOT NULL,
    dataset_id integer NOT NULL,
    version_number character varying(50) NOT NULL,
    version_note character varying,
    is_current boolean NOT NULL,
    previous_version_id integer,
    job_id integer,
    row_count integer,
    schema_hash character varying(64)
);


--
-- Name: dataset_versions_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

CREATE SEQUENCE core.dataset_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dataset_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: -
--

ALTER SEQUENCE core.dataset_versions_id_seq OWNED BY core.dataset_versions.id;


--
-- Name: datasets; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.datasets (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying,
    storage_type character varying(50) NOT NULL,
    refresh_type character varying(50) NOT NULL,
    refresh_schedule character varying(100),
    status character varying(50) NOT NULL,
    version character varying(50),
    properties json,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: datasets_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

CREATE SEQUENCE core.datasets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: datasets_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: -
--

ALTER SEQUENCE core.datasets_id_seq OWNED BY core.datasets.id;


--
-- Name: group_dataset_permissions; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.group_dataset_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    dataset_id integer NOT NULL,
    access_level public.datasetaccesslevel NOT NULL
);


--
-- Name: group_dataset_permissions_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

CREATE SEQUENCE core.group_dataset_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: group_dataset_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: -
--

ALTER SEQUENCE core.group_dataset_permissions_id_seq OWNED BY core.group_dataset_permissions.id;


--
-- Name: groups; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.groups (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    organization_id integer NOT NULL,
    description character varying
);


--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

CREATE SEQUENCE core.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: -
--

ALTER SEQUENCE core.groups_id_seq OWNED BY core.groups.id;


--
-- Name: organizacoes; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.organizacoes (
    id integer NOT NULL,
    nome character varying NOT NULL
);


--
-- Name: organizacoes_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

CREATE SEQUENCE core.organizacoes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: organizacoes_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: -
--

ALTER SEQUENCE core.organizacoes_id_seq OWNED BY core.organizacoes.id;


--
-- Name: roles; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    nivel_acesso integer NOT NULL
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

CREATE SEQUENCE core.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: -
--

ALTER SEQUENCE core.roles_id_seq OWNED BY core.roles.id;


--
-- Name: user_dataset_permissions; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.user_dataset_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    dataset_id integer NOT NULL,
    access_level public.datasetaccesslevel NOT NULL
);


--
-- Name: user_dataset_permissions_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

CREATE SEQUENCE core.user_dataset_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_dataset_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: -
--

ALTER SEQUENCE core.user_dataset_permissions_id_seq OWNED BY core.user_dataset_permissions.id;


--
-- Name: user_groups; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.user_groups (
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.user_roles (
    user_id integer,
    role_id integer
);


--
-- Name: users; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.users (
    id integer NOT NULL,
    organization_id integer NOT NULL,
    nome_usuario character varying(50),
    email character varying(100) NOT NULL,
    cpf character varying(11) NOT NULL,
    senha_hash character varying(255),
    password_reset_token character varying(255),
    password_reset_token_used boolean,
    email_invite_token character varying(255),
    email_invite_token_used boolean,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: core; Owner: -
--

CREATE SEQUENCE core.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: core; Owner: -
--

ALTER SEQUENCE core.users_id_seq OWNED BY core.users.id;


--
-- Name: bronze_column_mappings; Type: TABLE; Schema: datasets; Owner: -
--

CREATE TABLE datasets.bronze_column_mappings (
    id integer NOT NULL,
    ingestion_group_id integer NOT NULL,
    external_column_id integer NOT NULL,
    external_table_id integer NOT NULL,
    original_column_name character varying(255) NOT NULL,
    original_table_name character varying(255) NOT NULL,
    original_schema_name character varying(255),
    bronze_column_name character varying(255) NOT NULL,
    data_type character varying(100),
    column_position integer,
    is_prefixed boolean
);


--
-- Name: bronze_column_mappings_id_seq; Type: SEQUENCE; Schema: datasets; Owner: -
--

CREATE SEQUENCE datasets.bronze_column_mappings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bronze_column_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: datasets; Owner: -
--

ALTER SEQUENCE datasets.bronze_column_mappings_id_seq OWNED BY datasets.bronze_column_mappings.id;


--
-- Name: bronze_executions; Type: TABLE; Schema: datasets; Owner: -
--

CREATE TABLE datasets.bronze_executions (
    id integer NOT NULL,
    config_id integer NOT NULL,
    status public.bronzeexecutionstatus NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    group_results json,
    rows_ingested integer,
    output_paths json,
    error_message text,
    execution_details json,
    version_number integer,
    path_delta_versions json,
    delta_version integer,
    write_mode_used character varying(20),
    merge_keys_used json,
    rows_inserted integer,
    rows_updated integer,
    rows_deleted integer,
    schema_hash character varying(64),
    schema_changed boolean,
    config_snapshot json,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: bronze_executions_id_seq; Type: SEQUENCE; Schema: datasets; Owner: -
--

CREATE SEQUENCE datasets.bronze_executions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bronze_executions_id_seq; Type: SEQUENCE OWNED BY; Schema: datasets; Owner: -
--

ALTER SEQUENCE datasets.bronze_executions_id_seq OWNED BY datasets.bronze_executions.id;


--
-- Name: bronze_persistent_configs; Type: TABLE; Schema: datasets; Owner: -
--

CREATE TABLE datasets.bronze_persistent_configs (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    tables json NOT NULL,
    relationship_ids json,
    enable_federated_joins boolean,
    output_format character varying(50) NOT NULL,
    output_bucket character varying(255),
    output_path_prefix character varying(500),
    partition_columns json,
    write_mode public.writemode NOT NULL,
    merge_keys json,
    merge_keys_source character varying(50),
    properties json,
    config_snapshot json,
    last_execution_time timestamp with time zone,
    last_execution_status public.bronzeexecutionstatus,
    last_execution_rows integer,
    last_execution_error text,
    current_delta_version integer,
    known_output_paths json,
    is_active boolean,
    dataset_id integer,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: bronze_persistent_configs_id_seq; Type: SEQUENCE; Schema: datasets; Owner: -
--

CREATE SEQUENCE datasets.bronze_persistent_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bronze_persistent_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: datasets; Owner: -
--

ALTER SEQUENCE datasets.bronze_persistent_configs_id_seq OWNED BY datasets.bronze_persistent_configs.id;


--
-- Name: bronze_virtualized_configs; Type: TABLE; Schema: datasets; Owner: -
--

CREATE TABLE datasets.bronze_virtualized_configs (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    tables json NOT NULL,
    relationship_ids json,
    enable_federated_joins boolean,
    generated_sql text,
    is_active boolean,
    last_query_time timestamp with time zone,
    last_query_rows integer,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: bronze_virtualized_configs_id_seq; Type: SEQUENCE; Schema: datasets; Owner: -
--

CREATE SEQUENCE datasets.bronze_virtualized_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bronze_virtualized_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: datasets; Owner: -
--

ALTER SEQUENCE datasets.bronze_virtualized_configs_id_seq OWNED BY datasets.bronze_virtualized_configs.id;


--
-- Name: dataset_bronze_configs; Type: TABLE; Schema: datasets; Owner: -
--

CREATE TABLE datasets.dataset_bronze_configs (
    id integer NOT NULL,
    dataset_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    bronze_bucket character varying(255) NOT NULL,
    bronze_path_prefix character varying(500) NOT NULL,
    output_format character varying(50) NOT NULL,
    partition_columns json,
    config_snapshot json NOT NULL,
    last_ingestion_time timestamp with time zone,
    last_ingestion_status public.ingestionstatus,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: dataset_bronze_configs_id_seq; Type: SEQUENCE; Schema: datasets; Owner: -
--

CREATE SEQUENCE datasets.dataset_bronze_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dataset_bronze_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: datasets; Owner: -
--

ALTER SEQUENCE datasets.dataset_bronze_configs_id_seq OWNED BY datasets.dataset_bronze_configs.id;


--
-- Name: dataset_ingestion_groups; Type: TABLE; Schema: datasets; Owner: -
--

CREATE TABLE datasets.dataset_ingestion_groups (
    id integer NOT NULL,
    bronze_config_id integer NOT NULL,
    connection_id integer NOT NULL,
    group_name character varying(255) NOT NULL,
    group_order integer NOT NULL,
    output_path character varying(500) NOT NULL,
    generated_sql text,
    status public.ingestionstatus NOT NULL,
    last_execution_time timestamp with time zone,
    rows_ingested integer,
    error_message text,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: dataset_ingestion_groups_id_seq; Type: SEQUENCE; Schema: datasets; Owner: -
--

CREATE SEQUENCE datasets.dataset_ingestion_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dataset_ingestion_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: datasets; Owner: -
--

ALTER SEQUENCE datasets.dataset_ingestion_groups_id_seq OWNED BY datasets.dataset_ingestion_groups.id;


--
-- Name: ingestion_group_tables; Type: TABLE; Schema: datasets; Owner: -
--

CREATE TABLE datasets.ingestion_group_tables (
    id integer NOT NULL,
    ingestion_group_id integer NOT NULL,
    table_id integer NOT NULL,
    table_alias character varying(50) NOT NULL,
    select_all_columns boolean,
    selected_column_ids json,
    is_primary_table boolean,
    join_to_table_id integer,
    join_type public.joinstrategy,
    join_condition text
);


--
-- Name: ingestion_group_tables_id_seq; Type: SEQUENCE; Schema: datasets; Owner: -
--

CREATE SEQUENCE datasets.ingestion_group_tables_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ingestion_group_tables_id_seq; Type: SEQUENCE OWNED BY; Schema: datasets; Owner: -
--

ALTER SEQUENCE datasets.ingestion_group_tables_id_seq OWNED BY datasets.ingestion_group_tables.id;


--
-- Name: inter_source_links; Type: TABLE; Schema: datasets; Owner: -
--

CREATE TABLE datasets.inter_source_links (
    id integer NOT NULL,
    bronze_config_id integer NOT NULL,
    left_group_id integer NOT NULL,
    left_column_name character varying(255) NOT NULL,
    right_group_id integer NOT NULL,
    right_column_name character varying(255) NOT NULL,
    join_strategy public.joinstrategy NOT NULL,
    description text,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: inter_source_links_id_seq; Type: SEQUENCE; Schema: datasets; Owner: -
--

CREATE SEQUENCE datasets.inter_source_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inter_source_links_id_seq; Type: SEQUENCE OWNED BY; Schema: datasets; Owner: -
--

ALTER SEQUENCE datasets.inter_source_links_id_seq OWNED BY datasets.inter_source_links.id;


--
-- Name: silver_executions; Type: TABLE; Schema: datasets; Owner: -
--

CREATE TABLE datasets.silver_executions (
    id integer NOT NULL,
    config_id integer NOT NULL,
    status public.transformstatus NOT NULL,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    rows_processed integer,
    rows_output integer,
    output_path character varying(500),
    error_message text,
    execution_details json,
    delta_version integer,
    write_mode_used character varying(20),
    merge_keys_used json,
    rows_inserted integer,
    rows_updated integer,
    rows_deleted integer,
    schema_hash character varying(64),
    schema_changed boolean,
    config_snapshot json,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: silver_executions_id_seq; Type: SEQUENCE; Schema: datasets; Owner: -
--

CREATE SEQUENCE datasets.silver_executions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: silver_executions_id_seq; Type: SEQUENCE OWNED BY; Schema: datasets; Owner: -
--

ALTER SEQUENCE datasets.silver_executions_id_seq OWNED BY datasets.silver_executions.id;


--
-- Name: silver_normalization_rules; Type: TABLE; Schema: datasets; Owner: -
--

CREATE TABLE datasets.silver_normalization_rules (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    template character varying(500),
    regex_pattern text,
    regex_replacement text,
    pre_process character varying(100),
    regex_entrada text,
    template_saida text,
    case_transforms json,
    is_builtin boolean,
    is_active boolean,
    example_input character varying(255),
    example_output character varying(255),
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: silver_normalization_rules_id_seq; Type: SEQUENCE; Schema: datasets; Owner: -
--

CREATE SEQUENCE datasets.silver_normalization_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: silver_normalization_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: datasets; Owner: -
--

ALTER SEQUENCE datasets.silver_normalization_rules_id_seq OWNED BY datasets.silver_normalization_rules.id;


--
-- Name: silver_persistent_configs; Type: TABLE; Schema: datasets; Owner: -
--

CREATE TABLE datasets.silver_persistent_configs (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    source_bronze_config_id integer,
    source_bronze_version integer,
    source_bronze_dataset_id integer,
    silver_bucket character varying(255),
    silver_path_prefix character varying(500),
    column_group_ids json,
    filters json,
    column_transformations json,
    image_labeling_config json,
    llm_extractions json,
    exclude_unified_source_columns boolean CONSTRAINT silver_persistent_configs_exclude_unified_source_colum_not_null NOT NULL,
    write_mode public.silverwritemode NOT NULL,
    merge_keys json,
    merge_keys_source character varying(50),
    current_delta_version integer,
    last_execution_time timestamp with time zone,
    last_execution_status public.transformstatus,
    last_execution_rows integer,
    last_execution_error text,
    is_active boolean,
    config_snapshot json,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: silver_persistent_configs_id_seq; Type: SEQUENCE; Schema: datasets; Owner: -
--

CREATE SEQUENCE datasets.silver_persistent_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: silver_persistent_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: datasets; Owner: -
--

ALTER SEQUENCE datasets.silver_persistent_configs_id_seq OWNED BY datasets.silver_persistent_configs.id;


--
-- Name: silver_virtualized_configs; Type: TABLE; Schema: datasets; Owner: -
--

CREATE TABLE datasets.silver_virtualized_configs (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    tables json NOT NULL,
    column_group_ids json,
    relationship_ids json,
    filters json,
    column_transformations json,
    exclude_unified_source_columns boolean CONSTRAINT silver_virtualized_configs_exclude_unified_source_colu_not_null NOT NULL,
    is_active boolean,
    generated_sql text,
    sql_generated_at timestamp with time zone,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: silver_virtualized_configs_id_seq; Type: SEQUENCE; Schema: datasets; Owner: -
--

CREATE SEQUENCE datasets.silver_virtualized_configs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: silver_virtualized_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: datasets; Owner: -
--

ALTER SEQUENCE datasets.silver_virtualized_configs_id_seq OWNED BY datasets.silver_virtualized_configs.id;


--
-- Name: source_relationships; Type: TABLE; Schema: datasets; Owner: -
--

CREATE TABLE datasets.source_relationships (
    id integer NOT NULL,
    left_table_id integer NOT NULL,
    left_column_id integer NOT NULL,
    right_table_id integer NOT NULL,
    right_column_id integer NOT NULL,
    relationship_type public.relationshiptype NOT NULL,
    join_strategy public.joinstrategy NOT NULL,
    custom_condition text,
    is_verified boolean,
    notes text,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: source_relationships_id_seq; Type: SEQUENCE; Schema: datasets; Owner: -
--

CREATE SEQUENCE datasets.source_relationships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: source_relationships_id_seq; Type: SEQUENCE OWNED BY; Schema: datasets; Owner: -
--

ALTER SEQUENCE datasets.source_relationships_id_seq OWNED BY datasets.source_relationships.id;


--
-- Name: recipient_access_logs; Type: TABLE; Schema: delta_sharing; Owner: -
--

CREATE TABLE delta_sharing.recipient_access_logs (
    id integer NOT NULL,
    recipient_id integer NOT NULL,
    share_id integer,
    schema_id integer,
    table_id integer,
    operation character varying(100) NOT NULL,
    request_method character varying(10) NOT NULL,
    request_path character varying(500) NOT NULL,
    request_query_params json,
    request_body text,
    response_status_code integer NOT NULL,
    response_size_bytes integer,
    processing_time_ms integer,
    client_ip character varying(45),
    user_agent character varying(500),
    accessed_at timestamp with time zone NOT NULL,
    error_message text
);


--
-- Name: recipient_access_logs_id_seq; Type: SEQUENCE; Schema: delta_sharing; Owner: -
--

CREATE SEQUENCE delta_sharing.recipient_access_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recipient_access_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: delta_sharing; Owner: -
--

ALTER SEQUENCE delta_sharing.recipient_access_logs_id_seq OWNED BY delta_sharing.recipient_access_logs.id;


--
-- Name: recipient_shares; Type: TABLE; Schema: delta_sharing; Owner: -
--

CREATE TABLE delta_sharing.recipient_shares (
    recipient_id integer NOT NULL,
    share_id integer NOT NULL
);


--
-- Name: recipients; Type: TABLE; Schema: delta_sharing; Owner: -
--

CREATE TABLE delta_sharing.recipients (
    id integer NOT NULL,
    identifier character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255),
    organization_name character varying(255),
    authentication_type character varying(50) NOT NULL,
    bearer_token character varying(500),
    token_expiry timestamp with time zone,
    is_active boolean NOT NULL,
    max_requests_per_hour integer,
    max_downloads_per_day integer,
    access_logged boolean NOT NULL,
    data_usage_agreement_accepted boolean NOT NULL,
    agreement_accepted_at timestamp with time zone,
    contact_info json,
    notes text,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: recipients_id_seq; Type: SEQUENCE; Schema: delta_sharing; Owner: -
--

CREATE SEQUENCE delta_sharing.recipients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recipients_id_seq; Type: SEQUENCE OWNED BY; Schema: delta_sharing; Owner: -
--

ALTER SEQUENCE delta_sharing.recipients_id_seq OWNED BY delta_sharing.recipients.id;


--
-- Name: share_schemas; Type: TABLE; Schema: delta_sharing; Owner: -
--

CREATE TABLE delta_sharing.share_schemas (
    id integer NOT NULL,
    share_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: share_schemas_id_seq; Type: SEQUENCE; Schema: delta_sharing; Owner: -
--

CREATE SEQUENCE delta_sharing.share_schemas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: share_schemas_id_seq; Type: SEQUENCE OWNED BY; Schema: delta_sharing; Owner: -
--

ALTER SEQUENCE delta_sharing.share_schemas_id_seq OWNED BY delta_sharing.share_schemas.id;


--
-- Name: share_table_files; Type: TABLE; Schema: delta_sharing; Owner: -
--

CREATE TABLE delta_sharing.share_table_files (
    id integer NOT NULL,
    table_id integer NOT NULL,
    file_path character varying(1000) NOT NULL,
    file_size_bytes integer NOT NULL,
    modification_time timestamp with time zone NOT NULL,
    data_change boolean NOT NULL,
    partition_values json,
    num_records integer,
    min_values json,
    max_values json,
    null_count json,
    created_at_version integer NOT NULL,
    removed_at_version integer,
    storage_url character varying(1000),
    content_length integer,
    etag character varying(100)
);


--
-- Name: share_table_files_id_seq; Type: SEQUENCE; Schema: delta_sharing; Owner: -
--

CREATE SEQUENCE delta_sharing.share_table_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: share_table_files_id_seq; Type: SEQUENCE OWNED BY; Schema: delta_sharing; Owner: -
--

ALTER SEQUENCE delta_sharing.share_table_files_id_seq OWNED BY delta_sharing.share_table_files.id;


--
-- Name: share_table_versions; Type: TABLE; Schema: delta_sharing; Owner: -
--

CREATE TABLE delta_sharing.share_table_versions (
    id integer NOT NULL,
    table_id integer NOT NULL,
    version integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    operation character varying(50) NOT NULL,
    description text,
    protocol_version json,
    table_metadata json,
    schema_string text,
    add_files json,
    remove_files json,
    num_files integer,
    total_size_bytes integer,
    num_records integer
);


--
-- Name: share_table_versions_id_seq; Type: SEQUENCE; Schema: delta_sharing; Owner: -
--

CREATE SEQUENCE delta_sharing.share_table_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: share_table_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: delta_sharing; Owner: -
--

ALTER SEQUENCE delta_sharing.share_table_versions_id_seq OWNED BY delta_sharing.share_table_versions.id;


--
-- Name: share_tables; Type: TABLE; Schema: delta_sharing; Owner: -
--

CREATE TABLE delta_sharing.share_tables (
    id integer NOT NULL,
    schema_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    dataset_id integer,
    source_type public.sharetablesourcetype DEFAULT 'DELTA'::public.sharetablesourcetype NOT NULL,
    bronze_persistent_config_id integer,
    silver_persistent_config_id integer,
    bronze_virtualized_config_id integer,
    silver_virtualized_config_id integer,
    status public.tablesharestatus NOT NULL,
    share_mode character varying(50) NOT NULL,
    filter_condition text,
    current_version integer NOT NULL,
    min_reader_version integer NOT NULL,
    min_writer_version integer NOT NULL,
    pinned_delta_version integer,
    table_format character varying(50) NOT NULL,
    partition_columns json,
    schema_string text,
    table_properties json,
    storage_location character varying(500),
    storage_credentials_id integer,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: share_tables_id_seq; Type: SEQUENCE; Schema: delta_sharing; Owner: -
--

CREATE SEQUENCE delta_sharing.share_tables_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: share_tables_id_seq; Type: SEQUENCE OWNED BY; Schema: delta_sharing; Owner: -
--

ALTER SEQUENCE delta_sharing.share_tables_id_seq OWNED BY delta_sharing.share_tables.id;


--
-- Name: shares; Type: TABLE; Schema: delta_sharing; Owner: -
--

CREATE TABLE delta_sharing.shares (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    organization_id integer NOT NULL,
    status public.sharestatus NOT NULL,
    owner_email character varying(255),
    contact_info json,
    terms_of_use text,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: shares_id_seq; Type: SEQUENCE; Schema: delta_sharing; Owner: -
--

CREATE SEQUENCE delta_sharing.shares_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: shares_id_seq; Type: SEQUENCE OWNED BY; Schema: delta_sharing; Owner: -
--

ALTER SEQUENCE delta_sharing.shares_id_seq OWNED BY delta_sharing.shares.id;


--
-- Name: column_groups; Type: TABLE; Schema: equivalence; Owner: -
--

CREATE TABLE equivalence.column_groups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    semantic_domain_id integer,
    data_dictionary_term_id integer,
    properties json,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: column_groups_id_seq; Type: SEQUENCE; Schema: equivalence; Owner: -
--

CREATE SEQUENCE equivalence.column_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: column_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: equivalence; Owner: -
--

ALTER SEQUENCE equivalence.column_groups_id_seq OWNED BY equivalence.column_groups.id;


--
-- Name: column_mappings; Type: TABLE; Schema: equivalence; Owner: -
--

CREATE TABLE equivalence.column_mappings (
    id integer NOT NULL,
    group_id integer NOT NULL,
    column_id integer NOT NULL,
    transformation_rule text,
    confidence_score numeric(5,4),
    notes text,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: column_mappings_id_seq; Type: SEQUENCE; Schema: equivalence; Owner: -
--

CREATE SEQUENCE equivalence.column_mappings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: column_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: equivalence; Owner: -
--

ALTER SEQUENCE equivalence.column_mappings_id_seq OWNED BY equivalence.column_mappings.id;


--
-- Name: data_dictionary; Type: TABLE; Schema: equivalence; Owner: -
--

CREATE TABLE equivalence.data_dictionary (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    display_name character varying(255) NOT NULL,
    description text NOT NULL,
    semantic_domain_id integer,
    data_type character varying(50) NOT NULL,
    standard_values character varying[],
    validation_rules json,
    example_values json,
    synonyms character varying[],
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: data_dictionary_id_seq; Type: SEQUENCE; Schema: equivalence; Owner: -
--

CREATE SEQUENCE equivalence.data_dictionary_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: data_dictionary_id_seq; Type: SEQUENCE OWNED BY; Schema: equivalence; Owner: -
--

ALTER SEQUENCE equivalence.data_dictionary_id_seq OWNED BY equivalence.data_dictionary.id;


--
-- Name: semantic_domains; Type: TABLE; Schema: equivalence; Owner: -
--

CREATE TABLE equivalence.semantic_domains (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    parent_domain_id integer,
    color character varying(7),
    domain_rules json,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: semantic_domains_id_seq; Type: SEQUENCE; Schema: equivalence; Owner: -
--

CREATE SEQUENCE equivalence.semantic_domains_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: semantic_domains_id_seq; Type: SEQUENCE OWNED BY; Schema: equivalence; Owner: -
--

ALTER SEQUENCE equivalence.semantic_domains_id_seq OWNED BY equivalence.semantic_domains.id;


--
-- Name: value_mappings; Type: TABLE; Schema: equivalence; Owner: -
--

CREATE TABLE equivalence.value_mappings (
    id integer NOT NULL,
    group_id integer NOT NULL,
    source_column_id integer NOT NULL,
    source_value text NOT NULL,
    standard_value text NOT NULL,
    description text,
    record_count integer,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: value_mappings_id_seq; Type: SEQUENCE; Schema: equivalence; Owner: -
--

CREATE SEQUENCE equivalence.value_mappings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: value_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: equivalence; Owner: -
--

ALTER SEQUENCE equivalence.value_mappings_id_seq OWNED BY equivalence.value_mappings.id;


--
-- Name: column_tags; Type: TABLE; Schema: metadata; Owner: -
--

CREATE TABLE metadata.column_tags (
    id integer NOT NULL,
    column_id integer NOT NULL,
    tag_name character varying(100) NOT NULL,
    tag_type character varying(50) NOT NULL,
    confidence numeric(5,4),
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: column_tags_id_seq; Type: SEQUENCE; Schema: metadata; Owner: -
--

CREATE SEQUENCE metadata.column_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: column_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: -
--

ALTER SEQUENCE metadata.column_tags_id_seq OWNED BY metadata.column_tags.id;


--
-- Name: external_catalogs; Type: TABLE; Schema: metadata; Owner: -
--

CREATE TABLE metadata.external_catalogs (
    id integer NOT NULL,
    connection_id integer NOT NULL,
    catalog_name character varying(255),
    catalog_type character varying(50),
    external_reference character varying(255),
    properties json NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: external_catalogs_id_seq; Type: SEQUENCE; Schema: metadata; Owner: -
--

CREATE SEQUENCE metadata.external_catalogs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: external_catalogs_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: -
--

ALTER SEQUENCE metadata.external_catalogs_id_seq OWNED BY metadata.external_catalogs.id;


--
-- Name: external_columns; Type: TABLE; Schema: metadata; Owner: -
--

CREATE TABLE metadata.external_columns (
    id integer NOT NULL,
    table_id integer NOT NULL,
    column_name character varying(255) NOT NULL,
    external_reference character varying(255),
    data_type character varying(100) NOT NULL,
    is_nullable boolean NOT NULL,
    column_position integer NOT NULL,
    max_length integer,
    numeric_precision integer,
    numeric_scale integer,
    is_primary_key boolean NOT NULL,
    is_unique boolean NOT NULL,
    is_indexed boolean NOT NULL,
    is_foreign_key boolean NOT NULL,
    fk_referenced_table_id integer,
    fk_referenced_column_id integer,
    fk_constraint_name character varying(255),
    default_value character varying,
    description character varying,
    is_image_path boolean NOT NULL,
    image_connection_id integer,
    statistics json NOT NULL,
    sample_values json NOT NULL,
    properties json NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: external_columns_id_seq; Type: SEQUENCE; Schema: metadata; Owner: -
--

CREATE SEQUENCE metadata.external_columns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: external_columns_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: -
--

ALTER SEQUENCE metadata.external_columns_id_seq OWNED BY metadata.external_columns.id;


--
-- Name: external_schemas; Type: TABLE; Schema: metadata; Owner: -
--

CREATE TABLE metadata.external_schemas (
    id integer NOT NULL,
    catalog_id integer,
    connection_id integer NOT NULL,
    schema_name character varying(255) NOT NULL,
    external_reference character varying(255),
    is_system_schema boolean NOT NULL,
    properties json NOT NULL,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: external_schemas_id_seq; Type: SEQUENCE; Schema: metadata; Owner: -
--

CREATE SEQUENCE metadata.external_schemas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: external_schemas_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: -
--

ALTER SEQUENCE metadata.external_schemas_id_seq OWNED BY metadata.external_schemas.id;


--
-- Name: external_tables; Type: TABLE; Schema: metadata; Owner: -
--

CREATE TABLE metadata.external_tables (
    id integer NOT NULL,
    schema_id integer NOT NULL,
    connection_id integer NOT NULL,
    table_name character varying(255) NOT NULL,
    external_reference character varying(255),
    table_type character varying(50) NOT NULL,
    estimated_row_count integer,
    total_size_bytes integer,
    last_analyzed timestamp with time zone,
    properties json NOT NULL,
    description character varying,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: external_tables_id_seq; Type: SEQUENCE; Schema: metadata; Owner: -
--

CREATE SEQUENCE metadata.external_tables_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: external_tables_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: -
--

ALTER SEQUENCE metadata.external_tables_id_seq OWNED BY metadata.external_tables.id;


--
-- Name: federation_connections; Type: TABLE; Schema: metadata; Owner: -
--

CREATE TABLE metadata.federation_connections (
    id integer NOT NULL,
    federation_id integer NOT NULL,
    connection_id integer NOT NULL
);


--
-- Name: federation_connections_id_seq; Type: SEQUENCE; Schema: metadata; Owner: -
--

CREATE SEQUENCE metadata.federation_connections_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: federation_connections_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: -
--

ALTER SEQUENCE metadata.federation_connections_id_seq OWNED BY metadata.federation_connections.id;


--
-- Name: federation_tables; Type: TABLE; Schema: metadata; Owner: -
--

CREATE TABLE metadata.federation_tables (
    id integer NOT NULL,
    federation_id integer NOT NULL,
    table_id integer NOT NULL
);


--
-- Name: federation_tables_id_seq; Type: SEQUENCE; Schema: metadata; Owner: -
--

CREATE SEQUENCE metadata.federation_tables_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: federation_tables_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: -
--

ALTER SEQUENCE metadata.federation_tables_id_seq OWNED BY metadata.federation_tables.id;


--
-- Name: federations; Type: TABLE; Schema: metadata; Owner: -
--

CREATE TABLE metadata.federations (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: federations_id_seq; Type: SEQUENCE; Schema: metadata; Owner: -
--

CREATE SEQUENCE metadata.federations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: federations_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: -
--

ALTER SEQUENCE metadata.federations_id_seq OWNED BY metadata.federations.id;


--
-- Name: relationship_suggestions; Type: TABLE; Schema: metadata; Owner: -
--

CREATE TABLE metadata.relationship_suggestions (
    id integer NOT NULL,
    left_table_id integer NOT NULL,
    left_column_id integer NOT NULL,
    right_table_id integer NOT NULL,
    right_column_id integer NOT NULL,
    suggestion_reason character varying(100) NOT NULL,
    confidence_score double precision NOT NULL,
    status character varying(50) NOT NULL,
    details json NOT NULL,
    generated_at timestamp with time zone DEFAULT now(),
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: relationship_suggestions_id_seq; Type: SEQUENCE; Schema: metadata; Owner: -
--

CREATE SEQUENCE metadata.relationship_suggestions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: relationship_suggestions_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: -
--

ALTER SEQUENCE metadata.relationship_suggestions_id_seq OWNED BY metadata.relationship_suggestions.id;


--
-- Name: semantic_column_links; Type: TABLE; Schema: metadata; Owner: -
--

CREATE TABLE metadata.semantic_column_links (
    id integer NOT NULL,
    column_id integer NOT NULL,
    linked_column_id integer NOT NULL,
    semantic_type character varying(100),
    source public.relationshipsource NOT NULL,
    confidence_score double precision,
    is_verified boolean,
    is_active boolean,
    notes text,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: semantic_column_links_id_seq; Type: SEQUENCE; Schema: metadata; Owner: -
--

CREATE SEQUENCE metadata.semantic_column_links_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: semantic_column_links_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: -
--

ALTER SEQUENCE metadata.semantic_column_links_id_seq OWNED BY metadata.semantic_column_links.id;


--
-- Name: table_relationships; Type: TABLE; Schema: metadata; Owner: -
--

CREATE TABLE metadata.table_relationships (
    id integer NOT NULL,
    left_table_id integer NOT NULL,
    left_column_id integer NOT NULL,
    right_table_id integer NOT NULL,
    right_column_id integer NOT NULL,
    name character varying(255),
    description text,
    scope public.relationshipscope NOT NULL,
    source public.relationshipsource NOT NULL,
    cardinality public.relationshipcardinality,
    default_join_type public.jointype NOT NULL,
    confidence_score double precision,
    is_verified boolean,
    is_active boolean,
    properties json NOT NULL,
    discovery_details json,
    data_criacao timestamp without time zone DEFAULT now() NOT NULL,
    data_atualizacao timestamp without time zone DEFAULT now() NOT NULL,
    id_usuario_criacao integer,
    id_usuario_atualizacao integer,
    fl_ativo boolean NOT NULL
);


--
-- Name: table_relationships_id_seq; Type: SEQUENCE; Schema: metadata; Owner: -
--

CREATE SEQUENCE metadata.table_relationships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: table_relationships_id_seq; Type: SEQUENCE OWNED BY; Schema: metadata; Owner: -
--

ALTER SEQUENCE metadata.table_relationships_id_seq OWNED BY metadata.table_relationships.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: dataset_storage; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.dataset_storage (
    id integer NOT NULL,
    dataset_id integer NOT NULL,
    storage_type character varying(50) NOT NULL,
    storage_location character varying(1024) NOT NULL,
    file_format character varying(50),
    compression character varying(50),
    partition_columns text[],
    storage_properties json
);


--
-- Name: dataset_storage_id_seq; Type: SEQUENCE; Schema: storage; Owner: -
--

CREATE SEQUENCE storage.dataset_storage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dataset_storage_id_seq; Type: SEQUENCE OWNED BY; Schema: storage; Owner: -
--

ALTER SEQUENCE storage.dataset_storage_id_seq OWNED BY storage.dataset_storage.id;


--
-- Name: dataset_jobs; Type: TABLE; Schema: workflow; Owner: -
--

CREATE TABLE workflow.dataset_jobs (
    id integer NOT NULL,
    dataset_id integer NOT NULL,
    job_type character varying(50) NOT NULL,
    airflow_dag_id character varying(255),
    status character varying(50) NOT NULL,
    last_run_start timestamp with time zone,
    last_run_end timestamp with time zone,
    last_run_duration_seconds integer,
    row_count integer,
    size_bytes integer,
    error_message character varying,
    job_params json
);


--
-- Name: dataset_jobs_id_seq; Type: SEQUENCE; Schema: workflow; Owner: -
--

CREATE SEQUENCE workflow.dataset_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dataset_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: workflow; Owner: -
--

ALTER SEQUENCE workflow.dataset_jobs_id_seq OWNED BY workflow.dataset_jobs.id;


--
-- Name: metadata_sync_jobs; Type: TABLE; Schema: workflow; Owner: -
--

CREATE TABLE workflow.metadata_sync_jobs (
    id integer NOT NULL,
    connection_id integer NOT NULL,
    name character varying(255) NOT NULL,
    airflow_dag_id character varying(255),
    job_type character varying NOT NULL,
    status character varying NOT NULL,
    last_run_at timestamp with time zone,
    last_run_duration_seconds integer,
    error_message character varying,
    job_params json NOT NULL,
    job_results json NOT NULL
);


--
-- Name: metadata_sync_jobs_id_seq; Type: SEQUENCE; Schema: workflow; Owner: -
--

CREATE SEQUENCE workflow.metadata_sync_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: metadata_sync_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: workflow; Owner: -
--

ALTER SEQUENCE workflow.metadata_sync_jobs_id_seq OWNED BY workflow.metadata_sync_jobs.id;


--
-- Name: sync_execution_history; Type: TABLE; Schema: workflow; Owner: -
--

CREATE TABLE workflow.sync_execution_history (
    id integer NOT NULL,
    job_id integer NOT NULL,
    connection_id integer NOT NULL,
    execution_start timestamp with time zone DEFAULT now() NOT NULL,
    execution_end timestamp with time zone,
    status character varying NOT NULL,
    catalog_count integer NOT NULL,
    schemas_count integer NOT NULL,
    table_count integer NOT NULL,
    column_count integer NOT NULL,
    new_objects_count integer NOT NULL,
    updated_objects_count integer NOT NULL,
    deleted_objects_count integer NOT NULL,
    error_log character varying,
    execution_details json NOT NULL
);


--
-- Name: sync_execution_history_id_seq; Type: SEQUENCE; Schema: workflow; Owner: -
--

CREATE SEQUENCE workflow.sync_execution_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sync_execution_history_id_seq; Type: SEQUENCE OWNED BY; Schema: workflow; Owner: -
--

ALTER SEQUENCE workflow.sync_execution_history_id_seq OWNED BY workflow.sync_execution_history.id;


--
-- Name: connection_types id; Type: DEFAULT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.connection_types ALTER COLUMN id SET DEFAULT nextval('core.connection_types_id_seq'::regclass);


--
-- Name: data_connections id; Type: DEFAULT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.data_connections ALTER COLUMN id SET DEFAULT nextval('core.data_connections_id_seq'::regclass);


--
-- Name: dataset_column_sources id; Type: DEFAULT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_column_sources ALTER COLUMN id SET DEFAULT nextval('core.dataset_column_sources_id_seq'::regclass);


--
-- Name: dataset_columns id; Type: DEFAULT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_columns ALTER COLUMN id SET DEFAULT nextval('core.dataset_columns_id_seq'::regclass);


--
-- Name: dataset_sources id; Type: DEFAULT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_sources ALTER COLUMN id SET DEFAULT nextval('core.dataset_sources_id_seq'::regclass);


--
-- Name: dataset_versions id; Type: DEFAULT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_versions ALTER COLUMN id SET DEFAULT nextval('core.dataset_versions_id_seq'::regclass);


--
-- Name: datasets id; Type: DEFAULT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.datasets ALTER COLUMN id SET DEFAULT nextval('core.datasets_id_seq'::regclass);


--
-- Name: group_dataset_permissions id; Type: DEFAULT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.group_dataset_permissions ALTER COLUMN id SET DEFAULT nextval('core.group_dataset_permissions_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.groups ALTER COLUMN id SET DEFAULT nextval('core.groups_id_seq'::regclass);


--
-- Name: organizacoes id; Type: DEFAULT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.organizacoes ALTER COLUMN id SET DEFAULT nextval('core.organizacoes_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.roles ALTER COLUMN id SET DEFAULT nextval('core.roles_id_seq'::regclass);


--
-- Name: user_dataset_permissions id; Type: DEFAULT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.user_dataset_permissions ALTER COLUMN id SET DEFAULT nextval('core.user_dataset_permissions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users ALTER COLUMN id SET DEFAULT nextval('core.users_id_seq'::regclass);


--
-- Name: bronze_column_mappings id; Type: DEFAULT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_column_mappings ALTER COLUMN id SET DEFAULT nextval('datasets.bronze_column_mappings_id_seq'::regclass);


--
-- Name: bronze_executions id; Type: DEFAULT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_executions ALTER COLUMN id SET DEFAULT nextval('datasets.bronze_executions_id_seq'::regclass);


--
-- Name: bronze_persistent_configs id; Type: DEFAULT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_persistent_configs ALTER COLUMN id SET DEFAULT nextval('datasets.bronze_persistent_configs_id_seq'::regclass);


--
-- Name: bronze_virtualized_configs id; Type: DEFAULT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_virtualized_configs ALTER COLUMN id SET DEFAULT nextval('datasets.bronze_virtualized_configs_id_seq'::regclass);


--
-- Name: dataset_bronze_configs id; Type: DEFAULT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.dataset_bronze_configs ALTER COLUMN id SET DEFAULT nextval('datasets.dataset_bronze_configs_id_seq'::regclass);


--
-- Name: dataset_ingestion_groups id; Type: DEFAULT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.dataset_ingestion_groups ALTER COLUMN id SET DEFAULT nextval('datasets.dataset_ingestion_groups_id_seq'::regclass);


--
-- Name: ingestion_group_tables id; Type: DEFAULT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.ingestion_group_tables ALTER COLUMN id SET DEFAULT nextval('datasets.ingestion_group_tables_id_seq'::regclass);


--
-- Name: inter_source_links id; Type: DEFAULT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.inter_source_links ALTER COLUMN id SET DEFAULT nextval('datasets.inter_source_links_id_seq'::regclass);


--
-- Name: silver_executions id; Type: DEFAULT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_executions ALTER COLUMN id SET DEFAULT nextval('datasets.silver_executions_id_seq'::regclass);


--
-- Name: silver_normalization_rules id; Type: DEFAULT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_normalization_rules ALTER COLUMN id SET DEFAULT nextval('datasets.silver_normalization_rules_id_seq'::regclass);


--
-- Name: silver_persistent_configs id; Type: DEFAULT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_persistent_configs ALTER COLUMN id SET DEFAULT nextval('datasets.silver_persistent_configs_id_seq'::regclass);


--
-- Name: silver_virtualized_configs id; Type: DEFAULT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_virtualized_configs ALTER COLUMN id SET DEFAULT nextval('datasets.silver_virtualized_configs_id_seq'::regclass);


--
-- Name: source_relationships id; Type: DEFAULT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.source_relationships ALTER COLUMN id SET DEFAULT nextval('datasets.source_relationships_id_seq'::regclass);


--
-- Name: recipient_access_logs id; Type: DEFAULT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.recipient_access_logs ALTER COLUMN id SET DEFAULT nextval('delta_sharing.recipient_access_logs_id_seq'::regclass);


--
-- Name: recipients id; Type: DEFAULT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.recipients ALTER COLUMN id SET DEFAULT nextval('delta_sharing.recipients_id_seq'::regclass);


--
-- Name: share_schemas id; Type: DEFAULT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_schemas ALTER COLUMN id SET DEFAULT nextval('delta_sharing.share_schemas_id_seq'::regclass);


--
-- Name: share_table_files id; Type: DEFAULT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_table_files ALTER COLUMN id SET DEFAULT nextval('delta_sharing.share_table_files_id_seq'::regclass);


--
-- Name: share_table_versions id; Type: DEFAULT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_table_versions ALTER COLUMN id SET DEFAULT nextval('delta_sharing.share_table_versions_id_seq'::regclass);


--
-- Name: share_tables id; Type: DEFAULT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_tables ALTER COLUMN id SET DEFAULT nextval('delta_sharing.share_tables_id_seq'::regclass);


--
-- Name: shares id; Type: DEFAULT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.shares ALTER COLUMN id SET DEFAULT nextval('delta_sharing.shares_id_seq'::regclass);


--
-- Name: column_groups id; Type: DEFAULT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.column_groups ALTER COLUMN id SET DEFAULT nextval('equivalence.column_groups_id_seq'::regclass);


--
-- Name: column_mappings id; Type: DEFAULT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.column_mappings ALTER COLUMN id SET DEFAULT nextval('equivalence.column_mappings_id_seq'::regclass);


--
-- Name: data_dictionary id; Type: DEFAULT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.data_dictionary ALTER COLUMN id SET DEFAULT nextval('equivalence.data_dictionary_id_seq'::regclass);


--
-- Name: semantic_domains id; Type: DEFAULT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.semantic_domains ALTER COLUMN id SET DEFAULT nextval('equivalence.semantic_domains_id_seq'::regclass);


--
-- Name: value_mappings id; Type: DEFAULT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.value_mappings ALTER COLUMN id SET DEFAULT nextval('equivalence.value_mappings_id_seq'::regclass);


--
-- Name: column_tags id; Type: DEFAULT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.column_tags ALTER COLUMN id SET DEFAULT nextval('metadata.column_tags_id_seq'::regclass);


--
-- Name: external_catalogs id; Type: DEFAULT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_catalogs ALTER COLUMN id SET DEFAULT nextval('metadata.external_catalogs_id_seq'::regclass);


--
-- Name: external_columns id; Type: DEFAULT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_columns ALTER COLUMN id SET DEFAULT nextval('metadata.external_columns_id_seq'::regclass);


--
-- Name: external_schemas id; Type: DEFAULT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_schemas ALTER COLUMN id SET DEFAULT nextval('metadata.external_schemas_id_seq'::regclass);


--
-- Name: external_tables id; Type: DEFAULT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_tables ALTER COLUMN id SET DEFAULT nextval('metadata.external_tables_id_seq'::regclass);


--
-- Name: federation_connections id; Type: DEFAULT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.federation_connections ALTER COLUMN id SET DEFAULT nextval('metadata.federation_connections_id_seq'::regclass);


--
-- Name: federation_tables id; Type: DEFAULT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.federation_tables ALTER COLUMN id SET DEFAULT nextval('metadata.federation_tables_id_seq'::regclass);


--
-- Name: federations id; Type: DEFAULT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.federations ALTER COLUMN id SET DEFAULT nextval('metadata.federations_id_seq'::regclass);


--
-- Name: relationship_suggestions id; Type: DEFAULT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.relationship_suggestions ALTER COLUMN id SET DEFAULT nextval('metadata.relationship_suggestions_id_seq'::regclass);


--
-- Name: semantic_column_links id; Type: DEFAULT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.semantic_column_links ALTER COLUMN id SET DEFAULT nextval('metadata.semantic_column_links_id_seq'::regclass);


--
-- Name: table_relationships id; Type: DEFAULT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.table_relationships ALTER COLUMN id SET DEFAULT nextval('metadata.table_relationships_id_seq'::regclass);


--
-- Name: dataset_storage id; Type: DEFAULT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.dataset_storage ALTER COLUMN id SET DEFAULT nextval('storage.dataset_storage_id_seq'::regclass);


--
-- Name: dataset_jobs id; Type: DEFAULT; Schema: workflow; Owner: -
--

ALTER TABLE ONLY workflow.dataset_jobs ALTER COLUMN id SET DEFAULT nextval('workflow.dataset_jobs_id_seq'::regclass);


--
-- Name: metadata_sync_jobs id; Type: DEFAULT; Schema: workflow; Owner: -
--

ALTER TABLE ONLY workflow.metadata_sync_jobs ALTER COLUMN id SET DEFAULT nextval('workflow.metadata_sync_jobs_id_seq'::regclass);


--
-- Name: sync_execution_history id; Type: DEFAULT; Schema: workflow; Owner: -
--

ALTER TABLE ONLY workflow.sync_execution_history ALTER COLUMN id SET DEFAULT nextval('workflow.sync_execution_history_id_seq'::regclass);


--
-- Data for Name: connection_types; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.connection_types (id, name, description, icon, color_hex, connection_params_schema, metadata_extraction_method) FROM stdin;
1	postgresql	PostgreSQL database connection	postgresql	#336791	{"type": "object", "properties": {"host": {"type": "string", "title": "Host", "description": "Endere\\u00e7o do servidor PostgreSQL"}, "port": {"type": "integer", "title": "Port", "description": "Porta do servidor PostgreSQL", "default": 5432}, "database": {"type": "string", "title": "Database", "description": "Nome do banco de dados"}, "username": {"type": "string", "title": "Username", "description": "Usu\\u00e1rio para autentica\\u00e7\\u00e3o"}, "password": {"type": "string", "title": "Password", "description": "Senha para autentica\\u00e7\\u00e3o", "format": "password"}, "sslmode": {"type": "string", "title": "SSL Mode", "description": "Modo SSL (disable, require, verify-ca, verify-full)", "enum": ["disable", "allow", "prefer", "require", "verify-ca", "verify-full"], "default": "prefer"}, "tunnel": {"type": "object", "title": "SSH Tunnel", "description": "Configura\\u00e7\\u00e3o opcional de t\\u00fanel SSH para acessar fontes de dados em redes privadas", "properties": {"enabled": {"type": "boolean", "title": "Habilitar t\\u00fanel SSH", "description": "Ativar conex\\u00e3o via t\\u00fanel SSH", "default": false}, "ssh_host": {"type": "string", "title": "SSH Host", "description": "Endere\\u00e7o do servidor SSH (bastion/jump host)"}, "ssh_port": {"type": "integer", "title": "SSH Port", "description": "Porta do servidor SSH", "default": 22}, "ssh_username": {"type": "string", "title": "SSH Username", "description": "Usu\\u00e1rio para autentica\\u00e7\\u00e3o SSH"}, "auth_method": {"type": "string", "title": "M\\u00e9todo de Autentica\\u00e7\\u00e3o", "description": "M\\u00e9todo de autentica\\u00e7\\u00e3o SSH", "enum": ["password", "private_key"], "default": "password"}, "ssh_password": {"type": "string", "title": "SSH Password", "description": "Senha para autentica\\u00e7\\u00e3o SSH", "format": "password"}, "ssh_private_key": {"type": "string", "title": "SSH Private Key", "description": "Chave privada SSH (conte\\u00fado PEM)", "format": "textarea"}, "ssh_passphrase": {"type": "string", "title": "SSH Passphrase", "description": "Passphrase da chave privada (se houver)", "format": "password"}}, "required": [], "additionalProperties": false}}, "required": ["host", "database", "username", "password"], "additionalProperties": false}	direct_query
2	mysql	MySQL database connection	mysql	#4479A1	{"type": "object", "properties": {"host": {"type": "string", "title": "Host", "description": "Endere\\u00e7o do servidor MySQL"}, "port": {"type": "integer", "title": "Port", "description": "Porta do servidor MySQL", "default": 3306}, "database": {"type": "string", "title": "Database", "description": "Nome do banco de dados (schema padr\\u00e3o; todos os schemas do servidor ficam acess\\u00edveis via Trino)"}, "username": {"type": "string", "title": "Username", "description": "Usu\\u00e1rio para autentica\\u00e7\\u00e3o"}, "password": {"type": "string", "title": "Password", "description": "Senha para autentica\\u00e7\\u00e3o", "format": "password"}, "sslmode": {"type": "string", "title": "SSL Mode", "description": "Modo SSL (disabled, required, verify_ca, verify_identity)", "enum": ["disabled", "required", "verify_ca", "verify_identity"], "default": "required"}, "tunnel": {"type": "object", "title": "SSH Tunnel", "description": "Configura\\u00e7\\u00e3o opcional de t\\u00fanel SSH para acessar fontes de dados em redes privadas", "properties": {"enabled": {"type": "boolean", "title": "Habilitar t\\u00fanel SSH", "description": "Ativar conex\\u00e3o via t\\u00fanel SSH", "default": false}, "ssh_host": {"type": "string", "title": "SSH Host", "description": "Endere\\u00e7o do servidor SSH (bastion/jump host)"}, "ssh_port": {"type": "integer", "title": "SSH Port", "description": "Porta do servidor SSH", "default": 22}, "ssh_username": {"type": "string", "title": "SSH Username", "description": "Usu\\u00e1rio para autentica\\u00e7\\u00e3o SSH"}, "auth_method": {"type": "string", "title": "M\\u00e9todo de Autentica\\u00e7\\u00e3o", "description": "M\\u00e9todo de autentica\\u00e7\\u00e3o SSH", "enum": ["password", "private_key"], "default": "password"}, "ssh_password": {"type": "string", "title": "SSH Password", "description": "Senha para autentica\\u00e7\\u00e3o SSH", "format": "password"}, "ssh_private_key": {"type": "string", "title": "SSH Private Key", "description": "Chave privada SSH (conte\\u00fado PEM)", "format": "textarea"}, "ssh_passphrase": {"type": "string", "title": "SSH Passphrase", "description": "Passphrase da chave privada (se houver)", "format": "password"}}, "required": [], "additionalProperties": false}}, "required": ["host", "database", "username", "password"], "additionalProperties": false}	direct_query
3	deltalake	Delta Lake connection for reading/writing Delta tables on S3-compatible storage	delta	#FF6B35	{"type": "object", "properties": {"s3a_endpoint": {"type": "string", "title": "S3A Endpoint", "description": "S3-compatible storage endpoint (e.g., http://localhost:9000)", "default": "http://localhost:9000"}, "s3a_access_key": {"type": "string", "title": "Access Key", "description": "S3 access key for authentication"}, "s3a_secret_key": {"type": "string", "title": "Secret Key", "description": "S3 secret key for authentication", "format": "password"}, "app_name": {"type": "string", "title": "Application Name", "description": "Spark application name", "default": "DeltaLakeConnector"}, "bucket_name": {"type": "string", "title": "Delta Path", "description": "Base path for Delta tables (e.g., bucket-name)", "default": "isic-delta"}, "tunnel": {"type": "object", "title": "SSH Tunnel", "description": "Configura\\u00e7\\u00e3o opcional de t\\u00fanel SSH para acessar fontes de dados em redes privadas", "properties": {"enabled": {"type": "boolean", "title": "Habilitar t\\u00fanel SSH", "description": "Ativar conex\\u00e3o via t\\u00fanel SSH", "default": false}, "ssh_host": {"type": "string", "title": "SSH Host", "description": "Endere\\u00e7o do servidor SSH (bastion/jump host)"}, "ssh_port": {"type": "integer", "title": "SSH Port", "description": "Porta do servidor SSH", "default": 22}, "ssh_username": {"type": "string", "title": "SSH Username", "description": "Usu\\u00e1rio para autentica\\u00e7\\u00e3o SSH"}, "auth_method": {"type": "string", "title": "M\\u00e9todo de Autentica\\u00e7\\u00e3o", "description": "M\\u00e9todo de autentica\\u00e7\\u00e3o SSH", "enum": ["password", "private_key"], "default": "password"}, "ssh_password": {"type": "string", "title": "SSH Password", "description": "Senha para autentica\\u00e7\\u00e3o SSH", "format": "password"}, "ssh_private_key": {"type": "string", "title": "SSH Private Key", "description": "Chave privada SSH (conte\\u00fado PEM)", "format": "textarea"}, "ssh_passphrase": {"type": "string", "title": "SSH Passphrase", "description": "Passphrase da chave privada (se houver)", "format": "password"}}, "required": [], "additionalProperties": false}}, "required": ["s3a_endpoint", "s3a_access_key", "s3a_secret_key"], "additionalProperties": false}	direct_spark
4	s3	Amazon S3 or S3-compatible object storage	aws	#FF9900	{"type": "object", "properties": {"auth_type": {"type": "string", "title": "Authentication Type", "enum": ["access_key", "iam_role", "instance_profile"], "default": "access_key"}, "endpoint": {"type": "string", "title": "Custom Endpoint", "description": "Custom S3-compatible endpoint URL (leave empty for AWS S3)"}, "access_key": {"type": "string", "title": "Access Key ID"}, "secret_key": {"type": "string", "title": "Secret Access Key", "format": "password"}, "session_token": {"type": "string", "title": "Session Token", "format": "password"}, "iam_role": {"type": "string", "title": "IAM Role ARN"}, "external_id": {"type": "string", "title": "External ID"}, "region": {"type": "string", "title": "AWS Region", "default": "us-east-1"}, "bucket_name": {"type": "string", "title": "Bucket Name"}, "secure": {"type": "boolean", "title": "Use HTTPS", "default": true}, "path_style_access": {"type": "boolean", "title": "Path Style Access", "default": false}, "tunnel": {"type": "object", "title": "SSH Tunnel", "description": "Configura\\u00e7\\u00e3o opcional de t\\u00fanel SSH para acessar fontes de dados em redes privadas", "properties": {"enabled": {"type": "boolean", "title": "Habilitar t\\u00fanel SSH", "description": "Ativar conex\\u00e3o via t\\u00fanel SSH", "default": false}, "ssh_host": {"type": "string", "title": "SSH Host", "description": "Endere\\u00e7o do servidor SSH (bastion/jump host)"}, "ssh_port": {"type": "integer", "title": "SSH Port", "description": "Porta do servidor SSH", "default": 22}, "ssh_username": {"type": "string", "title": "SSH Username", "description": "Usu\\u00e1rio para autentica\\u00e7\\u00e3o SSH"}, "auth_method": {"type": "string", "title": "M\\u00e9todo de Autentica\\u00e7\\u00e3o", "description": "M\\u00e9todo de autentica\\u00e7\\u00e3o SSH", "enum": ["password", "private_key"], "default": "password"}, "ssh_password": {"type": "string", "title": "SSH Password", "description": "Senha para autentica\\u00e7\\u00e3o SSH", "format": "password"}, "ssh_private_key": {"type": "string", "title": "SSH Private Key", "description": "Chave privada SSH (conte\\u00fado PEM)", "format": "textarea"}, "ssh_passphrase": {"type": "string", "title": "SSH Passphrase", "description": "Passphrase da chave privada (se houver)", "format": "password"}}, "required": [], "additionalProperties": false}}, "required": ["region"], "additionalProperties": false}	trino
5	azure_storage	Azure Blob Storage or Azure Data Lake Storage Gen2	azure	#0078D4	{"type": "object", "properties": {"auth_type": {"type": "string", "title": "Authentication Type", "enum": ["access_key", "service_principal", "managed_identity", "sas_token"], "default": "access_key"}, "storage_account": {"type": "string", "title": "Storage Account Name"}, "container": {"type": "string", "title": "Container/Filesystem"}, "access_key": {"type": "string", "title": "Access Key", "format": "password"}, "tenant_id": {"type": "string", "title": "Tenant ID"}, "client_id": {"type": "string", "title": "Client ID"}, "client_secret": {"type": "string", "title": "Client Secret", "format": "password"}, "managed_identity_client_id": {"type": "string", "title": "Managed Identity Client ID"}, "sas_token": {"type": "string", "title": "SAS Token", "format": "password"}, "endpoint_suffix": {"type": "string", "title": "Endpoint Suffix", "default": "core.windows.net"}, "tunnel": {"type": "object", "title": "SSH Tunnel", "description": "Configura\\u00e7\\u00e3o opcional de t\\u00fanel SSH para acessar fontes de dados em redes privadas", "properties": {"enabled": {"type": "boolean", "title": "Habilitar t\\u00fanel SSH", "description": "Ativar conex\\u00e3o via t\\u00fanel SSH", "default": false}, "ssh_host": {"type": "string", "title": "SSH Host", "description": "Endere\\u00e7o do servidor SSH (bastion/jump host)"}, "ssh_port": {"type": "integer", "title": "SSH Port", "description": "Porta do servidor SSH", "default": 22}, "ssh_username": {"type": "string", "title": "SSH Username", "description": "Usu\\u00e1rio para autentica\\u00e7\\u00e3o SSH"}, "auth_method": {"type": "string", "title": "M\\u00e9todo de Autentica\\u00e7\\u00e3o", "description": "M\\u00e9todo de autentica\\u00e7\\u00e3o SSH", "enum": ["password", "private_key"], "default": "password"}, "ssh_password": {"type": "string", "title": "SSH Password", "description": "Senha para autentica\\u00e7\\u00e3o SSH", "format": "password"}, "ssh_private_key": {"type": "string", "title": "SSH Private Key", "description": "Chave privada SSH (conte\\u00fado PEM)", "format": "textarea"}, "ssh_passphrase": {"type": "string", "title": "SSH Passphrase", "description": "Passphrase da chave privada (se houver)", "format": "password"}}, "required": [], "additionalProperties": false}}, "required": ["storage_account"], "additionalProperties": false}	trino
6	gcs	Google Cloud Storage	google-cloud	#4285F4	{"type": "object", "properties": {"auth_type": {"type": "string", "title": "Authentication Type", "enum": ["service_account", "application_default", "workload_identity", "access_token"], "default": "service_account"}, "project_id": {"type": "string", "title": "Project ID"}, "bucket": {"type": "string", "title": "Bucket Name"}, "service_account_key": {"type": "string", "title": "Service Account Key", "format": "textarea"}, "service_account_key_path": {"type": "string", "title": "Service Account Key Path"}, "access_token": {"type": "string", "title": "Access Token", "format": "password"}, "max_retries": {"type": "integer", "title": "Max Retries", "default": 3}, "tunnel": {"type": "object", "title": "SSH Tunnel", "description": "Configura\\u00e7\\u00e3o opcional de t\\u00fanel SSH para acessar fontes de dados em redes privadas", "properties": {"enabled": {"type": "boolean", "title": "Habilitar t\\u00fanel SSH", "description": "Ativar conex\\u00e3o via t\\u00fanel SSH", "default": false}, "ssh_host": {"type": "string", "title": "SSH Host", "description": "Endere\\u00e7o do servidor SSH (bastion/jump host)"}, "ssh_port": {"type": "integer", "title": "SSH Port", "description": "Porta do servidor SSH", "default": 22}, "ssh_username": {"type": "string", "title": "SSH Username", "description": "Usu\\u00e1rio para autentica\\u00e7\\u00e3o SSH"}, "auth_method": {"type": "string", "title": "M\\u00e9todo de Autentica\\u00e7\\u00e3o", "description": "M\\u00e9todo de autentica\\u00e7\\u00e3o SSH", "enum": ["password", "private_key"], "default": "password"}, "ssh_password": {"type": "string", "title": "SSH Password", "description": "Senha para autentica\\u00e7\\u00e3o SSH", "format": "password"}, "ssh_private_key": {"type": "string", "title": "SSH Private Key", "description": "Chave privada SSH (conte\\u00fado PEM)", "format": "textarea"}, "ssh_passphrase": {"type": "string", "title": "SSH Passphrase", "description": "Passphrase da chave privada (se houver)", "format": "password"}}, "required": [], "additionalProperties": false}}, "required": [], "additionalProperties": false}	trino
\.


--
-- Data for Name: data_connections; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.data_connections (id, organization_id, name, description, connection_type_id, connection_params, content_type, status, sync_status, sync_progress, sync_progress_details, last_sync_time, next_sync_time, cron_expression, sync_settings) FROM stdin;
3	1	CMPD - Centro de Medicina Preventiva e Diagnóstico	Hospital B — PostgreSQL 15. Exames de rotina preventivos. Schemas: cadastro_beneficiario, rastreamento, laboratorio. 1505 beneficiários.	1	{ "host" : "cmpd-postgres", "port" : 5432, "database" : "cmpd_preventiva", "username" : "cmpd_user", "password" : "cmpd_pass", "sslmode" : "disable" }	metadata	active	idle	0	\N	2026-05-24 00:42:38.009702+00	\N	\N	{}
4	1	IDA - Instituto de Dermatologia Avançada	Hospital A — MySQL 8.0. Exames de câncer de pele. Schemas (databases MySQL): triagem, anatomopatologia, oncologia_pele. 1005 pacientes.	2	{ "host" : "ida-mysql", "port" : 3306, "database" : "triagem", "username" : "ida_user", "password" : "ida_pass", "sslmode" : "disabled" }	metadata	active	idle	0	\N	2026-05-24 00:42:38.014849+00	\N	\N	{}
5	1	REH - Rede de Emergências Hospitalares	PostgreSQL 15. Emergência/internação. Schemas: pronto_socorro, internacao, monitoramento. 500k pacientes. Federa via cpf_paciente (compartilha CPFs com CDI, não com RFA).	1	{ "host" : "reh-postgres", "port" : 5432, "database" : "reh_emergencias", "username" : "reh_user", "password" : "reh_pass", "sslmode" : "disable" }	metadata	active	idle	0	\N	2026-06-03 02:33:28.127703+00	\N	\N	{}
6	1	CDI - Centro de Diagnóstico por Imagem	PostgreSQL 15. Imagem/laudos (HUB). Schemas: pacientes, exames, dosimetria. 500k pacientes. Federa via cpf_pessoa (compartilha CPFs com REH e com RFA).	1	{ "host" : "cdi-postgres", "port" : 5432, "database" : "cdi_imagem", "username" : "cdi_user", "password" : "cdi_pass", "sslmode" : "disable" }	metadata	active	idle	0	\N	2026-06-03 02:33:40.829582+00	\N	\N	{}
7	1	RFA - Rede de Farmácias e Adesão	MySQL 8.0. Dispensação/farmacovigilância. Schemas (databases): dispensacao, farmacovigilancia, adesao_terapeutica. 500k clientes. Federa via cpf_cliente (compartilha CPFs com CDI, não com REH).	2	{ "host" : "rfa-mysql", "port" : 3306, "database" : "dispensacao", "username" : "rfa_user", "password" : "rfa_pass", "sslmode" : "disabled" }	metadata	active	idle	0	\N	2026-06-03 02:33:33.482183+00	\N	\N	{}
8	1	dermexp3 HAM10000 collection 212	Isolated ham10000 source for Dermatology Experiment 3	1	{ "host" : "dermexp_ham_postgres", "port" : 5432, "database" : "ham10000", "username" : "ham_user", "password" : "ham_pass", "sslmode" : "disable" }	metadata	active	idle	0	\N	2026-07-13 22:18:36.539668+00	\N	\N	{"experiment": "dermatology_exp3"}
9	1	dermexp3 HIBA collection 251	Isolated hiba source for Dermatology Experiment 3	1	{ "host" : "dermexp_hiba_postgres", "port" : 5432, "database" : "hiba", "username" : "hiba_user", "password" : "hiba_pass", "sslmode" : "disable" }	metadata	active	idle	0	\N	2026-07-13 22:18:38.203892+00	\N	\N	{"experiment": "dermatology_exp3"}
10	1	dermexp3 PAD-UFES-20 collection 406	Isolated pad_ufes_20 source for Dermatology Experiment 3	2	{ "host" : "dermexp_pad_mysql", "port" : 3306, "database" : "isic", "username" : "pad_user", "password" : "pad_pass" }	metadata	active	idle	0	\N	2026-07-13 22:18:41.35086+00	\N	\N	{"experiment": "dermatology_exp3"}
11	1	dermexp3 v2 HAM10000 collection 212	Isolated ham10000 source for Dermatology Experiment 3	1	{ "host" : "dermexp_ham_postgres", "port" : 5432, "database" : "ham10000", "username" : "ham_user", "password" : "ham_pass", "sslmode" : "disable" }	metadata	active	idle	0	\N	2026-07-13 22:21:53.270003+00	\N	\N	{"experiment": "dermatology_exp3"}
12	1	dermexp3 v2 HIBA collection 251	Isolated hiba source for Dermatology Experiment 3	1	{ "host" : "dermexp_hiba_postgres", "port" : 5432, "database" : "hiba", "username" : "hiba_user", "password" : "hiba_pass", "sslmode" : "disable" }	metadata	active	idle	0	\N	2026-07-13 22:21:54.5515+00	\N	\N	{"experiment": "dermatology_exp3"}
13	1	dermexp3 v2 PAD-UFES-20 collection 406	Isolated pad_ufes_20 source for Dermatology Experiment 3	2	{ "host" : "dermexp_pad_mysql", "port" : 3306, "database" : "isic", "username" : "pad_user", "password" : "pad_pass" }	metadata	active	idle	0	\N	2026-07-13 22:21:55.702116+00	\N	\N	{"experiment": "dermatology_exp3"}
\.


--
-- Data for Name: dataset_column_sources; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.dataset_column_sources (id, dataset_column_id, source_column_id, transformation_type, transformation_expression, is_primary_source) FROM stdin;
\.


--
-- Data for Name: dataset_columns; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.dataset_columns (id, dataset_id, name, description, data_type, is_nullable, column_position, transformation_expression, is_visible, format_pattern, properties) FROM stdin;
\.


--
-- Data for Name: dataset_sources; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.dataset_sources (id, dataset_id, table_id, join_type, join_condition, filter_condition) FROM stdin;
\.


--
-- Data for Name: dataset_versions; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.dataset_versions (id, dataset_id, version_number, version_note, is_current, previous_version_id, job_id, row_count, schema_hash) FROM stdin;
\.


--
-- Data for Name: datasets; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.datasets (id, name, description, storage_type, refresh_type, refresh_schedule, status, version, properties, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	silver_1_hospital_federation_persistent	Persistent Silver dataset joining IDA (MySQL) and CMPD (PostgreSQL) via federated CPF. Reads always from the latest Bronze version. Applies semantic unification (Patient CPF + Biological Sex), CPF formatting, accent removal on names, and uppercase smoking status. Filters ensure only records with complete CMPD data and valid BMI are included.	delta	manual	\N	active	1.0	{}	2026-05-24 03:42:04.514194	2026-05-24 03:42:04.514194	\N	\N	t
2	bronze_1_hospital_federation_persistent	Persistent Bronze: federated JOIN between IDA (MySQL) and CMPD (PostgreSQL) via CPF. Materialises a unified patient view into Delta Lake — demographics from both hospitals in one output path.	delta	manual	\N	active	1.0	{}	2026-05-24 03:42:09.314089	2026-05-24 03:42:09.314089	\N	\N	t
3	silver_5_dermexp3_governed_derm_cancer_histo_v1	Governed dermatology condition G2_DERM_CANCER_HISTO: Histopathology-confirmed dermoscopic cancer cohort. Frozen protocol derm-governed-cohorts-v1.0.0.	delta	manual	\N	active	1.0	{}	2026-07-16 02:03:09.449793	2026-07-16 02:03:09.449793	\N	\N	t
4	silver_6_dermexp3_governed_clinical_cancer_phototype_v1	Governed dermatology condition G3_CLINICAL_CANCER_PHOTOTYPE: Clinical cancer cohort with recorded phototype. Frozen protocol derm-governed-cohorts-v1.0.0.	delta	manual	\N	active	1.0	{}	2026-07-16 02:03:09.624984	2026-07-16 02:03:09.624984	\N	\N	t
5	silver_7_dermexp3_governed_cc_by_policy_v1	Governed dermatology condition G4_CC_BY_POLICY: Experiment-defined CC-BY allowlist view. Frozen protocol derm-governed-cohorts-v1.0.0.	delta	manual	\N	active	1.0	{}	2026-07-16 02:03:09.707677	2026-07-16 02:03:09.707677	\N	\N	t
\.


--
-- Data for Name: group_dataset_permissions; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.group_dataset_permissions (id, group_id, dataset_id, access_level) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.groups (id, name, organization_id, description) FROM stdin;
\.


--
-- Data for Name: organizacoes; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.organizacoes (id, nome) FROM stdin;
1	DataFabric Demo
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.roles (id, name, nivel_acesso) FROM stdin;
\.


--
-- Data for Name: user_dataset_permissions; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.user_dataset_permissions (id, user_id, dataset_id, access_level) FROM stdin;
\.


--
-- Data for Name: user_groups; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.user_groups (user_id, group_id) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.user_roles (user_id, role_id) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: core; Owner: -
--

COPY core.users (id, organization_id, nome_usuario, email, cpf, senha_hash, password_reset_token, password_reset_token_used, email_invite_token, email_invite_token_used, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
\.


--
-- Data for Name: bronze_column_mappings; Type: TABLE DATA; Schema: datasets; Owner: -
--

COPY datasets.bronze_column_mappings (id, ingestion_group_id, external_column_id, external_table_id, original_column_name, original_table_name, original_schema_name, bronze_column_name, data_type, column_position, is_prefixed) FROM stdin;
\.


--
-- Data for Name: bronze_executions; Type: TABLE DATA; Schema: datasets; Owner: -
--

COPY datasets.bronze_executions (id, config_id, status, started_at, finished_at, group_results, rows_ingested, output_paths, error_message, execution_details, version_number, path_delta_versions, delta_version, write_mode_used, merge_keys_used, rows_inserted, rows_updated, rows_deleted, schema_hash, schema_changed, config_snapshot, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	1	SUCCESS	2026-05-24 02:45:57.127018+00	2026-05-24 02:46:28.318051+00	[{"group_name": "unified_federated", "connection_name": "federated", "status": "success", "output_path": "s3a://datafabric-bronze/1-hospital_federation_persistent/unified/", "rows_ingested": 1005, "execution_time_seconds": 30.851547, "error_message": null}]	1005	["s3a://datafabric-bronze/1-hospital_federation_persistent/unified/"]	\N	\N	0	{"s3a://datafabric-bronze/1-hospital_federation_persistent/unified/": 0}	0	overwrite	\N	1005	0	0	\N	f	{"name": "hospital_federation_persistent", "description": "Persistent Bronze: federated JOIN between IDA (MySQL) and CMPD (PostgreSQL) via CPF. Materialises a unified patient view into Delta Lake \\u2014 demographics from both hospitals in one output path.", "tables": [{"table_id": 31, "select_all": false, "column_ids": [195, 196, 197, 198]}, {"table_id": 5, "select_all": false, "column_ids": [36, 37, 38, 39, 48, 50]}], "relationship_ids": [11], "enable_federated_joins": true, "output_format": "delta", "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "write_mode": "overwrite", "merge_keys": null, "merge_keys_source": null, "properties": {}, "snapshot_at": "2026-05-24T02:45:57.126984"}	2026-05-24 02:45:57.124569	2026-05-24 02:46:28.319611	\N	\N	t
2	1	SUCCESS	2026-05-24 02:52:35.453374+00	2026-05-24 02:52:37.99412+00	[{"group_name": "unified_federated", "connection_name": "federated", "status": "success", "output_path": "s3a://datafabric-bronze/1-hospital_federation_persistent/unified/", "rows_ingested": 1507, "execution_time_seconds": 2.139716, "error_message": null}]	1507	["s3a://datafabric-bronze/1-hospital_federation_persistent/unified/"]	\N	\N	1	{"s3a://datafabric-bronze/1-hospital_federation_persistent/unified/": 1}	1	overwrite	\N	1507	0	0	\N	f	{"name": "hospital_federation_persistent", "description": "Persistent Bronze: federated JOIN between IDA (MySQL) and CMPD (PostgreSQL) via CPF. Materialises a unified patient view into Delta Lake \\u2014 demographics from both hospitals in one output path.", "tables": [{"table_id": 31, "select_all": false, "column_ids": [195, 196, 197, 198]}, {"table_id": 5, "select_all": false, "column_ids": [36, 37, 38, 39, 48, 50]}], "relationship_ids": [11], "enable_federated_joins": true, "output_format": "delta", "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "write_mode": "overwrite", "merge_keys": null, "merge_keys_source": null, "properties": {}, "snapshot_at": "2026-05-24T02:52:35.453295"}	2026-05-24 02:52:35.451709	2026-05-24 02:52:37.994507	\N	\N	t
3	1	SUCCESS	2026-05-24 02:58:40.866129+00	2026-05-24 02:58:43.395428+00	[{"group_name": "unified_federated", "connection_name": "federated", "status": "success", "output_path": "s3a://datafabric-bronze/1-hospital_federation_persistent/unified/", "rows_ingested": 1507, "execution_time_seconds": 2.224691, "error_message": null}]	1507	["s3a://datafabric-bronze/1-hospital_federation_persistent/unified/"]	\N	\N	2	{"s3a://datafabric-bronze/1-hospital_federation_persistent/unified/": 2}	2	overwrite	\N	1507	0	0	\N	f	{"name": "hospital_federation_persistent", "description": "Persistent Bronze: federated JOIN between IDA (MySQL) and CMPD (PostgreSQL) via CPF. Materialises a unified patient view into Delta Lake \\u2014 demographics from both hospitals in one output path.", "tables": [{"table_id": 31, "select_all": false, "column_ids": [195, 196, 197, 198, 200]}, {"table_id": 5, "select_all": false, "column_ids": [36, 37, 38, 39, 48, 50, 49]}], "relationship_ids": [11], "enable_federated_joins": true, "output_format": "delta", "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "write_mode": "overwrite", "merge_keys": null, "merge_keys_source": null, "properties": {}, "snapshot_at": "2026-05-24T02:58:40.866090"}	2026-05-24 02:58:40.863631	2026-05-24 02:58:43.396075	\N	\N	t
4	1	SUCCESS	2026-05-24 03:08:08.660421+00	2026-05-24 03:08:11.754258+00	[{"group_name": "unified_federated", "connection_name": "federated", "status": "success", "output_path": "s3a://datafabric-bronze/1-hospital_federation_persistent/unified/", "rows_ingested": 1507, "execution_time_seconds": 2.683925, "error_message": null}]	1507	["s3a://datafabric-bronze/1-hospital_federation_persistent/unified/"]	\N	\N	3	{"s3a://datafabric-bronze/1-hospital_federation_persistent/unified/": 3}	3	overwrite	\N	1507	0	0	\N	f	{"name": "hospital_federation_persistent", "description": "Persistent Bronze: federated JOIN between IDA (MySQL) and CMPD (PostgreSQL) via CPF. Materialises a unified patient view into Delta Lake \\u2014 demographics from both hospitals in one output path.", "tables": [{"table_id": 31, "select_all": false, "column_ids": [195, 196, 197, 198, 200]}, {"table_id": 5, "select_all": false, "column_ids": [36, 37, 38, 39, 48, 50, 49]}], "relationship_ids": [11], "enable_federated_joins": true, "output_format": "delta", "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "write_mode": "overwrite", "merge_keys": null, "merge_keys_source": null, "properties": {}, "snapshot_at": "2026-05-24T03:08:08.660357"}	2026-05-24 03:08:08.638321	2026-05-24 03:08:11.75471	\N	\N	t
5	11	FAILED	2026-06-11 02:13:22.256552+00	2026-06-11 02:14:23.20392+00	[{"group_name": "part_reh_-_rede_de_emergencias_hospitalares_joined_0", "connection_name": "REH - Rede de Emerg\\u00eancias Hospitalares", "status": "failed", "output_path": null, "rows_ingested": null, "execution_time_seconds": 29.005899, "error_message": "An error occurred while calling o839.save.\\n: org.apache.spark.SparkException: Job aborted due to stage failure: Task 0 in stage 14.0 failed 4 times, most recent failure: Lost task 0.3 in stage 14.0 (TID 158) (172.18.0.10 executor 0): org.apache.spark.SparkException: [TASK_WRITE_FAILED] Task failed while writing rows to s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_reh_-_rede_de_emergencias_hospitalares. SQLSTATE: 58030\\n\\tat org.apache.spark.sql.errors.QueryExecutionErrors$.taskFailedWhileWritingRowsError(QueryExecutionErrors.scala:772)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeTask(DeltaFileFormatWriter.scala:469)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$3(DeltaFileFormatWriter.scala:281)\\n\\tat org.apache.spark.scheduler.ResultTask.runTask(ResultTask.scala:93)\\n\\tat org.apache.spark.TaskContext.runTaskWithListeners(TaskContext.scala:171)\\n\\tat org.apache.spark.scheduler.Task.run(Task.scala:147)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.$anonfun$run$5(Executor.scala:647)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally(SparkErrorUtils.scala:80)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally$(SparkErrorUtils.scala:77)\\n\\tat org.apache.spark.util.Utils$.tryWithSafeFinally(Utils.scala:99)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.run(Executor.scala:650)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\nCaused by: java.sql.SQLException: Query failed (#20260611_021347_00049_62huf): Query exceeded per-node memory limit of 307.20MB [Allocated: 306.33MB, Delta: 2.04MB, Top Consumers: {HashBuilderOperator=274.94MB, ExchangeOperator=26.51MB, PagePartitioner=2.47MB}]\\n\\tat io.trino.jdbc.ResultUtils.resultsException(ResultUtils.java:33)\\n\\tat io.trino.jdbc.AsyncResultIterator.lambda$new$1(AsyncResultIterator.java:94)\\n\\tat java.base/java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:539)\\n\\tat java.base/java.util.concurrent.FutureTask.run(FutureTask.java:264)\\n\\t... 3 more\\nCaused by: io.trino.ExceededMemoryLimitException: Query exceeded per-node memory limit of 307.20MB [Allocated: 306.33MB, Delta: 2.04MB, Top Consumers: {HashBuilderOperator=274.94MB, ExchangeOperator=26.51MB, PagePartitioner=2.47MB}]\\n\\tat io.trino.ExceededMemoryLimitException.exceededLocalUserMemoryLimit(ExceededMemoryLimitException.java:41)\\n\\tat io.trino.memory.QueryContext.enforceUserMemoryLimit(QueryContext.java:333)\\n\\tat io.trino.memory.QueryContext.updateUserMemory(QueryContext.java:166)\\n\\tat io.trino.memory.QueryContext.lambda$addTaskContext$0(QueryContext.java:252)\\n\\tat io.trino.memory.QueryContext$QueryMemoryReservationHandler.reserveMemory(QueryContext.java:314)\\n\\tat io.trino.memory.context.RootAggregatedMemoryContext.updateBytes(RootAggregatedMemoryContext.java:37)\\n\\tat io.trino.memory.context.SimpleLocalMemoryContext.setBytes(SimpleLocalMemoryContext.java:65)\\n\\tat io.trino.execution.buffer.OutputBufferMemoryManager.updateMemoryUsage(OutputBufferMemoryManager.java:108)\\n\\tat io.trino.execution.buffer.PartitionedOutputBuffer.enqueue(PartitionedOutputBuffer.java:207)\\n\\tat io.trino.execution.buffer.LazyOutputBuffer.enqueue(LazyOutputBuffer.java:277)\\n\\tat io.trino.operator.output.PagePartitioner.enqueuePage(PagePartitioner.java:487)\\n\\tat io.trino.operator.output.PagePartitioner.flushPositionsAppenders(PagePartitioner.java:479)\\n\\tat io.trino.operator.output.PagePartitioner.partitionPage(PagePartitioner.java:160)\\n\\tat io.trino.operator.output.PartitionedOutputOperator.addInput(PartitionedOutputOperator.java:339)\\n\\tat io.trino.operator.Driver.processInternal(Driver.java:408)\\n\\tat io.trino.operator.Driver.lambda$process$0(Driver.java:306)\\n\\tat io.trino.operator.Driver.tryWithLock(Driver.java:709)\\n\\tat io.trino.operator.Driver.process(Driver.java:298)\\n\\tat io.trino.operator.Driver.processForDuration(Driver.java:269)\\n\\tat io.trino.execution.SqlTaskExecution$DriverSplitRunner.processFor(SqlTaskExecution.java:852)\\n\\tat io.trino.execution.executor.dedicated.SplitProcessor.run(SplitProcessor.java:77)\\n\\tat io.trino.execution.executor.dedicated.TaskEntry$VersionEmbedderBridge.lambda$run$0(TaskEntry.java:205)\\n\\tat io.trino.$gen.Trino_481____20260611_013912_2.run(Unknown Source)\\n\\tat io.trino.execution.executor.dedicated.TaskEntry$VersionEmbedderBridge.run(TaskEntry.java:206)\\n\\tat io.trino.execution.executor.scheduler.FairScheduler.runTask(FairScheduler.java:177)\\n\\tat io.trino.execution.executor.scheduler.FairScheduler.lambda$submit$0(FairScheduler.java:164)\\n\\tat java.base/java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:545)\\n\\tat com.google.common.util.concurrent.TrustedListenableFutureTask$TrustedFutureInterruptibleTask.runInterruptibly(TrustedListenableFutureTask.java:128)\\n\\tat com.google.common.util.concurrent.InterruptibleTask.run(InterruptibleTask.java:74)\\n\\tat com.google.common.util.concurrent.TrustedListenableFutureTask.run(TrustedListenableFutureTask.java:80)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1090)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:614)\\n\\tat java.base/java.lang.Thread.run(Thread.java:1474)\\n\\nDriver stacktrace:\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\tat scala.Option.getOrElse(Option.scala:201)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\tat scala.Option.foreach(Option.scala:437)\\n\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\tat scala.util.Try$.apply(Try.scala:217)\\n\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\tat org.apache.spark.util.Utils$.getTryWithCallerStacktrace(Utils.scala:1439)\\n\\tat org.apache.spark.util.LazyTry.get(LazyTry.scala:58)\\n\\tat org.apache.spark.sql.execution.QueryExecution.commandExecuted(QueryExecution.scala:131)\\n\\tat org.apache.spark.sql.execution.QueryExecution.assertCommandExecuted(QueryExecution.scala:192)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.runCommand(DataFrameWriter.scala:622)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveToV1Source(DataFrameWriter.scala:273)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveInternal(DataFrameWriter.scala:182)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.save(DataFrameWriter.scala:118)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)\\n\\tat java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\\n\\tat java.base/java.lang.reflect.Method.invoke(Method.java:569)\\n\\tat py4j.reflection.MethodInvoker.invoke(MethodInvoker.java:244)\\n\\tat py4j.reflection.ReflectionEngine.invoke(ReflectionEngine.java:374)\\n\\tat py4j.Gateway.invoke(Gateway.java:282)\\n\\tat py4j.commands.AbstractCommand.invokeMethod(AbstractCommand.java:132)\\n\\tat py4j.commands.CallCommand.execute(CallCommand.java:79)\\n\\tat py4j.ClientServerConnection.waitForCommands(ClientServerConnection.java:184)\\n\\tat py4j.ClientServerConnection.run(ClientServerConnection.java:108)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\n\\tSuppressed: org.apache.spark.util.Utils$OriginalTryStackTraceException: Full stacktrace of original doTryWithCallerStacktrace caller\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\t\\tat scala.Option.getOrElse(Option.scala:201)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\t\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\t\\tat scala.Option.foreach(Option.scala:437)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\t\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\t\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\t\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\t\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\t\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\t\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\t\\tat scala.util.Try$.apply(Try.scala:217)\\n\\t\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT$lzycompute(LazyTry.scala:46)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT(LazyTry.scala:46)\\n\\t\\t... 19 more\\n"}, {"group_name": "part_rfa_-_rede_de_farmacias_e_adesao_joined_0", "connection_name": "RFA - Rede de Farm\\u00e1cias e Ades\\u00e3o", "status": "failed", "output_path": null, "rows_ingested": null, "execution_time_seconds": 13.849551, "error_message": "An error occurred while calling o854.save.\\n: org.apache.spark.SparkException: Job aborted due to stage failure: Task 0 in stage 15.0 failed 4 times, most recent failure: Lost task 0.3 in stage 15.0 (TID 162) (172.18.0.10 executor 0): org.apache.spark.SparkException: [TASK_WRITE_FAILED] Task failed while writing rows to s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_rfa_-_rede_de_farmacias_e_adesao. SQLSTATE: 58030\\n\\tat org.apache.spark.sql.errors.QueryExecutionErrors$.taskFailedWhileWritingRowsError(QueryExecutionErrors.scala:772)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeTask(DeltaFileFormatWriter.scala:469)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$3(DeltaFileFormatWriter.scala:281)\\n\\tat org.apache.spark.scheduler.ResultTask.runTask(ResultTask.scala:93)\\n\\tat org.apache.spark.TaskContext.runTaskWithListeners(TaskContext.scala:171)\\n\\tat org.apache.spark.scheduler.Task.run(Task.scala:147)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.$anonfun$run$5(Executor.scala:647)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally(SparkErrorUtils.scala:80)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally$(SparkErrorUtils.scala:77)\\n\\tat org.apache.spark.util.Utils$.tryWithSafeFinally(Utils.scala:99)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.run(Executor.scala:650)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\nCaused by: java.sql.SQLException: Query failed (#20260611_021402_00059_62huf): Query exceeded per-node memory limit of 307.20MB [Allocated: 306.79MB, Delta: 931.18kB, Top Consumers: {HashBuilderOperator=255.25MB, ExchangeOperator=33.33MB, LazyOutputBuffer=18.00MB}]\\n\\tat io.trino.jdbc.ResultUtils.resultsException(ResultUtils.java:33)\\n\\tat io.trino.jdbc.AsyncResultIterator.lambda$new$1(AsyncResultIterator.java:94)\\n\\tat java.base/java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:539)\\n\\tat java.base/java.util.concurrent.FutureTask.run(FutureTask.java:264)\\n\\t... 3 more\\nCaused by: io.trino.ExceededMemoryLimitException: Query exceeded per-node memory limit of 307.20MB [Allocated: 306.79MB, Delta: 931.18kB, Top Consumers: {HashBuilderOperator=255.25MB, ExchangeOperator=33.33MB, LazyOutputBuffer=18.00MB}]\\n\\tat io.trino.ExceededMemoryLimitException.exceededLocalUserMemoryLimit(ExceededMemoryLimitException.java:41)\\n\\tat io.trino.memory.QueryContext.enforceUserMemoryLimit(QueryContext.java:333)\\n\\tat io.trino.memory.QueryContext.updateUserMemory(QueryContext.java:166)\\n\\tat io.trino.memory.QueryContext.lambda$addTaskContext$0(QueryContext.java:252)\\n\\tat io.trino.memory.QueryContext$QueryMemoryReservationHandler.reserveMemory(QueryContext.java:314)\\n\\tat io.trino.memory.context.RootAggregatedMemoryContext.updateBytes(RootAggregatedMemoryContext.java:37)\\n\\tat io.trino.memory.context.ChildAggregatedMemoryContext.updateBytes(ChildAggregatedMemoryContext.java:38)\\n\\tat io.trino.memory.context.SimpleLocalMemoryContext.setBytes(SimpleLocalMemoryContext.java:65)\\n\\tat io.trino.operator.DirectExchangeClient.updateRetainedMemory(DirectExchangeClient.java:368)\\n\\tat io.trino.operator.DirectExchangeClient.addPages(DirectExchangeClient.java:347)\\n\\tat io.trino.operator.DirectExchangeClient$ExchangeClientCallback.addPages(DirectExchangeClient.java:431)\\n\\tat io.trino.operator.HttpPageBufferClient$1.onSuccess(HttpPageBufferClient.java:436)\\n\\tat io.trino.operator.HttpPageBufferClient$1.onSuccess(HttpPageBufferClient.java:366)\\n\\tat com.google.common.util.concurrent.Futures$CallbackListener.run(Futures.java:1126)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1090)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:614)\\n\\tat java.base/java.lang.Thread.run(Thread.java:1474)\\n\\nDriver stacktrace:\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\tat scala.Option.getOrElse(Option.scala:201)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\tat scala.Option.foreach(Option.scala:437)\\n\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\tat scala.util.Try$.apply(Try.scala:217)\\n\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\tat org.apache.spark.util.Utils$.getTryWithCallerStacktrace(Utils.scala:1439)\\n\\tat org.apache.spark.util.LazyTry.get(LazyTry.scala:58)\\n\\tat org.apache.spark.sql.execution.QueryExecution.commandExecuted(QueryExecution.scala:131)\\n\\tat org.apache.spark.sql.execution.QueryExecution.assertCommandExecuted(QueryExecution.scala:192)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.runCommand(DataFrameWriter.scala:622)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveToV1Source(DataFrameWriter.scala:273)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveInternal(DataFrameWriter.scala:182)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.save(DataFrameWriter.scala:118)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)\\n\\tat java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\\n\\tat java.base/java.lang.reflect.Method.invoke(Method.java:569)\\n\\tat py4j.reflection.MethodInvoker.invoke(MethodInvoker.java:244)\\n\\tat py4j.reflection.ReflectionEngine.invoke(ReflectionEngine.java:374)\\n\\tat py4j.Gateway.invoke(Gateway.java:282)\\n\\tat py4j.commands.AbstractCommand.invokeMethod(AbstractCommand.java:132)\\n\\tat py4j.commands.CallCommand.execute(CallCommand.java:79)\\n\\tat py4j.ClientServerConnection.waitForCommands(ClientServerConnection.java:184)\\n\\tat py4j.ClientServerConnection.run(ClientServerConnection.java:108)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\n\\tSuppressed: org.apache.spark.util.Utils$OriginalTryStackTraceException: Full stacktrace of original doTryWithCallerStacktrace caller\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\t\\tat scala.Option.getOrElse(Option.scala:201)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\t\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\t\\tat scala.Option.foreach(Option.scala:437)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\t\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\t\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\t\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\t\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\t\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\t\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\t\\tat scala.util.Try$.apply(Try.scala:217)\\n\\t\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT$lzycompute(LazyTry.scala:46)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT(LazyTry.scala:46)\\n\\t\\t... 19 more\\n"}, {"group_name": "part_cdi_-_centro_de_diagnostico_por_imagem_joined_0", "connection_name": "CDI - Centro de Diagn\\u00f3stico por Imagem", "status": "failed", "output_path": null, "rows_ingested": null, "execution_time_seconds": 17.420829, "error_message": "An error occurred while calling o869.save.\\n: org.apache.spark.SparkException: Job aborted due to stage failure: Task 0 in stage 16.0 failed 4 times, most recent failure: Lost task 0.3 in stage 16.0 (TID 166) (172.18.0.10 executor 0): org.apache.spark.SparkException: [TASK_WRITE_FAILED] Task failed while writing rows to s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_cdi_-_centro_de_diagnostico_por_imagem. SQLSTATE: 58030\\n\\tat org.apache.spark.sql.errors.QueryExecutionErrors$.taskFailedWhileWritingRowsError(QueryExecutionErrors.scala:772)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeTask(DeltaFileFormatWriter.scala:469)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$3(DeltaFileFormatWriter.scala:281)\\n\\tat org.apache.spark.scheduler.ResultTask.runTask(ResultTask.scala:93)\\n\\tat org.apache.spark.TaskContext.runTaskWithListeners(TaskContext.scala:171)\\n\\tat org.apache.spark.scheduler.Task.run(Task.scala:147)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.$anonfun$run$5(Executor.scala:647)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally(SparkErrorUtils.scala:80)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally$(SparkErrorUtils.scala:77)\\n\\tat org.apache.spark.util.Utils$.tryWithSafeFinally(Utils.scala:99)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.run(Executor.scala:650)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\nCaused by: java.sql.SQLException: Query failed (#20260611_021419_00069_62huf): Query exceeded per-node memory limit of 307.20MB [Allocated: 306.74MB, Delta: 922.88kB, Top Consumers: {HashBuilderOperator=253.88MB, ExchangeOperator=34.57MB, LazyOutputBuffer=18.00MB}]\\n\\tat io.trino.jdbc.ResultUtils.resultsException(ResultUtils.java:33)\\n\\tat io.trino.jdbc.AsyncResultIterator.lambda$new$1(AsyncResultIterator.java:94)\\n\\tat java.base/java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:539)\\n\\tat java.base/java.util.concurrent.FutureTask.run(FutureTask.java:264)\\n\\t... 3 more\\nCaused by: io.trino.ExceededMemoryLimitException: Query exceeded per-node memory limit of 307.20MB [Allocated: 306.74MB, Delta: 922.88kB, Top Consumers: {HashBuilderOperator=253.88MB, ExchangeOperator=34.57MB, LazyOutputBuffer=18.00MB}]\\n\\tat io.trino.ExceededMemoryLimitException.exceededLocalUserMemoryLimit(ExceededMemoryLimitException.java:41)\\n\\tat io.trino.memory.QueryContext.enforceUserMemoryLimit(QueryContext.java:333)\\n\\tat io.trino.memory.QueryContext.updateUserMemory(QueryContext.java:166)\\n\\tat io.trino.memory.QueryContext.lambda$addTaskContext$0(QueryContext.java:252)\\n\\tat io.trino.memory.QueryContext$QueryMemoryReservationHandler.reserveMemory(QueryContext.java:314)\\n\\tat io.trino.memory.context.RootAggregatedMemoryContext.updateBytes(RootAggregatedMemoryContext.java:37)\\n\\tat io.trino.memory.context.ChildAggregatedMemoryContext.updateBytes(ChildAggregatedMemoryContext.java:38)\\n\\tat io.trino.memory.context.SimpleLocalMemoryContext.setBytes(SimpleLocalMemoryContext.java:65)\\n\\tat io.trino.operator.DirectExchangeClient.updateRetainedMemory(DirectExchangeClient.java:368)\\n\\tat io.trino.operator.DirectExchangeClient.addPages(DirectExchangeClient.java:347)\\n\\tat io.trino.operator.DirectExchangeClient$ExchangeClientCallback.addPages(DirectExchangeClient.java:431)\\n\\tat io.trino.operator.HttpPageBufferClient$1.onSuccess(HttpPageBufferClient.java:436)\\n\\tat io.trino.operator.HttpPageBufferClient$1.onSuccess(HttpPageBufferClient.java:366)\\n\\tat com.google.common.util.concurrent.Futures$CallbackListener.run(Futures.java:1126)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1090)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:614)\\n\\tat java.base/java.lang.Thread.run(Thread.java:1474)\\n\\nDriver stacktrace:\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\tat scala.Option.getOrElse(Option.scala:201)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\tat scala.Option.foreach(Option.scala:437)\\n\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\tat scala.util.Try$.apply(Try.scala:217)\\n\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\tat org.apache.spark.util.Utils$.getTryWithCallerStacktrace(Utils.scala:1439)\\n\\tat org.apache.spark.util.LazyTry.get(LazyTry.scala:58)\\n\\tat org.apache.spark.sql.execution.QueryExecution.commandExecuted(QueryExecution.scala:131)\\n\\tat org.apache.spark.sql.execution.QueryExecution.assertCommandExecuted(QueryExecution.scala:192)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.runCommand(DataFrameWriter.scala:622)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveToV1Source(DataFrameWriter.scala:273)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveInternal(DataFrameWriter.scala:182)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.save(DataFrameWriter.scala:118)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)\\n\\tat java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\\n\\tat java.base/java.lang.reflect.Method.invoke(Method.java:569)\\n\\tat py4j.reflection.MethodInvoker.invoke(MethodInvoker.java:244)\\n\\tat py4j.reflection.ReflectionEngine.invoke(ReflectionEngine.java:374)\\n\\tat py4j.Gateway.invoke(Gateway.java:282)\\n\\tat py4j.commands.AbstractCommand.invokeMethod(AbstractCommand.java:132)\\n\\tat py4j.commands.CallCommand.execute(CallCommand.java:79)\\n\\tat py4j.ClientServerConnection.waitForCommands(ClientServerConnection.java:184)\\n\\tat py4j.ClientServerConnection.run(ClientServerConnection.java:108)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\n\\tSuppressed: org.apache.spark.util.Utils$OriginalTryStackTraceException: Full stacktrace of original doTryWithCallerStacktrace caller\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\t\\tat scala.Option.getOrElse(Option.scala:201)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\t\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\t\\tat scala.Option.foreach(Option.scala:437)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\t\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\t\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\t\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\t\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\t\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\t\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\t\\tat scala.util.Try$.apply(Try.scala:217)\\n\\t\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT$lzycompute(LazyTry.scala:46)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT(LazyTry.scala:46)\\n\\t\\t... 19 more\\n"}]	0	[]	\N	\N	0	{}	0	overwrite	\N	\N	\N	\N	\N	f	{"name": "Bronze REH-CDI-RFA 21tab [federated=FALSE]", "description": "21 tabelas id\\u00eanticas (sem programa_adesao). federated=False.", "tables": [{"table_id": 41, "select_all": true, "column_ids": null}, {"table_id": 42, "select_all": true, "column_ids": null}, {"table_id": 43, "select_all": true, "column_ids": null}, {"table_id": 44, "select_all": true, "column_ids": null}, {"table_id": 45, "select_all": true, "column_ids": null}, {"table_id": 46, "select_all": true, "column_ids": null}, {"table_id": 47, "select_all": true, "column_ids": null}, {"table_id": 48, "select_all": true, "column_ids": null}, {"table_id": 64, "select_all": true, "column_ids": null}, {"table_id": 65, "select_all": true, "column_ids": null}, {"table_id": 66, "select_all": true, "column_ids": null}, {"table_id": 67, "select_all": true, "column_ids": null}, {"table_id": 68, "select_all": true, "column_ids": null}, {"table_id": 77, "select_all": true, "column_ids": null}, {"table_id": 78, "select_all": true, "column_ids": null}, {"table_id": 49, "select_all": true, "column_ids": null}, {"table_id": 51, "select_all": true, "column_ids": null}, {"table_id": 52, "select_all": true, "column_ids": null}, {"table_id": 53, "select_all": true, "column_ids": null}, {"table_id": 54, "select_all": true, "column_ids": null}, {"table_id": 55, "select_all": true, "column_ids": null}], "relationship_ids": null, "enable_federated_joins": false, "output_format": "delta", "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "write_mode": "overwrite", "merge_keys": null, "merge_keys_source": null, "properties": {}, "snapshot_at": "2026-06-11T02:13:22.256519"}	2026-06-11 02:13:22.254609	2026-06-11 02:14:23.205021	\N	\N	t
6	11	FAILED	2026-06-11 02:18:20.265079+00	2026-06-11 02:20:00.637438+00	[{"group_name": "part_reh_-_rede_de_emergencias_hospitalares_joined_0", "connection_name": "REH - Rede de Emerg\\u00eancias Hospitalares", "status": "failed", "output_path": null, "rows_ingested": null, "execution_time_seconds": 36.330708, "error_message": "An error occurred while calling o1218.save.\\n: org.apache.spark.SparkException: Job aborted due to stage failure: Task 0 in stage 17.0 failed 4 times, most recent failure: Lost task 0.3 in stage 17.0 (TID 170) (172.18.0.10 executor 0): org.apache.spark.SparkException: [TASK_WRITE_FAILED] Task failed while writing rows to s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_reh_-_rede_de_emergencias_hospitalares. SQLSTATE: 58030\\n\\tat org.apache.spark.sql.errors.QueryExecutionErrors$.taskFailedWhileWritingRowsError(QueryExecutionErrors.scala:772)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeTask(DeltaFileFormatWriter.scala:469)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$3(DeltaFileFormatWriter.scala:281)\\n\\tat org.apache.spark.scheduler.ResultTask.runTask(ResultTask.scala:93)\\n\\tat org.apache.spark.TaskContext.runTaskWithListeners(TaskContext.scala:171)\\n\\tat org.apache.spark.scheduler.Task.run(Task.scala:147)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.$anonfun$run$5(Executor.scala:647)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally(SparkErrorUtils.scala:80)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally$(SparkErrorUtils.scala:77)\\n\\tat org.apache.spark.util.Utils$.tryWithSafeFinally(Utils.scala:99)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.run(Executor.scala:650)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\nCaused by: java.sql.SQLException: Query failed (#20260611_021854_00018_xgfce): Query exceeded per-node memory limit of 1GB [Allocated: 1023.44MB, Delta: 1.20MB, Top Consumers: {HashBuilderOperator=901.31MB, ExchangeOperator=68.76MB, LazyOutputBuffer=53.03MB}]\\n\\tat io.trino.jdbc.ResultUtils.resultsException(ResultUtils.java:33)\\n\\tat io.trino.jdbc.AsyncResultIterator.lambda$new$1(AsyncResultIterator.java:94)\\n\\tat java.base/java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:539)\\n\\tat java.base/java.util.concurrent.FutureTask.run(FutureTask.java:264)\\n\\t... 3 more\\nCaused by: io.trino.ExceededMemoryLimitException: Query exceeded per-node memory limit of 1GB [Allocated: 1023.44MB, Delta: 1.20MB, Top Consumers: {HashBuilderOperator=901.31MB, ExchangeOperator=68.76MB, LazyOutputBuffer=53.03MB}]\\n\\tat io.trino.ExceededMemoryLimitException.exceededLocalUserMemoryLimit(ExceededMemoryLimitException.java:41)\\n\\tat io.trino.memory.QueryContext.enforceUserMemoryLimit(QueryContext.java:333)\\n\\tat io.trino.memory.QueryContext.updateUserMemory(QueryContext.java:166)\\n\\tat io.trino.memory.QueryContext.lambda$addTaskContext$0(QueryContext.java:252)\\n\\tat io.trino.memory.QueryContext$QueryMemoryReservationHandler.reserveMemory(QueryContext.java:314)\\n\\tat io.trino.memory.context.RootAggregatedMemoryContext.updateBytes(RootAggregatedMemoryContext.java:37)\\n\\tat io.trino.memory.context.SimpleLocalMemoryContext.setBytes(SimpleLocalMemoryContext.java:65)\\n\\tat io.trino.execution.buffer.OutputBufferMemoryManager.updateMemoryUsage(OutputBufferMemoryManager.java:108)\\n\\tat io.trino.execution.buffer.PartitionedOutputBuffer.enqueue(PartitionedOutputBuffer.java:207)\\n\\tat io.trino.execution.buffer.LazyOutputBuffer.enqueue(LazyOutputBuffer.java:277)\\n\\tat io.trino.operator.output.PagePartitioner.enqueuePage(PagePartitioner.java:487)\\n\\tat io.trino.operator.output.PagePartitioner.flushPositionsAppenders(PagePartitioner.java:479)\\n\\tat io.trino.operator.output.PagePartitioner.partitionPage(PagePartitioner.java:160)\\n\\tat io.trino.operator.output.PartitionedOutputOperator.addInput(PartitionedOutputOperator.java:339)\\n\\tat io.trino.operator.Driver.processInternal(Driver.java:408)\\n\\tat io.trino.operator.Driver.lambda$process$0(Driver.java:306)\\n\\tat io.trino.operator.Driver.tryWithLock(Driver.java:709)\\n\\tat io.trino.operator.Driver.process(Driver.java:298)\\n\\tat io.trino.operator.Driver.processForDuration(Driver.java:269)\\n\\tat io.trino.execution.SqlTaskExecution$DriverSplitRunner.processFor(SqlTaskExecution.java:852)\\n\\tat io.trino.execution.executor.dedicated.SplitProcessor.run(SplitProcessor.java:77)\\n\\tat io.trino.execution.executor.dedicated.TaskEntry$VersionEmbedderBridge.lambda$run$0(TaskEntry.java:205)\\n\\tat io.trino.$gen.Trino_481____20260611_021800_2.run(Unknown Source)\\n\\tat io.trino.execution.executor.dedicated.TaskEntry$VersionEmbedderBridge.run(TaskEntry.java:206)\\n\\tat io.trino.execution.executor.scheduler.FairScheduler.runTask(FairScheduler.java:177)\\n\\tat io.trino.execution.executor.scheduler.FairScheduler.lambda$submit$0(FairScheduler.java:164)\\n\\tat java.base/java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:545)\\n\\tat com.google.common.util.concurrent.TrustedListenableFutureTask$TrustedFutureInterruptibleTask.runInterruptibly(TrustedListenableFutureTask.java:128)\\n\\tat com.google.common.util.concurrent.InterruptibleTask.run(InterruptibleTask.java:74)\\n\\tat com.google.common.util.concurrent.TrustedListenableFutureTask.run(TrustedListenableFutureTask.java:80)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1090)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:614)\\n\\tat java.base/java.lang.Thread.run(Thread.java:1474)\\n\\nDriver stacktrace:\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\tat scala.Option.getOrElse(Option.scala:201)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\tat scala.Option.foreach(Option.scala:437)\\n\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\tat scala.util.Try$.apply(Try.scala:217)\\n\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\tat org.apache.spark.util.Utils$.getTryWithCallerStacktrace(Utils.scala:1439)\\n\\tat org.apache.spark.util.LazyTry.get(LazyTry.scala:58)\\n\\tat org.apache.spark.sql.execution.QueryExecution.commandExecuted(QueryExecution.scala:131)\\n\\tat org.apache.spark.sql.execution.QueryExecution.assertCommandExecuted(QueryExecution.scala:192)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.runCommand(DataFrameWriter.scala:622)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveToV1Source(DataFrameWriter.scala:273)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveInternal(DataFrameWriter.scala:182)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.save(DataFrameWriter.scala:118)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)\\n\\tat java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\\n\\tat java.base/java.lang.reflect.Method.invoke(Method.java:569)\\n\\tat py4j.reflection.MethodInvoker.invoke(MethodInvoker.java:244)\\n\\tat py4j.reflection.ReflectionEngine.invoke(ReflectionEngine.java:374)\\n\\tat py4j.Gateway.invoke(Gateway.java:282)\\n\\tat py4j.commands.AbstractCommand.invokeMethod(AbstractCommand.java:132)\\n\\tat py4j.commands.CallCommand.execute(CallCommand.java:79)\\n\\tat py4j.ClientServerConnection.waitForCommands(ClientServerConnection.java:184)\\n\\tat py4j.ClientServerConnection.run(ClientServerConnection.java:108)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\n\\tSuppressed: org.apache.spark.util.Utils$OriginalTryStackTraceException: Full stacktrace of original doTryWithCallerStacktrace caller\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\t\\tat scala.Option.getOrElse(Option.scala:201)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\t\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\t\\tat scala.Option.foreach(Option.scala:437)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\t\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\t\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\t\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\t\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\t\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\t\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\t\\tat scala.util.Try$.apply(Try.scala:217)\\n\\t\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT$lzycompute(LazyTry.scala:46)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT(LazyTry.scala:46)\\n\\t\\t... 19 more\\n"}, {"group_name": "part_rfa_-_rede_de_farmacias_e_adesao_joined_0", "connection_name": "RFA - Rede de Farm\\u00e1cias e Ades\\u00e3o", "status": "failed", "output_path": null, "rows_ingested": null, "execution_time_seconds": 33.271499, "error_message": "An error occurred while calling o1233.save.\\n: org.apache.spark.SparkException: Job aborted due to stage failure: Task 0 in stage 18.0 failed 4 times, most recent failure: Lost task 0.3 in stage 18.0 (TID 174) (172.18.0.10 executor 0): org.apache.spark.SparkException: [TASK_WRITE_FAILED] Task failed while writing rows to s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_rfa_-_rede_de_farmacias_e_adesao. SQLSTATE: 58030\\n\\tat org.apache.spark.sql.errors.QueryExecutionErrors$.taskFailedWhileWritingRowsError(QueryExecutionErrors.scala:772)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeTask(DeltaFileFormatWriter.scala:469)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$3(DeltaFileFormatWriter.scala:281)\\n\\tat org.apache.spark.scheduler.ResultTask.runTask(ResultTask.scala:93)\\n\\tat org.apache.spark.TaskContext.runTaskWithListeners(TaskContext.scala:171)\\n\\tat org.apache.spark.scheduler.Task.run(Task.scala:147)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.$anonfun$run$5(Executor.scala:647)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally(SparkErrorUtils.scala:80)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally$(SparkErrorUtils.scala:77)\\n\\tat org.apache.spark.util.Utils$.tryWithSafeFinally(Utils.scala:99)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.run(Executor.scala:650)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\nCaused by: java.sql.SQLException: Query failed (#20260611_021927_00028_xgfce): Query exceeded per-node memory limit of 1GB [Allocated: 1023.10MB, Delta: 1.20MB, Top Consumers: {HashBuilderOperator=956.88MB, LazyOutputBuffer=33.60MB, ExchangeOperator=32.42MB}]\\n\\tat io.trino.jdbc.ResultUtils.resultsException(ResultUtils.java:33)\\n\\tat io.trino.jdbc.AsyncResultIterator.lambda$new$1(AsyncResultIterator.java:94)\\n\\tat java.base/java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:539)\\n\\tat java.base/java.util.concurrent.FutureTask.run(FutureTask.java:264)\\n\\t... 3 more\\nCaused by: io.trino.ExceededMemoryLimitException: Query exceeded per-node memory limit of 1GB [Allocated: 1023.10MB, Delta: 1.20MB, Top Consumers: {HashBuilderOperator=956.88MB, LazyOutputBuffer=33.60MB, ExchangeOperator=32.42MB}]\\n\\tat io.trino.ExceededMemoryLimitException.exceededLocalUserMemoryLimit(ExceededMemoryLimitException.java:41)\\n\\tat io.trino.memory.QueryContext.enforceUserMemoryLimit(QueryContext.java:333)\\n\\tat io.trino.memory.QueryContext.updateUserMemory(QueryContext.java:166)\\n\\tat io.trino.memory.QueryContext.lambda$addTaskContext$0(QueryContext.java:252)\\n\\tat io.trino.memory.QueryContext$QueryMemoryReservationHandler.reserveMemory(QueryContext.java:314)\\n\\tat io.trino.memory.context.RootAggregatedMemoryContext.updateBytes(RootAggregatedMemoryContext.java:37)\\n\\tat io.trino.memory.context.SimpleLocalMemoryContext.setBytes(SimpleLocalMemoryContext.java:65)\\n\\tat io.trino.execution.buffer.OutputBufferMemoryManager.updateMemoryUsage(OutputBufferMemoryManager.java:108)\\n\\tat io.trino.execution.buffer.PartitionedOutputBuffer.enqueue(PartitionedOutputBuffer.java:207)\\n\\tat io.trino.execution.buffer.LazyOutputBuffer.enqueue(LazyOutputBuffer.java:277)\\n\\tat io.trino.operator.output.PagePartitioner.enqueuePage(PagePartitioner.java:487)\\n\\tat io.trino.operator.output.PagePartitioner.flushPositionsAppenders(PagePartitioner.java:479)\\n\\tat io.trino.operator.output.PagePartitioner.partitionPage(PagePartitioner.java:160)\\n\\tat io.trino.operator.output.PartitionedOutputOperator.addInput(PartitionedOutputOperator.java:339)\\n\\tat io.trino.operator.Driver.processInternal(Driver.java:408)\\n\\tat io.trino.operator.Driver.lambda$process$0(Driver.java:306)\\n\\tat io.trino.operator.Driver.tryWithLock(Driver.java:709)\\n\\tat io.trino.operator.Driver.process(Driver.java:298)\\n\\tat io.trino.operator.Driver.processForDuration(Driver.java:269)\\n\\tat io.trino.execution.SqlTaskExecution$DriverSplitRunner.processFor(SqlTaskExecution.java:852)\\n\\tat io.trino.execution.executor.dedicated.SplitProcessor.run(SplitProcessor.java:77)\\n\\tat io.trino.execution.executor.dedicated.TaskEntry$VersionEmbedderBridge.lambda$run$0(TaskEntry.java:205)\\n\\tat io.trino.$gen.Trino_481____20260611_021800_2.run(Unknown Source)\\n\\tat io.trino.execution.executor.dedicated.TaskEntry$VersionEmbedderBridge.run(TaskEntry.java:206)\\n\\tat io.trino.execution.executor.scheduler.FairScheduler.runTask(FairScheduler.java:177)\\n\\tat io.trino.execution.executor.scheduler.FairScheduler.lambda$submit$0(FairScheduler.java:164)\\n\\tat java.base/java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:545)\\n\\tat com.google.common.util.concurrent.TrustedListenableFutureTask$TrustedFutureInterruptibleTask.runInterruptibly(TrustedListenableFutureTask.java:128)\\n\\tat com.google.common.util.concurrent.InterruptibleTask.run(InterruptibleTask.java:74)\\n\\tat com.google.common.util.concurrent.TrustedListenableFutureTask.run(TrustedListenableFutureTask.java:80)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1090)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:614)\\n\\tat java.base/java.lang.Thread.run(Thread.java:1474)\\n\\nDriver stacktrace:\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\tat scala.Option.getOrElse(Option.scala:201)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\tat scala.Option.foreach(Option.scala:437)\\n\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\tat scala.util.Try$.apply(Try.scala:217)\\n\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\tat org.apache.spark.util.Utils$.getTryWithCallerStacktrace(Utils.scala:1439)\\n\\tat org.apache.spark.util.LazyTry.get(LazyTry.scala:58)\\n\\tat org.apache.spark.sql.execution.QueryExecution.commandExecuted(QueryExecution.scala:131)\\n\\tat org.apache.spark.sql.execution.QueryExecution.assertCommandExecuted(QueryExecution.scala:192)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.runCommand(DataFrameWriter.scala:622)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveToV1Source(DataFrameWriter.scala:273)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveInternal(DataFrameWriter.scala:182)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.save(DataFrameWriter.scala:118)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)\\n\\tat java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\\n\\tat java.base/java.lang.reflect.Method.invoke(Method.java:569)\\n\\tat py4j.reflection.MethodInvoker.invoke(MethodInvoker.java:244)\\n\\tat py4j.reflection.ReflectionEngine.invoke(ReflectionEngine.java:374)\\n\\tat py4j.Gateway.invoke(Gateway.java:282)\\n\\tat py4j.commands.AbstractCommand.invokeMethod(AbstractCommand.java:132)\\n\\tat py4j.commands.CallCommand.execute(CallCommand.java:79)\\n\\tat py4j.ClientServerConnection.waitForCommands(ClientServerConnection.java:184)\\n\\tat py4j.ClientServerConnection.run(ClientServerConnection.java:108)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\n\\tSuppressed: org.apache.spark.util.Utils$OriginalTryStackTraceException: Full stacktrace of original doTryWithCallerStacktrace caller\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\t\\tat scala.Option.getOrElse(Option.scala:201)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\t\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\t\\tat scala.Option.foreach(Option.scala:437)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\t\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\t\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\t\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\t\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\t\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\t\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\t\\tat scala.util.Try$.apply(Try.scala:217)\\n\\t\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT$lzycompute(LazyTry.scala:46)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT(LazyTry.scala:46)\\n\\t\\t... 19 more\\n"}, {"group_name": "part_cdi_-_centro_de_diagnostico_por_imagem_joined_0", "connection_name": "CDI - Centro de Diagn\\u00f3stico por Imagem", "status": "failed", "output_path": null, "rows_ingested": null, "execution_time_seconds": 25.392536, "error_message": "An error occurred while calling o1248.save.\\n: org.apache.spark.SparkException: Job aborted due to stage failure: Task 0 in stage 19.0 failed 4 times, most recent failure: Lost task 0.3 in stage 19.0 (TID 178) (172.18.0.10 executor 0): org.apache.spark.SparkException: [TASK_WRITE_FAILED] Task failed while writing rows to s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_cdi_-_centro_de_diagnostico_por_imagem. SQLSTATE: 58030\\n\\tat org.apache.spark.sql.errors.QueryExecutionErrors$.taskFailedWhileWritingRowsError(QueryExecutionErrors.scala:772)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeTask(DeltaFileFormatWriter.scala:469)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$3(DeltaFileFormatWriter.scala:281)\\n\\tat org.apache.spark.scheduler.ResultTask.runTask(ResultTask.scala:93)\\n\\tat org.apache.spark.TaskContext.runTaskWithListeners(TaskContext.scala:171)\\n\\tat org.apache.spark.scheduler.Task.run(Task.scala:147)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.$anonfun$run$5(Executor.scala:647)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally(SparkErrorUtils.scala:80)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally$(SparkErrorUtils.scala:77)\\n\\tat org.apache.spark.util.Utils$.tryWithSafeFinally(Utils.scala:99)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.run(Executor.scala:650)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\nCaused by: java.sql.SQLException: Query failed (#20260611_021954_00038_xgfce): Query exceeded per-node memory limit of 1GB [Allocated: 1023.46MB, Delta: 922.89kB, Top Consumers: {HashBuilderOperator=955.63MB, LazyOutputBuffer=34.80MB, ExchangeOperator=32.74MB}]\\n\\tat io.trino.jdbc.ResultUtils.resultsException(ResultUtils.java:33)\\n\\tat io.trino.jdbc.AsyncResultIterator.lambda$new$1(AsyncResultIterator.java:94)\\n\\tat java.base/java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:539)\\n\\tat java.base/java.util.concurrent.FutureTask.run(FutureTask.java:264)\\n\\t... 3 more\\nCaused by: io.trino.ExceededMemoryLimitException: Query exceeded per-node memory limit of 1GB [Allocated: 1023.46MB, Delta: 922.89kB, Top Consumers: {HashBuilderOperator=955.63MB, LazyOutputBuffer=34.80MB, ExchangeOperator=32.74MB}]\\n\\tat io.trino.ExceededMemoryLimitException.exceededLocalUserMemoryLimit(ExceededMemoryLimitException.java:41)\\n\\tat io.trino.memory.QueryContext.enforceUserMemoryLimit(QueryContext.java:333)\\n\\tat io.trino.memory.QueryContext.updateUserMemory(QueryContext.java:166)\\n\\tat io.trino.memory.QueryContext.lambda$addTaskContext$0(QueryContext.java:252)\\n\\tat io.trino.memory.QueryContext$QueryMemoryReservationHandler.reserveMemory(QueryContext.java:314)\\n\\tat io.trino.memory.context.RootAggregatedMemoryContext.updateBytes(RootAggregatedMemoryContext.java:37)\\n\\tat io.trino.memory.context.ChildAggregatedMemoryContext.updateBytes(ChildAggregatedMemoryContext.java:38)\\n\\tat io.trino.memory.context.SimpleLocalMemoryContext.setBytes(SimpleLocalMemoryContext.java:65)\\n\\tat io.trino.operator.DirectExchangeClient.updateRetainedMemory(DirectExchangeClient.java:368)\\n\\tat io.trino.operator.DirectExchangeClient.addPages(DirectExchangeClient.java:347)\\n\\tat io.trino.operator.DirectExchangeClient$ExchangeClientCallback.addPages(DirectExchangeClient.java:431)\\n\\tat io.trino.operator.HttpPageBufferClient$1.onSuccess(HttpPageBufferClient.java:436)\\n\\tat io.trino.operator.HttpPageBufferClient$1.onSuccess(HttpPageBufferClient.java:366)\\n\\tat com.google.common.util.concurrent.Futures$CallbackListener.run(Futures.java:1126)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1090)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:614)\\n\\tat java.base/java.lang.Thread.run(Thread.java:1474)\\n\\nDriver stacktrace:\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\tat scala.Option.getOrElse(Option.scala:201)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\tat scala.Option.foreach(Option.scala:437)\\n\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\tat scala.util.Try$.apply(Try.scala:217)\\n\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\tat org.apache.spark.util.Utils$.getTryWithCallerStacktrace(Utils.scala:1439)\\n\\tat org.apache.spark.util.LazyTry.get(LazyTry.scala:58)\\n\\tat org.apache.spark.sql.execution.QueryExecution.commandExecuted(QueryExecution.scala:131)\\n\\tat org.apache.spark.sql.execution.QueryExecution.assertCommandExecuted(QueryExecution.scala:192)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.runCommand(DataFrameWriter.scala:622)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveToV1Source(DataFrameWriter.scala:273)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveInternal(DataFrameWriter.scala:182)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.save(DataFrameWriter.scala:118)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)\\n\\tat java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\\n\\tat java.base/java.lang.reflect.Method.invoke(Method.java:569)\\n\\tat py4j.reflection.MethodInvoker.invoke(MethodInvoker.java:244)\\n\\tat py4j.reflection.ReflectionEngine.invoke(ReflectionEngine.java:374)\\n\\tat py4j.Gateway.invoke(Gateway.java:282)\\n\\tat py4j.commands.AbstractCommand.invokeMethod(AbstractCommand.java:132)\\n\\tat py4j.commands.CallCommand.execute(CallCommand.java:79)\\n\\tat py4j.ClientServerConnection.waitForCommands(ClientServerConnection.java:184)\\n\\tat py4j.ClientServerConnection.run(ClientServerConnection.java:108)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\n\\tSuppressed: org.apache.spark.util.Utils$OriginalTryStackTraceException: Full stacktrace of original doTryWithCallerStacktrace caller\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\t\\tat scala.Option.getOrElse(Option.scala:201)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\t\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\t\\tat scala.Option.foreach(Option.scala:437)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\t\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\t\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\t\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\t\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\t\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\t\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\t\\tat scala.util.Try$.apply(Try.scala:217)\\n\\t\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT$lzycompute(LazyTry.scala:46)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT(LazyTry.scala:46)\\n\\t\\t... 19 more\\n"}]	0	[]	\N	\N	1	{}	1	overwrite	\N	\N	\N	\N	\N	f	{"name": "Bronze REH-CDI-RFA 21tab [federated=FALSE]", "description": "21 tabelas id\\u00eanticas (sem programa_adesao). federated=False.", "tables": [{"table_id": 41, "select_all": true, "column_ids": null}, {"table_id": 42, "select_all": true, "column_ids": null}, {"table_id": 43, "select_all": true, "column_ids": null}, {"table_id": 44, "select_all": true, "column_ids": null}, {"table_id": 45, "select_all": true, "column_ids": null}, {"table_id": 46, "select_all": true, "column_ids": null}, {"table_id": 47, "select_all": true, "column_ids": null}, {"table_id": 48, "select_all": true, "column_ids": null}, {"table_id": 64, "select_all": true, "column_ids": null}, {"table_id": 65, "select_all": true, "column_ids": null}, {"table_id": 66, "select_all": true, "column_ids": null}, {"table_id": 67, "select_all": true, "column_ids": null}, {"table_id": 68, "select_all": true, "column_ids": null}, {"table_id": 77, "select_all": true, "column_ids": null}, {"table_id": 78, "select_all": true, "column_ids": null}, {"table_id": 49, "select_all": true, "column_ids": null}, {"table_id": 51, "select_all": true, "column_ids": null}, {"table_id": 52, "select_all": true, "column_ids": null}, {"table_id": 53, "select_all": true, "column_ids": null}, {"table_id": 54, "select_all": true, "column_ids": null}, {"table_id": 55, "select_all": true, "column_ids": null}], "relationship_ids": null, "enable_federated_joins": false, "output_format": "delta", "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "write_mode": "overwrite", "merge_keys": null, "merge_keys_source": null, "properties": {}, "snapshot_at": "2026-06-11T02:18:20.265044"}	2026-06-11 02:18:20.26341	2026-06-11 02:20:00.637923	\N	\N	t
7	11	FAILED	2026-06-11 02:27:16.920991+00	2026-06-11 02:29:44.449225+00	[{"group_name": "part_reh_-_rede_de_emergencias_hospitalares_joined_0", "connection_name": "REH - Rede de Emerg\\u00eancias Hospitalares", "status": "failed", "output_path": null, "rows_ingested": null, "execution_time_seconds": 49.258744, "error_message": "An error occurred while calling o1597.save.\\n: org.apache.spark.SparkException: Job aborted due to stage failure: Task 0 in stage 20.0 failed 4 times, most recent failure: Lost task 0.3 in stage 20.0 (TID 182) (172.18.0.10 executor 0): org.apache.spark.SparkException: [TASK_WRITE_FAILED] Task failed while writing rows to s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_reh_-_rede_de_emergencias_hospitalares. SQLSTATE: 58030\\n\\tat org.apache.spark.sql.errors.QueryExecutionErrors$.taskFailedWhileWritingRowsError(QueryExecutionErrors.scala:772)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeTask(DeltaFileFormatWriter.scala:469)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$3(DeltaFileFormatWriter.scala:281)\\n\\tat org.apache.spark.scheduler.ResultTask.runTask(ResultTask.scala:93)\\n\\tat org.apache.spark.TaskContext.runTaskWithListeners(TaskContext.scala:171)\\n\\tat org.apache.spark.scheduler.Task.run(Task.scala:147)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.$anonfun$run$5(Executor.scala:647)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally(SparkErrorUtils.scala:80)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally$(SparkErrorUtils.scala:77)\\n\\tat org.apache.spark.util.Utils$.tryWithSafeFinally(Utils.scala:99)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.run(Executor.scala:650)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\nCaused by: java.sql.SQLException: Query failed (#20260611_022800_00018_6jyw7): Query exceeded per-node memory limit of 1.50GB [Allocated: 1.50GB, Delta: 845.52kB, Top Consumers: {HashBuilderOperator=1.37GB, LazyOutputBuffer=69.83MB, ExchangeOperator=66.65MB}]\\n\\tat io.trino.jdbc.ResultUtils.resultsException(ResultUtils.java:33)\\n\\tat io.trino.jdbc.AsyncResultIterator.lambda$new$1(AsyncResultIterator.java:94)\\n\\tat java.base/java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:539)\\n\\tat java.base/java.util.concurrent.FutureTask.run(FutureTask.java:264)\\n\\t... 3 more\\nCaused by: io.trino.ExceededMemoryLimitException: Query exceeded per-node memory limit of 1.50GB [Allocated: 1.50GB, Delta: 845.52kB, Top Consumers: {HashBuilderOperator=1.37GB, LazyOutputBuffer=69.83MB, ExchangeOperator=66.65MB}]\\n\\tat io.trino.ExceededMemoryLimitException.exceededLocalUserMemoryLimit(ExceededMemoryLimitException.java:41)\\n\\tat io.trino.memory.QueryContext.enforceUserMemoryLimit(QueryContext.java:333)\\n\\tat io.trino.memory.QueryContext.updateUserMemory(QueryContext.java:166)\\n\\tat io.trino.memory.QueryContext.lambda$addTaskContext$0(QueryContext.java:252)\\n\\tat io.trino.memory.QueryContext$QueryMemoryReservationHandler.reserveMemory(QueryContext.java:314)\\n\\tat io.trino.memory.context.RootAggregatedMemoryContext.updateBytes(RootAggregatedMemoryContext.java:37)\\n\\tat io.trino.memory.context.ChildAggregatedMemoryContext.updateBytes(ChildAggregatedMemoryContext.java:38)\\n\\tat io.trino.memory.context.SimpleLocalMemoryContext.setBytes(SimpleLocalMemoryContext.java:65)\\n\\tat io.trino.operator.DirectExchangeClient.updateRetainedMemory(DirectExchangeClient.java:368)\\n\\tat io.trino.operator.DirectExchangeClient.addPages(DirectExchangeClient.java:347)\\n\\tat io.trino.operator.DirectExchangeClient$ExchangeClientCallback.addPages(DirectExchangeClient.java:431)\\n\\tat io.trino.operator.HttpPageBufferClient$1.onSuccess(HttpPageBufferClient.java:436)\\n\\tat io.trino.operator.HttpPageBufferClient$1.onSuccess(HttpPageBufferClient.java:366)\\n\\tat com.google.common.util.concurrent.Futures$CallbackListener.run(Futures.java:1126)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1090)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:614)\\n\\tat java.base/java.lang.Thread.run(Thread.java:1474)\\n\\nDriver stacktrace:\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\tat scala.Option.getOrElse(Option.scala:201)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\tat scala.Option.foreach(Option.scala:437)\\n\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\tat scala.util.Try$.apply(Try.scala:217)\\n\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\tat org.apache.spark.util.Utils$.getTryWithCallerStacktrace(Utils.scala:1439)\\n\\tat org.apache.spark.util.LazyTry.get(LazyTry.scala:58)\\n\\tat org.apache.spark.sql.execution.QueryExecution.commandExecuted(QueryExecution.scala:131)\\n\\tat org.apache.spark.sql.execution.QueryExecution.assertCommandExecuted(QueryExecution.scala:192)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.runCommand(DataFrameWriter.scala:622)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveToV1Source(DataFrameWriter.scala:273)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveInternal(DataFrameWriter.scala:182)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.save(DataFrameWriter.scala:118)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)\\n\\tat java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\\n\\tat java.base/java.lang.reflect.Method.invoke(Method.java:569)\\n\\tat py4j.reflection.MethodInvoker.invoke(MethodInvoker.java:244)\\n\\tat py4j.reflection.ReflectionEngine.invoke(ReflectionEngine.java:374)\\n\\tat py4j.Gateway.invoke(Gateway.java:282)\\n\\tat py4j.commands.AbstractCommand.invokeMethod(AbstractCommand.java:132)\\n\\tat py4j.commands.CallCommand.execute(CallCommand.java:79)\\n\\tat py4j.ClientServerConnection.waitForCommands(ClientServerConnection.java:184)\\n\\tat py4j.ClientServerConnection.run(ClientServerConnection.java:108)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\n\\tSuppressed: org.apache.spark.util.Utils$OriginalTryStackTraceException: Full stacktrace of original doTryWithCallerStacktrace caller\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\t\\tat scala.Option.getOrElse(Option.scala:201)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\t\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\t\\tat scala.Option.foreach(Option.scala:437)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\t\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\t\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\t\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\t\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\t\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\t\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\t\\tat scala.util.Try$.apply(Try.scala:217)\\n\\t\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT$lzycompute(LazyTry.scala:46)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT(LazyTry.scala:46)\\n\\t\\t... 19 more\\n"}, {"group_name": "part_rfa_-_rede_de_farmacias_e_adesao_joined_0", "connection_name": "RFA - Rede de Farm\\u00e1cias e Ades\\u00e3o", "status": "failed", "output_path": null, "rows_ingested": null, "execution_time_seconds": 50.614698, "error_message": "An error occurred while calling o1612.save.\\n: org.apache.spark.SparkException: Job aborted due to stage failure: Task 0 in stage 21.0 failed 4 times, most recent failure: Lost task 0.3 in stage 21.0 (TID 186) (172.18.0.10 executor 0): org.apache.spark.SparkException: [TASK_WRITE_FAILED] Task failed while writing rows to s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_rfa_-_rede_de_farmacias_e_adesao. SQLSTATE: 58030\\n\\tat org.apache.spark.sql.errors.QueryExecutionErrors$.taskFailedWhileWritingRowsError(QueryExecutionErrors.scala:772)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeTask(DeltaFileFormatWriter.scala:469)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$3(DeltaFileFormatWriter.scala:281)\\n\\tat org.apache.spark.scheduler.ResultTask.runTask(ResultTask.scala:93)\\n\\tat org.apache.spark.TaskContext.runTaskWithListeners(TaskContext.scala:171)\\n\\tat org.apache.spark.scheduler.Task.run(Task.scala:147)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.$anonfun$run$5(Executor.scala:647)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally(SparkErrorUtils.scala:80)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally$(SparkErrorUtils.scala:77)\\n\\tat org.apache.spark.util.Utils$.tryWithSafeFinally(Utils.scala:99)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.run(Executor.scala:650)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\nCaused by: java.sql.SQLException: Query failed (#20260611_022849_00028_6jyw7): Query exceeded per-node memory limit of 1.50GB [Allocated: 1.50GB, Delta: 2.31MB, Top Consumers: {HashBuilderOperator=1.44GB, ExchangeOperator=32.42MB, LazyOutputBuffer=32.40MB}]\\n\\tat io.trino.jdbc.ResultUtils.resultsException(ResultUtils.java:33)\\n\\tat io.trino.jdbc.AsyncResultIterator.lambda$new$1(AsyncResultIterator.java:94)\\n\\tat java.base/java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:539)\\n\\tat java.base/java.util.concurrent.FutureTask.run(FutureTask.java:264)\\n\\t... 3 more\\nCaused by: io.trino.ExceededMemoryLimitException: Query exceeded per-node memory limit of 1.50GB [Allocated: 1.50GB, Delta: 2.31MB, Top Consumers: {HashBuilderOperator=1.44GB, ExchangeOperator=32.42MB, LazyOutputBuffer=32.40MB}]\\n\\tat io.trino.ExceededMemoryLimitException.exceededLocalUserMemoryLimit(ExceededMemoryLimitException.java:41)\\n\\tat io.trino.memory.QueryContext.enforceUserMemoryLimit(QueryContext.java:333)\\n\\tat io.trino.memory.QueryContext.updateUserMemory(QueryContext.java:166)\\n\\tat io.trino.memory.QueryContext.lambda$addTaskContext$0(QueryContext.java:252)\\n\\tat io.trino.memory.QueryContext$QueryMemoryReservationHandler.reserveMemory(QueryContext.java:314)\\n\\tat io.trino.memory.context.RootAggregatedMemoryContext.updateBytes(RootAggregatedMemoryContext.java:37)\\n\\tat io.trino.memory.context.ChildAggregatedMemoryContext.updateBytes(ChildAggregatedMemoryContext.java:38)\\n\\tat io.trino.memory.context.ChildAggregatedMemoryContext.updateBytes(ChildAggregatedMemoryContext.java:38)\\n\\tat io.trino.memory.context.ChildAggregatedMemoryContext.updateBytes(ChildAggregatedMemoryContext.java:38)\\n\\tat io.trino.memory.context.SimpleLocalMemoryContext.setBytes(SimpleLocalMemoryContext.java:65)\\n\\tat io.trino.operator.OperatorContext$InternalLocalMemoryContext.setBytes(OperatorContext.java:708)\\n\\tat io.trino.memory.context.CoarseGrainLocalMemoryContext.setBytes(CoarseGrainLocalMemoryContext.java:68)\\n\\tat io.trino.operator.join.nonspilling.HashBuilderOperator.updateIndex(HashBuilderOperator.java:274)\\n\\tat io.trino.operator.join.nonspilling.HashBuilderOperator.addInput(HashBuilderOperator.java:263)\\n\\tat io.trino.operator.Driver.processInternal(Driver.java:408)\\n\\tat io.trino.operator.Driver.lambda$process$0(Driver.java:306)\\n\\tat io.trino.operator.Driver.tryWithLock(Driver.java:709)\\n\\tat io.trino.operator.Driver.process(Driver.java:298)\\n\\tat io.trino.operator.Driver.processForDuration(Driver.java:269)\\n\\tat io.trino.execution.SqlTaskExecution$DriverSplitRunner.processFor(SqlTaskExecution.java:852)\\n\\tat io.trino.execution.executor.dedicated.SplitProcessor.run(SplitProcessor.java:77)\\n\\tat io.trino.execution.executor.dedicated.TaskEntry$VersionEmbedderBridge.lambda$run$0(TaskEntry.java:205)\\n\\tat io.trino.$gen.Trino_481____20260611_022704_2.run(Unknown Source)\\n\\tat io.trino.execution.executor.dedicated.TaskEntry$VersionEmbedderBridge.run(TaskEntry.java:206)\\n\\tat io.trino.execution.executor.scheduler.FairScheduler.runTask(FairScheduler.java:177)\\n\\tat io.trino.execution.executor.scheduler.FairScheduler.lambda$submit$0(FairScheduler.java:164)\\n\\tat java.base/java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:545)\\n\\tat com.google.common.util.concurrent.TrustedListenableFutureTask$TrustedFutureInterruptibleTask.runInterruptibly(TrustedListenableFutureTask.java:128)\\n\\tat com.google.common.util.concurrent.InterruptibleTask.run(InterruptibleTask.java:74)\\n\\tat com.google.common.util.concurrent.TrustedListenableFutureTask.run(TrustedListenableFutureTask.java:80)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1090)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:614)\\n\\tat java.base/java.lang.Thread.run(Thread.java:1474)\\n\\nDriver stacktrace:\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\tat scala.Option.getOrElse(Option.scala:201)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\tat scala.Option.foreach(Option.scala:437)\\n\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\tat scala.util.Try$.apply(Try.scala:217)\\n\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\tat org.apache.spark.util.Utils$.getTryWithCallerStacktrace(Utils.scala:1439)\\n\\tat org.apache.spark.util.LazyTry.get(LazyTry.scala:58)\\n\\tat org.apache.spark.sql.execution.QueryExecution.commandExecuted(QueryExecution.scala:131)\\n\\tat org.apache.spark.sql.execution.QueryExecution.assertCommandExecuted(QueryExecution.scala:192)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.runCommand(DataFrameWriter.scala:622)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveToV1Source(DataFrameWriter.scala:273)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveInternal(DataFrameWriter.scala:182)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.save(DataFrameWriter.scala:118)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)\\n\\tat java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\\n\\tat java.base/java.lang.reflect.Method.invoke(Method.java:569)\\n\\tat py4j.reflection.MethodInvoker.invoke(MethodInvoker.java:244)\\n\\tat py4j.reflection.ReflectionEngine.invoke(ReflectionEngine.java:374)\\n\\tat py4j.Gateway.invoke(Gateway.java:282)\\n\\tat py4j.commands.AbstractCommand.invokeMethod(AbstractCommand.java:132)\\n\\tat py4j.commands.CallCommand.execute(CallCommand.java:79)\\n\\tat py4j.ClientServerConnection.waitForCommands(ClientServerConnection.java:184)\\n\\tat py4j.ClientServerConnection.run(ClientServerConnection.java:108)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\n\\tSuppressed: org.apache.spark.util.Utils$OriginalTryStackTraceException: Full stacktrace of original doTryWithCallerStacktrace caller\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\t\\tat scala.Option.getOrElse(Option.scala:201)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\t\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\t\\tat scala.Option.foreach(Option.scala:437)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\t\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\t\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\t\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\t\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\t\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\t\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\t\\tat scala.util.Try$.apply(Try.scala:217)\\n\\t\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT$lzycompute(LazyTry.scala:46)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT(LazyTry.scala:46)\\n\\t\\t... 19 more\\n"}, {"group_name": "part_cdi_-_centro_de_diagnostico_por_imagem_joined_0", "connection_name": "CDI - Centro de Diagn\\u00f3stico por Imagem", "status": "failed", "output_path": null, "rows_ingested": null, "execution_time_seconds": 42.864633, "error_message": "An error occurred while calling o1627.save.\\n: org.apache.spark.SparkException: Job aborted due to stage failure: Task 0 in stage 22.0 failed 4 times, most recent failure: Lost task 0.3 in stage 22.0 (TID 190) (172.18.0.10 executor 0): org.apache.spark.SparkException: [TASK_WRITE_FAILED] Task failed while writing rows to s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_cdi_-_centro_de_diagnostico_por_imagem. SQLSTATE: 58030\\n\\tat org.apache.spark.sql.errors.QueryExecutionErrors$.taskFailedWhileWritingRowsError(QueryExecutionErrors.scala:772)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeTask(DeltaFileFormatWriter.scala:469)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$3(DeltaFileFormatWriter.scala:281)\\n\\tat org.apache.spark.scheduler.ResultTask.runTask(ResultTask.scala:93)\\n\\tat org.apache.spark.TaskContext.runTaskWithListeners(TaskContext.scala:171)\\n\\tat org.apache.spark.scheduler.Task.run(Task.scala:147)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.$anonfun$run$5(Executor.scala:647)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally(SparkErrorUtils.scala:80)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally$(SparkErrorUtils.scala:77)\\n\\tat org.apache.spark.util.Utils$.tryWithSafeFinally(Utils.scala:99)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.run(Executor.scala:650)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\nCaused by: java.sql.SQLException: Query failed (#20260611_022934_00038_6jyw7): Query exceeded per-node memory limit of 1.50GB [Allocated: 1.50GB, Delta: 892.11kB, Top Consumers: {HashBuilderOperator=1.43GB, LazyOutputBuffer=36.00MB, ExchangeOperator=32.74MB}]\\n\\tat io.trino.jdbc.ResultUtils.resultsException(ResultUtils.java:33)\\n\\tat io.trino.jdbc.AsyncResultIterator.lambda$new$1(AsyncResultIterator.java:94)\\n\\tat java.base/java.util.concurrent.Executors$RunnableAdapter.call(Executors.java:539)\\n\\tat java.base/java.util.concurrent.FutureTask.run(FutureTask.java:264)\\n\\t... 3 more\\nCaused by: io.trino.ExceededMemoryLimitException: Query exceeded per-node memory limit of 1.50GB [Allocated: 1.50GB, Delta: 892.11kB, Top Consumers: {HashBuilderOperator=1.43GB, LazyOutputBuffer=36.00MB, ExchangeOperator=32.74MB}]\\n\\tat io.trino.ExceededMemoryLimitException.exceededLocalUserMemoryLimit(ExceededMemoryLimitException.java:41)\\n\\tat io.trino.memory.QueryContext.enforceUserMemoryLimit(QueryContext.java:333)\\n\\tat io.trino.memory.QueryContext.updateUserMemory(QueryContext.java:166)\\n\\tat io.trino.memory.QueryContext.lambda$addTaskContext$0(QueryContext.java:252)\\n\\tat io.trino.memory.QueryContext$QueryMemoryReservationHandler.reserveMemory(QueryContext.java:314)\\n\\tat io.trino.memory.context.RootAggregatedMemoryContext.updateBytes(RootAggregatedMemoryContext.java:37)\\n\\tat io.trino.memory.context.ChildAggregatedMemoryContext.updateBytes(ChildAggregatedMemoryContext.java:38)\\n\\tat io.trino.memory.context.SimpleLocalMemoryContext.setBytes(SimpleLocalMemoryContext.java:65)\\n\\tat io.trino.operator.DirectExchangeClient.updateRetainedMemory(DirectExchangeClient.java:368)\\n\\tat io.trino.operator.DirectExchangeClient.addPages(DirectExchangeClient.java:347)\\n\\tat io.trino.operator.DirectExchangeClient$ExchangeClientCallback.addPages(DirectExchangeClient.java:431)\\n\\tat io.trino.operator.HttpPageBufferClient$1.onSuccess(HttpPageBufferClient.java:436)\\n\\tat io.trino.operator.HttpPageBufferClient$1.onSuccess(HttpPageBufferClient.java:366)\\n\\tat com.google.common.util.concurrent.Futures$CallbackListener.run(Futures.java:1126)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1090)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:614)\\n\\tat java.base/java.lang.Thread.run(Thread.java:1474)\\n\\nDriver stacktrace:\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\tat scala.Option.getOrElse(Option.scala:201)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\tat scala.Option.foreach(Option.scala:437)\\n\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\tat scala.util.Try$.apply(Try.scala:217)\\n\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\tat org.apache.spark.util.Utils$.getTryWithCallerStacktrace(Utils.scala:1439)\\n\\tat org.apache.spark.util.LazyTry.get(LazyTry.scala:58)\\n\\tat org.apache.spark.sql.execution.QueryExecution.commandExecuted(QueryExecution.scala:131)\\n\\tat org.apache.spark.sql.execution.QueryExecution.assertCommandExecuted(QueryExecution.scala:192)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.runCommand(DataFrameWriter.scala:622)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveToV1Source(DataFrameWriter.scala:273)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveInternal(DataFrameWriter.scala:182)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.save(DataFrameWriter.scala:118)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)\\n\\tat java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\\n\\tat java.base/java.lang.reflect.Method.invoke(Method.java:569)\\n\\tat py4j.reflection.MethodInvoker.invoke(MethodInvoker.java:244)\\n\\tat py4j.reflection.ReflectionEngine.invoke(ReflectionEngine.java:374)\\n\\tat py4j.Gateway.invoke(Gateway.java:282)\\n\\tat py4j.commands.AbstractCommand.invokeMethod(AbstractCommand.java:132)\\n\\tat py4j.commands.CallCommand.execute(CallCommand.java:79)\\n\\tat py4j.ClientServerConnection.waitForCommands(ClientServerConnection.java:184)\\n\\tat py4j.ClientServerConnection.run(ClientServerConnection.java:108)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\n\\tSuppressed: org.apache.spark.util.Utils$OriginalTryStackTraceException: Full stacktrace of original doTryWithCallerStacktrace caller\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\t\\tat scala.Option.getOrElse(Option.scala:201)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\t\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\t\\tat scala.Option.foreach(Option.scala:437)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\t\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\t\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\t\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\t\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\t\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\t\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\t\\tat scala.util.Try$.apply(Try.scala:217)\\n\\t\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT$lzycompute(LazyTry.scala:46)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT(LazyTry.scala:46)\\n\\t\\t... 19 more\\n"}]	0	[]	\N	\N	2	{}	2	overwrite	\N	\N	\N	\N	\N	f	{"name": "Bronze REH-CDI-RFA 21tab [federated=FALSE]", "description": "21 tabelas id\\u00eanticas (sem programa_adesao). federated=False.", "tables": [{"table_id": 41, "select_all": true, "column_ids": null}, {"table_id": 42, "select_all": true, "column_ids": null}, {"table_id": 43, "select_all": true, "column_ids": null}, {"table_id": 44, "select_all": true, "column_ids": null}, {"table_id": 45, "select_all": true, "column_ids": null}, {"table_id": 46, "select_all": true, "column_ids": null}, {"table_id": 47, "select_all": true, "column_ids": null}, {"table_id": 48, "select_all": true, "column_ids": null}, {"table_id": 64, "select_all": true, "column_ids": null}, {"table_id": 65, "select_all": true, "column_ids": null}, {"table_id": 66, "select_all": true, "column_ids": null}, {"table_id": 67, "select_all": true, "column_ids": null}, {"table_id": 68, "select_all": true, "column_ids": null}, {"table_id": 77, "select_all": true, "column_ids": null}, {"table_id": 78, "select_all": true, "column_ids": null}, {"table_id": 49, "select_all": true, "column_ids": null}, {"table_id": 51, "select_all": true, "column_ids": null}, {"table_id": 52, "select_all": true, "column_ids": null}, {"table_id": 53, "select_all": true, "column_ids": null}, {"table_id": 54, "select_all": true, "column_ids": null}, {"table_id": 55, "select_all": true, "column_ids": null}], "relationship_ids": null, "enable_federated_joins": false, "output_format": "delta", "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "write_mode": "overwrite", "merge_keys": null, "merge_keys_source": null, "properties": {}, "snapshot_at": "2026-06-11T02:27:16.920954"}	2026-06-11 02:27:16.918813	2026-06-11 02:29:44.449785	\N	\N	t
8	11	SUCCESS	2026-06-11 02:46:22.530191+00	2026-06-11 03:50:47.502592+00	[{"group_name": "part_reh_-_rede_de_emergencias_hospitalares_joined_0", "connection_name": "REH - Rede de Emerg\\u00eancias Hospitalares", "status": "success", "output_path": "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_reh_-_rede_de_emergencias_hospitalares/", "rows_ingested": 37500009, "execution_time_seconds": 1103.013247, "error_message": null}, {"group_name": "part_rfa_-_rede_de_farmacias_e_adesao_joined_0", "connection_name": "RFA - Rede de Farm\\u00e1cias e Ades\\u00e3o", "status": "success", "output_path": "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_rfa_-_rede_de_farmacias_e_adesao/", "rows_ingested": 165000007, "execution_time_seconds": 2268.849014, "error_message": null}, {"group_name": "part_cdi_-_centro_de_diagnostico_por_imagem_joined_0", "connection_name": "CDI - Centro de Diagn\\u00f3stico por Imagem", "status": "success", "output_path": "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_cdi_-_centro_de_diagnostico_por_imagem/", "rows_ingested": 20000005, "execution_time_seconds": 490.296577, "error_message": null}]	222500021	["s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_reh_-_rede_de_emergencias_hospitalares/", "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_rfa_-_rede_de_farmacias_e_adesao/", "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_cdi_-_centro_de_diagnostico_por_imagem/"]	\N	\N	3	{"s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_reh_-_rede_de_emergencias_hospitalares/": 0, "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_rfa_-_rede_de_farmacias_e_adesao/": 0, "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_cdi_-_centro_de_diagnostico_por_imagem/": 0}	3	overwrite	\N	222500021	0	0	\N	f	{"name": "Bronze REH-CDI-RFA 21tab [federated=FALSE]", "description": "21 tabelas id\\u00eanticas (sem programa_adesao). federated=False.", "tables": [{"table_id": 41, "select_all": true, "column_ids": null}, {"table_id": 42, "select_all": true, "column_ids": null}, {"table_id": 43, "select_all": true, "column_ids": null}, {"table_id": 44, "select_all": true, "column_ids": null}, {"table_id": 45, "select_all": true, "column_ids": null}, {"table_id": 46, "select_all": true, "column_ids": null}, {"table_id": 47, "select_all": true, "column_ids": null}, {"table_id": 48, "select_all": true, "column_ids": null}, {"table_id": 64, "select_all": true, "column_ids": null}, {"table_id": 65, "select_all": true, "column_ids": null}, {"table_id": 66, "select_all": true, "column_ids": null}, {"table_id": 67, "select_all": true, "column_ids": null}, {"table_id": 68, "select_all": true, "column_ids": null}, {"table_id": 77, "select_all": true, "column_ids": null}, {"table_id": 78, "select_all": true, "column_ids": null}, {"table_id": 49, "select_all": true, "column_ids": null}, {"table_id": 51, "select_all": true, "column_ids": null}, {"table_id": 52, "select_all": true, "column_ids": null}, {"table_id": 53, "select_all": true, "column_ids": null}, {"table_id": 54, "select_all": true, "column_ids": null}, {"table_id": 55, "select_all": true, "column_ids": null}], "relationship_ids": null, "enable_federated_joins": false, "output_format": "delta", "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "write_mode": "overwrite", "merge_keys": null, "merge_keys_source": null, "properties": {}, "snapshot_at": "2026-06-11T02:46:22.530168"}	2026-06-11 02:46:22.504039	2026-06-11 03:50:47.521732	\N	\N	t
9	12	SUCCESS	2026-06-11 03:58:03.26322+00	2026-06-11 04:34:52.907506+00	[{"group_name": "unified_federated", "connection_name": "federated", "status": "success", "output_path": "s3a://datafabric-bronze/12-bronze_reh-cdi-rfa_21tab_federated_true/unified/", "rows_ingested": 71500019, "execution_time_seconds": 2209.00185, "error_message": null}]	71500019	["s3a://datafabric-bronze/12-bronze_reh-cdi-rfa_21tab_federated_true/unified/"]	\N	\N	0	{"s3a://datafabric-bronze/12-bronze_reh-cdi-rfa_21tab_federated_true/unified/": 0}	0	overwrite	\N	71500019	0	0	\N	f	{"name": "Bronze REH-CDI-RFA 21tab [federated=TRUE]", "description": "21 tabelas id\\u00eanticas (sem programa_adesao). federated=True.", "tables": [{"table_id": 41, "select_all": true, "column_ids": null}, {"table_id": 42, "select_all": true, "column_ids": null}, {"table_id": 43, "select_all": true, "column_ids": null}, {"table_id": 44, "select_all": true, "column_ids": null}, {"table_id": 45, "select_all": true, "column_ids": null}, {"table_id": 46, "select_all": true, "column_ids": null}, {"table_id": 47, "select_all": true, "column_ids": null}, {"table_id": 48, "select_all": true, "column_ids": null}, {"table_id": 64, "select_all": true, "column_ids": null}, {"table_id": 65, "select_all": true, "column_ids": null}, {"table_id": 66, "select_all": true, "column_ids": null}, {"table_id": 67, "select_all": true, "column_ids": null}, {"table_id": 68, "select_all": true, "column_ids": null}, {"table_id": 77, "select_all": true, "column_ids": null}, {"table_id": 78, "select_all": true, "column_ids": null}, {"table_id": 49, "select_all": true, "column_ids": null}, {"table_id": 51, "select_all": true, "column_ids": null}, {"table_id": 52, "select_all": true, "column_ids": null}, {"table_id": 53, "select_all": true, "column_ids": null}, {"table_id": 54, "select_all": true, "column_ids": null}, {"table_id": 55, "select_all": true, "column_ids": null}], "relationship_ids": null, "enable_federated_joins": true, "output_format": "delta", "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "write_mode": "overwrite", "merge_keys": null, "merge_keys_source": null, "properties": {}, "snapshot_at": "2026-06-11T03:58:03.263196"}	2026-06-11 03:58:03.261934	2026-06-11 04:34:52.915717	\N	\N	t
12	12	SUCCESS	2026-06-11 14:37:30.671453+00	2026-06-11 15:07:38.539429+00	[{"group_name": "unified_federated", "connection_name": "federated", "status": "success", "output_path": "s3a://datafabric-bronze/12-bronze_reh-cdi-rfa_21tab_federated_true/unified/", "rows_ingested": 71500019, "execution_time_seconds": 1805.876704, "error_message": null}]	71500019	["s3a://datafabric-bronze/12-bronze_reh-cdi-rfa_21tab_federated_true/unified/"]	\N	\N	2	{"s3a://datafabric-bronze/12-bronze_reh-cdi-rfa_21tab_federated_true/unified/": 1}	2	overwrite	\N	71500019	0	0	\N	f	{"name": "Bronze REH-CDI-RFA 21tab [federated=TRUE]", "description": "21 tabelas id\\u00eanticas (sem programa_adesao). federated=True.", "tables": [{"table_id": 41, "select_all": true, "column_ids": null}, {"table_id": 42, "select_all": true, "column_ids": null}, {"table_id": 43, "select_all": true, "column_ids": null}, {"table_id": 44, "select_all": true, "column_ids": null}, {"table_id": 45, "select_all": true, "column_ids": null}, {"table_id": 46, "select_all": true, "column_ids": null}, {"table_id": 47, "select_all": true, "column_ids": null}, {"table_id": 48, "select_all": true, "column_ids": null}, {"table_id": 64, "select_all": true, "column_ids": null}, {"table_id": 65, "select_all": true, "column_ids": null}, {"table_id": 66, "select_all": true, "column_ids": null}, {"table_id": 67, "select_all": true, "column_ids": null}, {"table_id": 68, "select_all": true, "column_ids": null}, {"table_id": 77, "select_all": true, "column_ids": null}, {"table_id": 78, "select_all": true, "column_ids": null}, {"table_id": 49, "select_all": true, "column_ids": null}, {"table_id": 51, "select_all": true, "column_ids": null}, {"table_id": 52, "select_all": true, "column_ids": null}, {"table_id": 53, "select_all": true, "column_ids": null}, {"table_id": 54, "select_all": true, "column_ids": null}, {"table_id": 55, "select_all": true, "column_ids": null}], "relationship_ids": null, "enable_federated_joins": true, "output_format": "delta", "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "write_mode": "overwrite", "merge_keys": null, "merge_keys_source": null, "properties": {}, "snapshot_at": "2026-06-11T14:37:30.671429"}	2026-06-11 14:37:30.669696	2026-06-11 15:07:38.541204	\N	\N	t
10	11	SUCCESS	2026-06-11 13:05:30.012294+00	2026-06-11 14:03:00.205321+00	[{"group_name": "part_reh_-_rede_de_emergencias_hospitalares_joined_0", "connection_name": "REH - Rede de Emerg\\u00eancias Hospitalares", "status": "success", "output_path": "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_reh_-_rede_de_emergencias_hospitalares/", "rows_ingested": 37500009, "execution_time_seconds": 792.703681, "error_message": null}, {"group_name": "part_rfa_-_rede_de_farmacias_e_adesao_joined_0", "connection_name": "RFA - Rede de Farm\\u00e1cias e Ades\\u00e3o", "status": "success", "output_path": "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_rfa_-_rede_de_farmacias_e_adesao/", "rows_ingested": 165000007, "execution_time_seconds": 2197.996618, "error_message": null}, {"group_name": "part_cdi_-_centro_de_diagnostico_por_imagem_joined_0", "connection_name": "CDI - Centro de Diagn\\u00f3stico por Imagem", "status": "success", "output_path": "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_cdi_-_centro_de_diagnostico_por_imagem/", "rows_ingested": 20000005, "execution_time_seconds": 458.972239, "error_message": null}]	222500021	["s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_reh_-_rede_de_emergencias_hospitalares/", "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_rfa_-_rede_de_farmacias_e_adesao/", "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_cdi_-_centro_de_diagnostico_por_imagem/"]	\N	\N	4	{"s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_reh_-_rede_de_emergencias_hospitalares/": 1, "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_rfa_-_rede_de_farmacias_e_adesao/": 1, "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_cdi_-_centro_de_diagnostico_por_imagem/": 1}	4	overwrite	\N	222500021	0	0	\N	f	{"name": "Bronze REH-CDI-RFA 21tab [federated=FALSE]", "description": "21 tabelas id\\u00eanticas (sem programa_adesao). federated=False.", "tables": [{"table_id": 41, "select_all": true, "column_ids": null}, {"table_id": 42, "select_all": true, "column_ids": null}, {"table_id": 43, "select_all": true, "column_ids": null}, {"table_id": 44, "select_all": true, "column_ids": null}, {"table_id": 45, "select_all": true, "column_ids": null}, {"table_id": 46, "select_all": true, "column_ids": null}, {"table_id": 47, "select_all": true, "column_ids": null}, {"table_id": 48, "select_all": true, "column_ids": null}, {"table_id": 64, "select_all": true, "column_ids": null}, {"table_id": 65, "select_all": true, "column_ids": null}, {"table_id": 66, "select_all": true, "column_ids": null}, {"table_id": 67, "select_all": true, "column_ids": null}, {"table_id": 68, "select_all": true, "column_ids": null}, {"table_id": 77, "select_all": true, "column_ids": null}, {"table_id": 78, "select_all": true, "column_ids": null}, {"table_id": 49, "select_all": true, "column_ids": null}, {"table_id": 51, "select_all": true, "column_ids": null}, {"table_id": 52, "select_all": true, "column_ids": null}, {"table_id": 53, "select_all": true, "column_ids": null}, {"table_id": 54, "select_all": true, "column_ids": null}, {"table_id": 55, "select_all": true, "column_ids": null}], "relationship_ids": null, "enable_federated_joins": false, "output_format": "delta", "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "write_mode": "overwrite", "merge_keys": null, "merge_keys_source": null, "properties": {}, "snapshot_at": "2026-06-11T13:05:30.012262"}	2026-06-11 13:05:30.011041	2026-06-11 14:03:00.21251	\N	\N	t
11	12	FAILED	2026-06-11 14:16:10.010403+00	2026-06-11 14:24:53.395168+00	[{"group_name": "unified_federated", "connection_name": "federated", "status": "failed", "output_path": null, "rows_ingested": null, "execution_time_seconds": 522.926084, "error_message": "An error occurred while calling o887.save.\\n: org.apache.spark.SparkException: Job aborted due to stage failure: Task 0 in stage 36.0 failed 4 times, most recent failure: Lost task 0.3 in stage 36.0 (TID 370) (172.18.0.10 executor 0): java.sql.SQLException: Query failed (#20260611_142453_00002_xy3uu): Trino server is still initializing\\n\\tat io.trino.jdbc.ResultUtils.resultsException(ResultUtils.java:33)\\n\\tat io.trino.jdbc.TrinoResultSet.getColumns(TrinoResultSet.java:143)\\n\\tat io.trino.jdbc.TrinoResultSet.create(TrinoResultSet.java:49)\\n\\tat io.trino.jdbc.TrinoStatement.internalExecute(TrinoStatement.java:276)\\n\\tat io.trino.jdbc.TrinoStatement.execute(TrinoStatement.java:254)\\n\\tat io.trino.jdbc.TrinoPreparedStatement.<init>(TrinoPreparedStatement.java:131)\\n\\tat io.trino.jdbc.TrinoConnection.prepareStatement(TrinoConnection.java:307)\\n\\tat io.trino.jdbc.TrinoConnection.prepareStatement(TrinoConnection.java:501)\\n\\tat org.apache.spark.sql.execution.datasources.jdbc.JDBCRDD.compute(JDBCRDD.scala:282)\\n\\tat org.apache.spark.rdd.RDD.computeOrReadCheckpoint(RDD.scala:374)\\n\\tat org.apache.spark.rdd.RDD.iterator(RDD.scala:338)\\n\\tat org.apache.spark.rdd.MapPartitionsRDD.compute(MapPartitionsRDD.scala:52)\\n\\tat org.apache.spark.rdd.RDD.computeOrReadCheckpoint(RDD.scala:374)\\n\\tat org.apache.spark.rdd.RDD.iterator(RDD.scala:338)\\n\\tat org.apache.spark.rdd.MapPartitionsRDD.compute(MapPartitionsRDD.scala:52)\\n\\tat org.apache.spark.rdd.RDD.computeOrReadCheckpoint(RDD.scala:374)\\n\\tat org.apache.spark.rdd.RDD.iterator(RDD.scala:338)\\n\\tat org.apache.spark.rdd.MapPartitionsRDD.compute(MapPartitionsRDD.scala:52)\\n\\tat org.apache.spark.rdd.RDD.computeOrReadCheckpoint(RDD.scala:374)\\n\\tat org.apache.spark.rdd.RDD.iterator(RDD.scala:338)\\n\\tat org.apache.spark.scheduler.ResultTask.runTask(ResultTask.scala:93)\\n\\tat org.apache.spark.TaskContext.runTaskWithListeners(TaskContext.scala:171)\\n\\tat org.apache.spark.scheduler.Task.run(Task.scala:147)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.$anonfun$run$5(Executor.scala:647)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally(SparkErrorUtils.scala:80)\\n\\tat org.apache.spark.util.SparkErrorUtils.tryWithSafeFinally$(SparkErrorUtils.scala:77)\\n\\tat org.apache.spark.util.Utils$.tryWithSafeFinally(Utils.scala:99)\\n\\tat org.apache.spark.executor.Executor$TaskRunner.run(Executor.scala:650)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1136)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:635)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\nCaused by: io.trino.spi.TrinoException: Trino server is still initializing\\n\\tat io.trino.security.AccessControlManager$InitializingSystemAccessControl.delegate(AccessControlManager.java:1708)\\n\\tat io.trino.plugin.base.security.ForwardingSystemAccessControl.checkCanSetUser(ForwardingSystemAccessControl.java:71)\\n\\tat io.trino.security.AccessControlManager.lambda$checkCanSetUser$0(AccessControlManager.java:298)\\n\\tat io.trino.security.AccessControlManager.systemAuthorizationCheck(AccessControlManager.java:1604)\\n\\tat io.trino.security.AccessControlManager.checkCanSetUser(AccessControlManager.java:298)\\n\\tat io.trino.security.ForwardingAccessControl.checkCanSetUser(ForwardingAccessControl.java:80)\\n\\tat io.trino.tracing.TracingAccessControl.checkCanSetUser(TracingAccessControl.java:70)\\n\\tat io.trino.server.QuerySessionSupplier.createSession(QuerySessionSupplier.java:74)\\n\\tat io.trino.dispatcher.DispatchManager.createQueryInternal(DispatchManager.java:219)\\n\\tat io.trino.dispatcher.DispatchManager.lambda$createQuery$0(DispatchManager.java:194)\\n\\tat io.opentelemetry.context.Context.lambda$wrap$1(Context.java:241)\\n\\tat io.airlift.concurrent.BoundedExecutor.drainQueue(BoundedExecutor.java:79)\\n\\tat io.trino.$gen.Trino_481____20260611_142448_2.run(Unknown Source)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1090)\\n\\tat java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:614)\\n\\tat java.base/java.lang.Thread.run(Thread.java:1474)\\n\\nDriver stacktrace:\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\tat scala.Option.getOrElse(Option.scala:201)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\tat scala.Option.foreach(Option.scala:437)\\n\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\tat scala.util.Try$.apply(Try.scala:217)\\n\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\tat org.apache.spark.util.Utils$.getTryWithCallerStacktrace(Utils.scala:1439)\\n\\tat org.apache.spark.util.LazyTry.get(LazyTry.scala:58)\\n\\tat org.apache.spark.sql.execution.QueryExecution.commandExecuted(QueryExecution.scala:131)\\n\\tat org.apache.spark.sql.execution.QueryExecution.assertCommandExecuted(QueryExecution.scala:192)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.runCommand(DataFrameWriter.scala:622)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveToV1Source(DataFrameWriter.scala:273)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.saveInternal(DataFrameWriter.scala:182)\\n\\tat org.apache.spark.sql.classic.DataFrameWriter.save(DataFrameWriter.scala:118)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\\n\\tat java.base/jdk.internal.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:77)\\n\\tat java.base/jdk.internal.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\\n\\tat java.base/java.lang.reflect.Method.invoke(Method.java:569)\\n\\tat py4j.reflection.MethodInvoker.invoke(MethodInvoker.java:244)\\n\\tat py4j.reflection.ReflectionEngine.invoke(ReflectionEngine.java:374)\\n\\tat py4j.Gateway.invoke(Gateway.java:282)\\n\\tat py4j.commands.AbstractCommand.invokeMethod(AbstractCommand.java:132)\\n\\tat py4j.commands.CallCommand.execute(CallCommand.java:79)\\n\\tat py4j.ClientServerConnection.waitForCommands(ClientServerConnection.java:184)\\n\\tat py4j.ClientServerConnection.run(ClientServerConnection.java:108)\\n\\tat java.base/java.lang.Thread.run(Thread.java:840)\\n\\tSuppressed: org.apache.spark.util.Utils$OriginalTryStackTraceException: Full stacktrace of original doTryWithCallerStacktrace caller\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$3(DAGScheduler.scala:2935)\\n\\t\\tat scala.Option.getOrElse(Option.scala:201)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2(DAGScheduler.scala:2935)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$abortStage$2$adapted(DAGScheduler.scala:2927)\\n\\t\\tat scala.collection.immutable.List.foreach(List.scala:334)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.abortStage(DAGScheduler.scala:2927)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.$anonfun$handleTaskSetFailed$1$adapted(DAGScheduler.scala:1295)\\n\\t\\tat scala.Option.foreach(Option.scala:437)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.handleTaskSetFailed(DAGScheduler.scala:1295)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.doOnReceive(DAGScheduler.scala:3207)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3141)\\n\\t\\tat org.apache.spark.scheduler.DAGSchedulerEventProcessLoop.onReceive(DAGScheduler.scala:3130)\\n\\t\\tat org.apache.spark.util.EventLoop$$anon$1.run(EventLoop.scala:50)\\n\\t\\tat org.apache.spark.scheduler.DAGScheduler.runJob(DAGScheduler.scala:1009)\\n\\t\\tat org.apache.spark.SparkContext.runJob(SparkContext.scala:2484)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.$anonfun$executeWrite$1(DeltaFileFormatWriter.scala:269)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.writeAndCommit(DeltaFileFormatWriter.scala:302)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.executeWrite(DeltaFileFormatWriter.scala:238)\\n\\t\\tat org.apache.spark.sql.delta.files.DeltaFileFormatWriter$.write(DeltaFileFormatWriter.scala:218)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.$anonfun$writeFiles$2(TransactionalWrite.scala:470)\\n\\t\\tat scala.runtime.java8.JFunction0$mcV$sp.apply(JFunction0$mcV$sp.scala:18)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:428)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:386)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:250)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:246)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles(TransactionalWrite.scala:239)\\n\\t\\tat org.apache.spark.sql.delta.files.TransactionalWrite.writeFiles$(TransactionalWrite.scala:236)\\n\\t\\tat org.apache.spark.sql.delta.OptimisticTransaction.writeFiles(OptimisticTransaction.scala:169)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeFiles(WriteIntoDelta.scala:381)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.writeAndReturnCommitData(WriteIntoDelta.scala:326)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.$anonfun$run$1(WriteIntoDelta.scala:109)\\n\\t\\tat org.apache.spark.sql.delta.DeltaLog.withNewTransaction(DeltaLog.scala:247)\\n\\t\\tat org.apache.spark.sql.delta.commands.WriteIntoDelta.run(WriteIntoDelta.scala:104)\\n\\t\\tat org.apache.spark.sql.delta.sources.DeltaDataSource.createRelation(DeltaDataSource.scala:209)\\n\\t\\tat org.apache.spark.sql.execution.datasources.SaveIntoDataSourceCommand.run(SaveIntoDataSourceCommand.scala:55)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult$lzycompute(commands.scala:79)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.sideEffectResult(commands.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.command.ExecutedCommandExec.executeCollect(commands.scala:88)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$2(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$8(SQLExecution.scala:162)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSessionTagsApplied(SQLExecution.scala:268)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$7(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.JobArtifactSet$.withActiveJobArtifactState(JobArtifactSet.scala:94)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.$anonfun$withResources$1(ArtifactManager.scala:112)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withClassLoaderIfNeeded(ArtifactManager.scala:106)\\n\\t\\tat org.apache.spark.sql.artifact.ArtifactManager.withResources(ArtifactManager.scala:111)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$6(SQLExecution.scala:124)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withSQLConfPropagated(SQLExecution.scala:291)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.$anonfun$withNewExecutionId0$1(SQLExecution.scala:123)\\n\\t\\tat org.apache.spark.sql.SparkSession.withActive(SparkSession.scala:804)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId0(SQLExecution.scala:77)\\n\\t\\tat org.apache.spark.sql.execution.SQLExecution$.withNewExecutionId(SQLExecution.scala:233)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$eagerlyExecuteCommands$1(QueryExecution.scala:155)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$.withInternalError(QueryExecution.scala:654)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.org$apache$spark$sql$execution$QueryExecution$$eagerlyExecute$1(QueryExecution.scala:154)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:169)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution$$anonfun$eagerlyExecuteCommands$3.applyOrElse(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.$anonfun$transformDownWithPruning$1(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.CurrentOrigin$.withOrigin(origin.scala:86)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDownWithPruning(TreeNode.scala:470)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.org$apache$spark$sql$catalyst$plans$logical$AnalysisHelper$$super$transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning(AnalysisHelper.scala:360)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.AnalysisHelper.transformDownWithPruning$(AnalysisHelper.scala:356)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.plans.logical.LogicalPlan.transformDownWithPruning(LogicalPlan.scala:37)\\n\\t\\tat org.apache.spark.sql.catalyst.trees.TreeNode.transformDown(TreeNode.scala:446)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.eagerlyExecuteCommands(QueryExecution.scala:164)\\n\\t\\tat org.apache.spark.sql.execution.QueryExecution.$anonfun$lazyCommandExecuted$1(QueryExecution.scala:126)\\n\\t\\tat scala.util.Try$.apply(Try.scala:217)\\n\\t\\tat org.apache.spark.util.Utils$.doTryWithCallerStacktrace(Utils.scala:1378)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT$lzycompute(LazyTry.scala:46)\\n\\t\\tat org.apache.spark.util.LazyTry.tryT(LazyTry.scala:46)\\n\\t\\t... 19 more\\n"}]	0	[]	\N	\N	1	{}	1	overwrite	\N	\N	\N	\N	\N	f	{"name": "Bronze REH-CDI-RFA 21tab [federated=TRUE]", "description": "21 tabelas id\\u00eanticas (sem programa_adesao). federated=True.", "tables": [{"table_id": 41, "select_all": true, "column_ids": null}, {"table_id": 42, "select_all": true, "column_ids": null}, {"table_id": 43, "select_all": true, "column_ids": null}, {"table_id": 44, "select_all": true, "column_ids": null}, {"table_id": 45, "select_all": true, "column_ids": null}, {"table_id": 46, "select_all": true, "column_ids": null}, {"table_id": 47, "select_all": true, "column_ids": null}, {"table_id": 48, "select_all": true, "column_ids": null}, {"table_id": 64, "select_all": true, "column_ids": null}, {"table_id": 65, "select_all": true, "column_ids": null}, {"table_id": 66, "select_all": true, "column_ids": null}, {"table_id": 67, "select_all": true, "column_ids": null}, {"table_id": 68, "select_all": true, "column_ids": null}, {"table_id": 77, "select_all": true, "column_ids": null}, {"table_id": 78, "select_all": true, "column_ids": null}, {"table_id": 49, "select_all": true, "column_ids": null}, {"table_id": 51, "select_all": true, "column_ids": null}, {"table_id": 52, "select_all": true, "column_ids": null}, {"table_id": 53, "select_all": true, "column_ids": null}, {"table_id": 54, "select_all": true, "column_ids": null}, {"table_id": 55, "select_all": true, "column_ids": null}], "relationship_ids": null, "enable_federated_joins": true, "output_format": "delta", "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "write_mode": "overwrite", "merge_keys": null, "merge_keys_source": null, "properties": {}, "snapshot_at": "2026-06-11T14:16:10.010390"}	2026-06-11 14:16:10.00993	2026-06-11 14:24:53.400892	\N	\N	t
13	13	SUCCESS	2026-07-13 22:18:43.389379+00	2026-07-13 22:19:23.225074+00	[{"group_name": "part_dermexp3_ham10000_collection_212_ham10000_metadata", "connection_name": "dermexp3 HAM10000 collection 212", "status": "success", "output_path": "s3a://datafabric-bronze/13-dermexp3_bronze_union_v1/part_dermexp3_ham10000_collection_212/", "rows_ingested": 11720, "execution_time_seconds": 28.473904, "error_message": null}, {"group_name": "part_dermexp3_hiba_collection_251_hiba_metadata", "connection_name": "dermexp3 HIBA collection 251", "status": "success", "output_path": "s3a://datafabric-bronze/13-dermexp3_bronze_union_v1/part_dermexp3_hiba_collection_251/", "rows_ingested": 1616, "execution_time_seconds": 5.091158, "error_message": null}, {"group_name": "part_dermexp3_pad-ufes-20_collection_406_pad_ufes_20_metadata", "connection_name": "dermexp3 PAD-UFES-20 collection 406", "status": "success", "output_path": "s3a://datafabric-bronze/13-dermexp3_bronze_union_v1/part_dermexp3_pad-ufes-20_collection_406/", "rows_ingested": 2298, "execution_time_seconds": 5.817189, "error_message": null}]	15634	["s3a://datafabric-bronze/13-dermexp3_bronze_union_v1/part_dermexp3_ham10000_collection_212/", "s3a://datafabric-bronze/13-dermexp3_bronze_union_v1/part_dermexp3_hiba_collection_251/", "s3a://datafabric-bronze/13-dermexp3_bronze_union_v1/part_dermexp3_pad-ufes-20_collection_406/"]	\N	\N	0	{"s3a://datafabric-bronze/13-dermexp3_bronze_union_v1/part_dermexp3_ham10000_collection_212/": 0, "s3a://datafabric-bronze/13-dermexp3_bronze_union_v1/part_dermexp3_hiba_collection_251/": 0, "s3a://datafabric-bronze/13-dermexp3_bronze_union_v1/part_dermexp3_pad-ufes-20_collection_406/": 0}	0	overwrite	\N	15634	0	0	\N	f	{"name": "dermexp3_bronze_union_v1", "description": "Raw versioned snapshots for HAM10000, HIBA, and PAD-UFES-20; no inter-source joins", "tables": [{"table_id": 87, "select_all": true, "column_ids": null}, {"table_id": 96, "select_all": true, "column_ids": null}, {"table_id": 105, "select_all": true, "column_ids": null}], "relationship_ids": null, "enable_federated_joins": false, "output_format": "delta", "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "write_mode": "overwrite", "merge_keys": null, "merge_keys_source": null, "properties": {"experiment": "dermatology_exp3", "combination": "union_in_silver"}, "snapshot_at": "2026-07-13T22:18:43.389326"}	2026-07-13 22:18:43.388199	2026-07-13 22:19:23.231849	\N	\N	t
14	14	SUCCESS	2026-07-13 22:21:57.061505+00	2026-07-13 22:22:09.529137+00	[{"group_name": "part_dermexp3_v2_ham10000_collection_212_metadata", "connection_name": "dermexp3 v2 HAM10000 collection 212", "status": "success", "output_path": "s3a://datafabric-bronze/14-dermexp3_bronze_union_v2/part_dermexp3_v2_ham10000_collection_212/", "rows_ingested": 11720, "execution_time_seconds": 4.455151, "error_message": null}, {"group_name": "part_dermexp3_v2_hiba_collection_251_metadata", "connection_name": "dermexp3 v2 HIBA collection 251", "status": "success", "output_path": "s3a://datafabric-bronze/14-dermexp3_bronze_union_v2/part_dermexp3_v2_hiba_collection_251/", "rows_ingested": 1616, "execution_time_seconds": 3.597458, "error_message": null}, {"group_name": "part_dermexp3_v2_pad-ufes-20_collection_406_metadata", "connection_name": "dermexp3 v2 PAD-UFES-20 collection 406", "status": "success", "output_path": "s3a://datafabric-bronze/14-dermexp3_bronze_union_v2/part_dermexp3_v2_pad-ufes-20_collection_406/", "rows_ingested": 2298, "execution_time_seconds": 4.080809, "error_message": null}]	15634	["s3a://datafabric-bronze/14-dermexp3_bronze_union_v2/part_dermexp3_v2_ham10000_collection_212/", "s3a://datafabric-bronze/14-dermexp3_bronze_union_v2/part_dermexp3_v2_hiba_collection_251/", "s3a://datafabric-bronze/14-dermexp3_bronze_union_v2/part_dermexp3_v2_pad-ufes-20_collection_406/"]	\N	\N	0	{"s3a://datafabric-bronze/14-dermexp3_bronze_union_v2/part_dermexp3_v2_ham10000_collection_212/": 0, "s3a://datafabric-bronze/14-dermexp3_bronze_union_v2/part_dermexp3_v2_hiba_collection_251/": 0, "s3a://datafabric-bronze/14-dermexp3_bronze_union_v2/part_dermexp3_v2_pad-ufes-20_collection_406/": 0}	0	overwrite	\N	15634	0	0	\N	f	{"name": "dermexp3_bronze_union_v2", "description": "Raw versioned snapshots for HAM10000, HIBA, and PAD-UFES-20; no inter-source joins", "tables": [{"table_id": 114, "select_all": true, "column_ids": null}, {"table_id": 123, "select_all": true, "column_ids": null}, {"table_id": 132, "select_all": true, "column_ids": null}], "relationship_ids": null, "enable_federated_joins": false, "output_format": "delta", "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "write_mode": "overwrite", "merge_keys": null, "merge_keys_source": null, "properties": {"experiment": "dermatology_exp3", "combination": "union_in_silver"}, "snapshot_at": "2026-07-13T22:21:57.061492"}	2026-07-13 22:21:57.061042	2026-07-13 22:22:09.529768	\N	\N	t
\.


--
-- Data for Name: bronze_persistent_configs; Type: TABLE DATA; Schema: datasets; Owner: -
--

COPY datasets.bronze_persistent_configs (id, name, description, tables, relationship_ids, enable_federated_joins, output_format, output_bucket, output_path_prefix, partition_columns, write_mode, merge_keys, merge_keys_source, properties, config_snapshot, last_execution_time, last_execution_status, last_execution_rows, last_execution_error, current_delta_version, known_output_paths, is_active, dataset_id, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
11	Bronze REH-CDI-RFA 21tab [federated=FALSE]	21 tabelas idênticas (sem programa_adesao). federated=False.	[{"table_id": 41, "select_all": true, "column_ids": null}, {"table_id": 42, "select_all": true, "column_ids": null}, {"table_id": 43, "select_all": true, "column_ids": null}, {"table_id": 44, "select_all": true, "column_ids": null}, {"table_id": 45, "select_all": true, "column_ids": null}, {"table_id": 46, "select_all": true, "column_ids": null}, {"table_id": 47, "select_all": true, "column_ids": null}, {"table_id": 48, "select_all": true, "column_ids": null}, {"table_id": 64, "select_all": true, "column_ids": null}, {"table_id": 65, "select_all": true, "column_ids": null}, {"table_id": 66, "select_all": true, "column_ids": null}, {"table_id": 67, "select_all": true, "column_ids": null}, {"table_id": 68, "select_all": true, "column_ids": null}, {"table_id": 77, "select_all": true, "column_ids": null}, {"table_id": 78, "select_all": true, "column_ids": null}, {"table_id": 49, "select_all": true, "column_ids": null}, {"table_id": 51, "select_all": true, "column_ids": null}, {"table_id": 52, "select_all": true, "column_ids": null}, {"table_id": 53, "select_all": true, "column_ids": null}, {"table_id": 54, "select_all": true, "column_ids": null}, {"table_id": 55, "select_all": true, "column_ids": null}]	null	f	delta	\N	\N	null	OVERWRITE	null	\N	{}	{"name": "Bronze REH-CDI-RFA 21tab [federated=FALSE]", "description": "21 tabelas id\\u00eanticas (sem programa_adesao). federated=False.", "tables": [{"table_id": 41, "select_all": true, "column_ids": null}, {"table_id": 42, "select_all": true, "column_ids": null}, {"table_id": 43, "select_all": true, "column_ids": null}, {"table_id": 44, "select_all": true, "column_ids": null}, {"table_id": 45, "select_all": true, "column_ids": null}, {"table_id": 46, "select_all": true, "column_ids": null}, {"table_id": 47, "select_all": true, "column_ids": null}, {"table_id": 48, "select_all": true, "column_ids": null}, {"table_id": 64, "select_all": true, "column_ids": null}, {"table_id": 65, "select_all": true, "column_ids": null}, {"table_id": 66, "select_all": true, "column_ids": null}, {"table_id": 67, "select_all": true, "column_ids": null}, {"table_id": 68, "select_all": true, "column_ids": null}, {"table_id": 77, "select_all": true, "column_ids": null}, {"table_id": 78, "select_all": true, "column_ids": null}, {"table_id": 49, "select_all": true, "column_ids": null}, {"table_id": 51, "select_all": true, "column_ids": null}, {"table_id": 52, "select_all": true, "column_ids": null}, {"table_id": 53, "select_all": true, "column_ids": null}, {"table_id": 54, "select_all": true, "column_ids": null}, {"table_id": 55, "select_all": true, "column_ids": null}], "relationship_ids": null, "enable_federated_joins": false, "output_format": "delta", "write_mode": "overwrite", "merge_keys": null, "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "properties": {}}	2026-06-11 14:03:00.209065+00	SUCCESS	222500021	\N	4	{"REH - Rede de Emerg\\u00eancias Hospitalares": "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_reh_-_rede_de_emergencias_hospitalares/", "RFA - Rede de Farm\\u00e1cias e Ades\\u00e3o": "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_rfa_-_rede_de_farmacias_e_adesao/", "CDI - Centro de Diagn\\u00f3stico por Imagem": "s3a://datafabric-bronze/11-bronze_reh-cdi-rfa_21tab_federated_false/part_cdi_-_centro_de_diagnostico_por_imagem/"}	t	\N	2026-06-11 02:10:27.958609	2026-06-11 14:03:00.228578	\N	\N	t
12	Bronze REH-CDI-RFA 21tab [federated=TRUE]	21 tabelas idênticas (sem programa_adesao). federated=True.	[{"table_id": 41, "select_all": true, "column_ids": null}, {"table_id": 42, "select_all": true, "column_ids": null}, {"table_id": 43, "select_all": true, "column_ids": null}, {"table_id": 44, "select_all": true, "column_ids": null}, {"table_id": 45, "select_all": true, "column_ids": null}, {"table_id": 46, "select_all": true, "column_ids": null}, {"table_id": 47, "select_all": true, "column_ids": null}, {"table_id": 48, "select_all": true, "column_ids": null}, {"table_id": 64, "select_all": true, "column_ids": null}, {"table_id": 65, "select_all": true, "column_ids": null}, {"table_id": 66, "select_all": true, "column_ids": null}, {"table_id": 67, "select_all": true, "column_ids": null}, {"table_id": 68, "select_all": true, "column_ids": null}, {"table_id": 77, "select_all": true, "column_ids": null}, {"table_id": 78, "select_all": true, "column_ids": null}, {"table_id": 49, "select_all": true, "column_ids": null}, {"table_id": 51, "select_all": true, "column_ids": null}, {"table_id": 52, "select_all": true, "column_ids": null}, {"table_id": 53, "select_all": true, "column_ids": null}, {"table_id": 54, "select_all": true, "column_ids": null}, {"table_id": 55, "select_all": true, "column_ids": null}]	null	t	delta	\N	\N	null	OVERWRITE	null	\N	{}	{"name": "Bronze REH-CDI-RFA 21tab [federated=TRUE]", "description": "21 tabelas id\\u00eanticas (sem programa_adesao). federated=True.", "tables": [{"table_id": 41, "select_all": true, "column_ids": null}, {"table_id": 42, "select_all": true, "column_ids": null}, {"table_id": 43, "select_all": true, "column_ids": null}, {"table_id": 44, "select_all": true, "column_ids": null}, {"table_id": 45, "select_all": true, "column_ids": null}, {"table_id": 46, "select_all": true, "column_ids": null}, {"table_id": 47, "select_all": true, "column_ids": null}, {"table_id": 48, "select_all": true, "column_ids": null}, {"table_id": 64, "select_all": true, "column_ids": null}, {"table_id": 65, "select_all": true, "column_ids": null}, {"table_id": 66, "select_all": true, "column_ids": null}, {"table_id": 67, "select_all": true, "column_ids": null}, {"table_id": 68, "select_all": true, "column_ids": null}, {"table_id": 77, "select_all": true, "column_ids": null}, {"table_id": 78, "select_all": true, "column_ids": null}, {"table_id": 49, "select_all": true, "column_ids": null}, {"table_id": 51, "select_all": true, "column_ids": null}, {"table_id": 52, "select_all": true, "column_ids": null}, {"table_id": 53, "select_all": true, "column_ids": null}, {"table_id": 54, "select_all": true, "column_ids": null}, {"table_id": 55, "select_all": true, "column_ids": null}], "relationship_ids": null, "enable_federated_joins": true, "output_format": "delta", "write_mode": "overwrite", "merge_keys": null, "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "properties": {}}	2026-06-11 15:07:38.54074+00	SUCCESS	71500019	\N	2	{"federated": "s3a://datafabric-bronze/12-bronze_reh-cdi-rfa_21tab_federated_true/unified/"}	t	\N	2026-06-11 02:10:27.970348	2026-06-11 15:07:38.542624	\N	\N	t
1	hospital_federation_persistent	Persistent Bronze: federated JOIN between IDA (MySQL) and CMPD (PostgreSQL) via CPF. Materialises a unified patient view into Delta Lake — demographics from both hospitals in one output path.	[{"table_id": 31, "select_all": false, "column_ids": [195, 196, 197, 198, 200]}, {"table_id": 5, "select_all": false, "column_ids": [36, 37, 38, 39, 48, 50, 49]}]	[11]	t	delta	\N	\N	null	OVERWRITE	null	\N	{}	{"name": "hospital_federation_persistent", "description": "Persistent Bronze: federated JOIN between IDA (MySQL) and CMPD (PostgreSQL) via CPF. Materialises a unified patient view into Delta Lake \\u2014 demographics from both hospitals in one output path.", "tables": [{"table_id": 31, "select_all": false, "column_ids": [195, 196, 197, 198, 200]}, {"table_id": 5, "select_all": false, "column_ids": [36, 37, 38, 39, 48, 50, 49]}], "relationship_ids": [11], "enable_federated_joins": true, "output_format": "delta", "write_mode": "overwrite", "merge_keys": null, "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "properties": {}}	2026-05-24 03:08:11.754314+00	SUCCESS	1507	\N	3	{"federated": "s3a://datafabric-bronze/1-hospital_federation_persistent/unified/"}	t	\N	2026-05-24 02:43:43.25993	2026-05-24 03:08:11.759966	\N	\N	t
13	dermexp3_bronze_union_v1	Raw versioned snapshots for HAM10000, HIBA, and PAD-UFES-20; no inter-source joins	[{"table_id": 87, "select_all": true, "column_ids": null}, {"table_id": 96, "select_all": true, "column_ids": null}, {"table_id": 105, "select_all": true, "column_ids": null}]	null	f	delta	\N	\N	null	OVERWRITE	null	\N	{"experiment": "dermatology_exp3", "combination": "union_in_silver"}	{"name": "dermexp3_bronze_union_v1", "description": "Raw versioned snapshots for HAM10000, HIBA, and PAD-UFES-20; no inter-source joins", "tables": [{"table_id": 87, "select_all": true, "column_ids": null}, {"table_id": 96, "select_all": true, "column_ids": null}, {"table_id": 105, "select_all": true, "column_ids": null}], "relationship_ids": null, "enable_federated_joins": false, "output_format": "delta", "write_mode": "merge", "merge_keys": null, "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "properties": {"experiment": "dermatology_exp3", "combination": "union_in_silver"}}	2026-07-13 22:19:23.22517+00	SUCCESS	15634	\N	0	{"dermexp3 HAM10000 collection 212": "s3a://datafabric-bronze/13-dermexp3_bronze_union_v1/part_dermexp3_ham10000_collection_212/", "dermexp3 HIBA collection 251": "s3a://datafabric-bronze/13-dermexp3_bronze_union_v1/part_dermexp3_hiba_collection_251/", "dermexp3 PAD-UFES-20 collection 406": "s3a://datafabric-bronze/13-dermexp3_bronze_union_v1/part_dermexp3_pad-ufes-20_collection_406/"}	t	\N	2026-07-13 22:18:43.336462	2026-07-13 22:19:23.235045	\N	\N	t
14	dermexp3_bronze_union_v2	Raw versioned snapshots for HAM10000, HIBA, and PAD-UFES-20; no inter-source joins	[{"table_id": 114, "select_all": true, "column_ids": null}, {"table_id": 123, "select_all": true, "column_ids": null}, {"table_id": 132, "select_all": true, "column_ids": null}]	null	f	delta	\N	\N	null	OVERWRITE	null	\N	{"experiment": "dermatology_exp3", "combination": "union_in_silver"}	{"name": "dermexp3_bronze_union_v2", "description": "Raw versioned snapshots for HAM10000, HIBA, and PAD-UFES-20; no inter-source joins", "tables": [{"table_id": 114, "select_all": true, "column_ids": null}, {"table_id": 123, "select_all": true, "column_ids": null}, {"table_id": 132, "select_all": true, "column_ids": null}], "relationship_ids": null, "enable_federated_joins": false, "output_format": "delta", "write_mode": "merge", "merge_keys": null, "output_bucket": null, "output_path_prefix": null, "partition_columns": null, "properties": {"experiment": "dermatology_exp3", "combination": "union_in_silver"}}	2026-07-13 22:22:09.529209+00	SUCCESS	15634	\N	0	{"dermexp3 v2 HAM10000 collection 212": "s3a://datafabric-bronze/14-dermexp3_bronze_union_v2/part_dermexp3_v2_ham10000_collection_212/", "dermexp3 v2 HIBA collection 251": "s3a://datafabric-bronze/14-dermexp3_bronze_union_v2/part_dermexp3_v2_hiba_collection_251/", "dermexp3 v2 PAD-UFES-20 collection 406": "s3a://datafabric-bronze/14-dermexp3_bronze_union_v2/part_dermexp3_v2_pad-ufes-20_collection_406/"}	t	\N	2026-07-13 22:21:57.043193	2026-07-13 22:22:09.553986	\N	\N	t
\.


--
-- Data for Name: bronze_virtualized_configs; Type: TABLE DATA; Schema: datasets; Owner: -
--

COPY datasets.bronze_virtualized_configs (id, name, description, tables, relationship_ids, enable_federated_joins, generated_sql, is_active, last_query_time, last_query_rows, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	hospital_federation_virtualized	Virtualized Bronze: same IDA + CMPD patient columns as the persistent config, but WITHOUT federated joins. Each source is queried independently — the CPF relationship (ID=11) is stored as metadata for the Silver layer to resolve.	[{"table_id": 31, "select_all": false, "column_ids": [195, 196, 197, 198]}, {"table_id": 5, "select_all": false, "column_ids": [36, 37, 38, 39, 48, 50]}]	[11]	f	\N	t	2026-06-02 02:21:43.253732+00	2000	2026-05-24 02:43:53.655024	2026-06-02 02:21:43.254805	\N	\N	t
\.


--
-- Data for Name: dataset_bronze_configs; Type: TABLE DATA; Schema: datasets; Owner: -
--

COPY datasets.dataset_bronze_configs (id, dataset_id, name, description, bronze_bucket, bronze_path_prefix, output_format, partition_columns, config_snapshot, last_ingestion_time, last_ingestion_status, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
\.


--
-- Data for Name: dataset_ingestion_groups; Type: TABLE DATA; Schema: datasets; Owner: -
--

COPY datasets.dataset_ingestion_groups (id, bronze_config_id, connection_id, group_name, group_order, output_path, generated_sql, status, last_execution_time, rows_ingested, error_message, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
\.


--
-- Data for Name: ingestion_group_tables; Type: TABLE DATA; Schema: datasets; Owner: -
--

COPY datasets.ingestion_group_tables (id, ingestion_group_id, table_id, table_alias, select_all_columns, selected_column_ids, is_primary_table, join_to_table_id, join_type, join_condition) FROM stdin;
\.


--
-- Data for Name: inter_source_links; Type: TABLE DATA; Schema: datasets; Owner: -
--

COPY datasets.inter_source_links (id, bronze_config_id, left_group_id, left_column_name, right_group_id, right_column_name, join_strategy, description, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
\.


--
-- Data for Name: silver_executions; Type: TABLE DATA; Schema: datasets; Owner: -
--

COPY datasets.silver_executions (id, config_id, status, started_at, finished_at, rows_processed, rows_output, output_path, error_message, execution_details, delta_version, write_mode_used, merge_keys_used, rows_inserted, rows_updated, rows_deleted, schema_hash, schema_changed, config_snapshot, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
10	3	SUCCESS	2026-07-13 22:22:09.658517+00	2026-07-13 22:22:19.24278+00	15634	15634	s3a://datafabric-silver/3-dermexp3_silver_harmonized_v2	\N	\N	0	overwrite	\N	15634	\N	\N	\N	f	{"name": "dermexp3_silver_harmonized_v2", "description": "Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [8, 9, 10, 11, 12], "filters": null, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-13T22:22:09.658517"}	2026-07-13 22:22:09.65518	2026-07-13 22:22:19.247784	\N	\N	t
4	1	SUCCESS	2026-05-24 03:24:02.600116+00	2026-05-24 03:24:06.121635+00	1507	1430	s3a://datafabric-silver/1-hospital_federation_persistent	\N	\N	2	overwrite	\N	1430	\N	\N	\N	f	{"name": "hospital_federation_persistent", "description": "Persistent Silver dataset joining IDA (MySQL) and CMPD (PostgreSQL) via federated CPF. Reads always from the latest Bronze version. Applies semantic unification (Patient CPF + Biological Sex), CPF formatting, accent removal on names, and uppercase smoking status. Filters ensure only records with complete CMPD data and valid BMI are included.", "source_bronze_config_id": 1, "source_bronze_version": null, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [1, 3], "filters": {"logic": "AND", "conditions": [{"column_id": 48, "operator": "IS NOT NULL"}, {"column_id": 50, "operator": ">=", "value": "20"}]}, "column_transformations": [{"column_id": 39, "type": "template", "rule_id": 2}, {"column_id": 196, "type": "remove_accents"}, {"column_id": 37, "type": "remove_accents"}, {"column_id": 38, "type": "remove_accents"}, {"column_id": 48, "type": "uppercase"}], "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": true, "write_mode": "overwrite", "snapshot_at": "2026-05-24T03:24:02.600116"}	2026-05-24 03:24:02.596754	2026-05-24 03:24:06.124194	\N	\N	t
9	2	FAILED	2026-07-13 22:20:29.571408+00	2026-07-13 22:20:46.734987+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	{"name": "dermexp3_silver_harmonized_v1", "description": "Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved", "source_bronze_config_id": 13, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [8, 9, 10, 11, 12], "filters": null, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-13T22:20:29.571408"}	2026-07-13 22:20:29.567766	2026-07-13 22:20:46.737643	\N	\N	t
11	3	SUCCESS	2026-07-13 22:25:47.505569+00	2026-07-13 22:25:56.389064+00	15634	15634	s3a://datafabric-silver/3-dermexp3_silver_harmonized_v2	\N	\N	1	overwrite	\N	15634	\N	\N	\N	f	{"name": "dermexp3_silver_harmonized_v2", "description": "Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [8, 9, 10, 11, 12], "filters": null, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-13T22:25:47.505569"}	2026-07-13 22:25:47.500723	2026-07-13 22:25:56.392071	\N	\N	t
12	3	SUCCESS	2026-07-13 22:25:56.604796+00	2026-07-13 22:26:05.209869+00	15634	15634	s3a://datafabric-silver/3-dermexp3_silver_harmonized_v2	\N	\N	2	overwrite	\N	15634	\N	\N	\N	f	{"name": "dermexp3_silver_harmonized_v2", "description": "Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [8, 9, 10, 11, 12], "filters": null, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-13T22:25:56.604796"}	2026-07-13 22:25:56.602052	2026-07-13 22:26:05.211582	\N	\N	t
13	4	SUCCESS	2026-07-14 03:20:36.985043+00	2026-07-14 03:20:50.738887+00	15634	15634	s3a://datafabric-silver/4-dermexp3_silver_harmonized_v3	\N	\N	0	overwrite	\N	15634	\N	\N	\N	f	{"name": "dermexp3_silver_harmonized_v3", "description": "Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": null, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-14T03:20:36.985043"}	2026-07-14 03:20:36.982523	2026-07-14 03:20:50.741462	\N	\N	t
14	4	SUCCESS	2026-07-14 03:20:51.033991+00	2026-07-14 03:20:59.425359+00	15634	15634	s3a://datafabric-silver/4-dermexp3_silver_harmonized_v3	\N	\N	1	overwrite	\N	15634	\N	\N	\N	f	{"name": "dermexp3_silver_harmonized_v3", "description": "Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": null, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-14T03:20:51.033991"}	2026-07-14 03:20:51.030133	2026-07-14 03:20:59.427024	\N	\N	t
15	4	SUCCESS	2026-07-14 03:20:59.740766+00	2026-07-14 03:21:08.081995+00	15634	15634	s3a://datafabric-silver/4-dermexp3_silver_harmonized_v3	\N	\N	2	overwrite	\N	15634	\N	\N	\N	f	{"name": "dermexp3_silver_harmonized_v3", "description": "Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": null, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-14T03:20:59.740766"}	2026-07-14 03:20:59.737791	2026-07-14 03:21:08.083584	\N	\N	t
16	5	SUCCESS	2026-07-16 02:01:18.079464+00	2026-07-16 02:01:42.365365+00	15634	2689	s3a://datafabric-silver/5-dermexp3_governed_derm_cancer_histo_v1	\N	\N	0	overwrite	\N	2689	\N	\N	\N	f	{"name": "dermexp3_governed_derm_cancer_histo_v1", "description": "Governed dermatology condition G2_DERM_CANCER_HISTO: Histopathology-confirmed dermoscopic cancer cohort. Frozen protocol derm-governed-cohorts-v1.0.0.", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": {"logic": "AND", "conditions": [{"column_id": null, "column_name": "image_type_harmonized", "operator": "=", "value": "DERMOSCOPIC", "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_harmonized", "operator": "IN", "value": ["MEL", "BCC", "SCC"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_confirm_type", "operator": "=", "value": "histopathology", "value_min": null, "value_max": null}]}, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-16T02:01:18.079464"}	2026-07-16 02:01:18.076287	2026-07-16 02:01:42.369273	\N	\N	t
17	6	SUCCESS	2026-07-16 02:02:52.689389+00	2026-07-16 02:03:00.640069+00	15634	1299	s3a://datafabric-silver/6-dermexp3_governed_clinical_cancer_phototype_v1	\N	\N	0	overwrite	\N	1299	\N	\N	\N	f	{"name": "dermexp3_governed_clinical_cancer_phototype_v1", "description": "Governed dermatology condition G3_CLINICAL_CANCER_PHOTOTYPE: Clinical cancer cohort with recorded phototype. Frozen protocol derm-governed-cohorts-v1.0.0.", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": {"logic": "AND", "conditions": [{"column_id": null, "column_name": "image_type_harmonized", "operator": "IN", "value": ["CLINICAL_OVERVIEW", "CLINICAL_CLOSE_UP"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_harmonized", "operator": "IN", "value": ["MEL", "BCC", "SCC"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_confirm_type", "operator": "=", "value": "histopathology", "value_min": null, "value_max": null}, {"column_id": null, "column_name": "fitzpatrick_skin_type_harmonized", "operator": "IN", "value": ["I", "II", "III", "IV", "V", "VI"], "value_min": null, "value_max": null}]}, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-16T02:02:52.689389"}	2026-07-16 02:02:52.688306	2026-07-16 02:03:00.643061	\N	\N	t
18	7	SUCCESS	2026-07-16 02:03:00.889769+00	2026-07-16 02:03:09.155167+00	15634	3914	s3a://datafabric-silver/7-dermexp3_governed_cc_by_policy_v1	\N	\N	0	overwrite	\N	3914	\N	\N	\N	f	{"name": "dermexp3_governed_cc_by_policy_v1", "description": "Governed dermatology condition G4_CC_BY_POLICY: Experiment-defined CC-BY allowlist view. Frozen protocol derm-governed-cohorts-v1.0.0.", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": {"logic": "AND", "conditions": [{"column_id": null, "column_name": "copyright_license", "operator": "=", "value": "CC-BY", "value_min": null, "value_max": null}]}, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-16T02:03:00.889769"}	2026-07-16 02:03:00.887236	2026-07-16 02:03:09.15654	\N	\N	t
19	5	SUCCESS	2026-07-16 02:03:09.980358+00	2026-07-16 02:03:17.054487+00	15634	2689	s3a://datafabric-silver/5-dermexp3_governed_derm_cancer_histo_v1	\N	\N	1	overwrite	\N	2689	\N	\N	\N	f	{"name": "dermexp3_governed_derm_cancer_histo_v1", "description": "Governed dermatology condition G2_DERM_CANCER_HISTO: Histopathology-confirmed dermoscopic cancer cohort. Frozen protocol derm-governed-cohorts-v1.0.0.", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": {"logic": "AND", "conditions": [{"column_id": null, "column_name": "image_type_harmonized", "operator": "=", "value": "DERMOSCOPIC", "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_harmonized", "operator": "IN", "value": ["MEL", "BCC", "SCC"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_confirm_type", "operator": "=", "value": "histopathology", "value_min": null, "value_max": null}]}, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-16T02:03:09.980358"}	2026-07-16 02:03:09.977407	2026-07-16 02:03:17.058007	\N	\N	t
20	5	SUCCESS	2026-07-16 02:03:17.14353+00	2026-07-16 02:03:25.086802+00	15634	2689	s3a://datafabric-silver/5-dermexp3_governed_derm_cancer_histo_v1	\N	\N	2	overwrite	\N	2689	\N	\N	\N	f	{"name": "dermexp3_governed_derm_cancer_histo_v1", "description": "Governed dermatology condition G2_DERM_CANCER_HISTO: Histopathology-confirmed dermoscopic cancer cohort. Frozen protocol derm-governed-cohorts-v1.0.0.", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": {"logic": "AND", "conditions": [{"column_id": null, "column_name": "image_type_harmonized", "operator": "=", "value": "DERMOSCOPIC", "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_harmonized", "operator": "IN", "value": ["MEL", "BCC", "SCC"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_confirm_type", "operator": "=", "value": "histopathology", "value_min": null, "value_max": null}]}, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-16T02:03:17.143530"}	2026-07-16 02:03:17.139233	2026-07-16 02:03:25.088173	\N	\N	t
21	6	SUCCESS	2026-07-16 02:03:25.164788+00	2026-07-16 02:03:30.258344+00	15634	1299	s3a://datafabric-silver/6-dermexp3_governed_clinical_cancer_phototype_v1	\N	\N	1	overwrite	\N	1299	\N	\N	\N	f	{"name": "dermexp3_governed_clinical_cancer_phototype_v1", "description": "Governed dermatology condition G3_CLINICAL_CANCER_PHOTOTYPE: Clinical cancer cohort with recorded phototype. Frozen protocol derm-governed-cohorts-v1.0.0.", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": {"logic": "AND", "conditions": [{"column_id": null, "column_name": "image_type_harmonized", "operator": "IN", "value": ["CLINICAL_OVERVIEW", "CLINICAL_CLOSE_UP"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_harmonized", "operator": "IN", "value": ["MEL", "BCC", "SCC"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_confirm_type", "operator": "=", "value": "histopathology", "value_min": null, "value_max": null}, {"column_id": null, "column_name": "fitzpatrick_skin_type_harmonized", "operator": "IN", "value": ["I", "II", "III", "IV", "V", "VI"], "value_min": null, "value_max": null}]}, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-16T02:03:25.164788"}	2026-07-16 02:03:25.162694	2026-07-16 02:03:30.259994	\N	\N	t
1	1	FAILED	2026-05-24 03:09:24.980076+00	2026-05-24 03:09:31.807793+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	{"name": "hospital_federation_persistent", "description": "Persistent Silver dataset joining IDA (MySQL) and CMPD (PostgreSQL) via federated CPF. Reads always from the latest Bronze version. Applies semantic unification (Patient CPF + Biological Sex), CPF formatting, accent removal on names, and uppercase smoking status. Filters ensure only records with complete CMPD data and valid BMI are included.", "source_bronze_config_id": 1, "source_bronze_version": null, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [1, 3], "filters": {"logic": "AND", "conditions": [{"column_id": 48, "column_name": null, "operator": "IS NOT NULL", "value": null, "value_min": null, "value_max": null}, {"column_id": 50, "column_name": null, "operator": ">=", "value": 15.0, "value_min": null, "value_max": null}]}, "column_transformations": [{"column_id": 195, "type": "template", "rule_id": 1}, {"column_id": 196, "type": "remove_accents", "rule_id": null}, {"column_id": 37, "type": "remove_accents", "rule_id": null}, {"column_id": 38, "type": "remove_accents", "rule_id": null}, {"column_id": 48, "type": "uppercase", "rule_id": null}], "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": true, "write_mode": "overwrite", "snapshot_at": "2026-05-24T03:09:24.980076"}	2026-05-24 03:09:24.975047	2026-05-24 03:09:31.812476	\N	\N	t
2	1	SUCCESS	2026-05-24 03:10:03.041499+00	2026-05-24 03:10:13.809928+00	1507	1505	s3a://datafabric-silver/1-hospital_federation_persistent	\N	\N	0	overwrite	\N	1505	\N	\N	\N	f	{"name": "hospital_federation_persistent", "description": "Persistent Silver dataset joining IDA (MySQL) and CMPD (PostgreSQL) via federated CPF. Reads always from the latest Bronze version. Applies semantic unification (Patient CPF + Biological Sex), CPF formatting, accent removal on names, and uppercase smoking status. Filters ensure only records with complete CMPD data and valid BMI are included.", "source_bronze_config_id": 1, "source_bronze_version": null, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [1, 3], "filters": {"logic": "AND", "conditions": [{"column_id": 48, "column_name": null, "operator": "IS NOT NULL", "value": null, "value_min": null, "value_max": null}, {"column_id": 50, "column_name": null, "operator": ">=", "value": 15.0, "value_min": null, "value_max": null}]}, "column_transformations": [{"column_id": 195, "type": "template", "rule_id": 1}, {"column_id": 196, "type": "remove_accents", "rule_id": null}, {"column_id": 37, "type": "remove_accents", "rule_id": null}, {"column_id": 38, "type": "remove_accents", "rule_id": null}, {"column_id": 48, "type": "uppercase", "rule_id": null}], "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": true, "write_mode": "overwrite", "snapshot_at": "2026-05-24T03:10:03.041499"}	2026-05-24 03:10:03.039828	2026-05-24 03:10:13.812358	\N	\N	t
3	1	SUCCESS	2026-05-24 03:16:16.743768+00	2026-05-24 03:16:20.092865+00	1507	1430	s3a://datafabric-silver/1-hospital_federation_persistent	\N	\N	1	overwrite	\N	1430	\N	\N	\N	f	{"name": "hospital_federation_persistent", "description": "Persistent Silver dataset joining IDA (MySQL) and CMPD (PostgreSQL) via federated CPF. Reads always from the latest Bronze version. Applies semantic unification (Patient CPF + Biological Sex), CPF formatting, accent removal on names, and uppercase smoking status. Filters ensure only records with complete CMPD data and valid BMI are included.", "source_bronze_config_id": 1, "source_bronze_version": null, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [1, 3], "filters": {"logic": "AND", "conditions": [{"column_id": 48, "operator": "IS NOT NULL"}, {"column_id": 50, "operator": ">=", "value": "20"}]}, "column_transformations": [{"column_id": 195, "type": "template", "rule_id": 1}, {"column_id": 196, "type": "remove_accents"}, {"column_id": 37, "type": "remove_accents"}, {"column_id": 38, "type": "remove_accents"}, {"column_id": 48, "type": "uppercase"}], "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": true, "write_mode": "overwrite", "snapshot_at": "2026-05-24T03:16:16.743768"}	2026-05-24 03:16:16.74058	2026-05-24 03:16:20.0978	\N	\N	t
5	1	SUCCESS	2026-05-24 03:32:10.252507+00	2026-05-24 03:32:46.884881+00	1507	1430	s3a://datafabric-silver/1-hospital_federation_persistent	\N	\N	3	overwrite	\N	1430	\N	\N	\N	f	{"name": "hospital_federation_persistent", "description": "Persistent Silver dataset joining IDA (MySQL) and CMPD (PostgreSQL) via federated CPF. Reads always from the latest Bronze version. Applies semantic unification (Patient CPF + Biological Sex), CPF formatting, accent removal on names, and uppercase smoking status. Filters ensure only records with complete CMPD data and valid BMI are included.", "source_bronze_config_id": 1, "source_bronze_version": null, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [1, 3], "filters": {"logic": "AND", "conditions": [{"column_id": 48, "operator": "IS NOT NULL"}, {"column_id": 50, "operator": ">=", "value": "20"}]}, "column_transformations": [{"column_id": 39, "type": "template", "rule_id": 2}, {"column_id": 196, "type": "remove_accents"}, {"column_id": 37, "type": "remove_accents"}, {"column_id": 38, "type": "remove_accents"}, {"column_id": 48, "type": "uppercase"}], "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": true, "write_mode": "overwrite", "snapshot_at": "2026-05-24T03:32:10.252507"}	2026-05-24 03:32:10.244451	2026-05-24 03:32:46.888038	\N	\N	t
6	2	FAILED	2026-07-13 22:19:23.421193+00	2026-07-13 22:19:43.831687+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	{"name": "dermexp3_silver_harmonized_v1", "description": "Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved", "source_bronze_config_id": 13, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [8, 9, 10, 11, 12], "filters": null, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-13T22:19:23.421193"}	2026-07-13 22:19:23.417808	2026-07-13 22:19:43.83806	\N	\N	t
7	2	FAILED	2026-07-13 22:19:45.856205+00	2026-07-13 22:20:02.611979+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	{"name": "dermexp3_silver_harmonized_v1", "description": "Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved", "source_bronze_config_id": 13, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [8, 9, 10, 11, 12], "filters": null, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-13T22:19:45.856205"}	2026-07-13 22:19:45.854153	2026-07-13 22:20:02.616534	\N	\N	t
8	2	FAILED	2026-07-13 22:20:06.650152+00	2026-07-13 22:20:23.54009+00	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	{"name": "dermexp3_silver_harmonized_v1", "description": "Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved", "source_bronze_config_id": 13, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [8, 9, 10, 11, 12], "filters": null, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-13T22:20:06.650152"}	2026-07-13 22:20:06.645633	2026-07-13 22:20:23.542472	\N	\N	t
22	6	SUCCESS	2026-07-16 02:03:30.330432+00	2026-07-16 02:03:37.348801+00	15634	1299	s3a://datafabric-silver/6-dermexp3_governed_clinical_cancer_phototype_v1	\N	\N	2	overwrite	\N	1299	\N	\N	\N	f	{"name": "dermexp3_governed_clinical_cancer_phototype_v1", "description": "Governed dermatology condition G3_CLINICAL_CANCER_PHOTOTYPE: Clinical cancer cohort with recorded phototype. Frozen protocol derm-governed-cohorts-v1.0.0.", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": {"logic": "AND", "conditions": [{"column_id": null, "column_name": "image_type_harmonized", "operator": "IN", "value": ["CLINICAL_OVERVIEW", "CLINICAL_CLOSE_UP"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_harmonized", "operator": "IN", "value": ["MEL", "BCC", "SCC"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_confirm_type", "operator": "=", "value": "histopathology", "value_min": null, "value_max": null}, {"column_id": null, "column_name": "fitzpatrick_skin_type_harmonized", "operator": "IN", "value": ["I", "II", "III", "IV", "V", "VI"], "value_min": null, "value_max": null}]}, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-16T02:03:30.330432"}	2026-07-16 02:03:30.32804	2026-07-16 02:03:37.352376	\N	\N	t
23	7	SUCCESS	2026-07-16 02:03:37.406352+00	2026-07-16 02:03:43.344277+00	15634	3914	s3a://datafabric-silver/7-dermexp3_governed_cc_by_policy_v1	\N	\N	1	overwrite	\N	3914	\N	\N	\N	f	{"name": "dermexp3_governed_cc_by_policy_v1", "description": "Governed dermatology condition G4_CC_BY_POLICY: Experiment-defined CC-BY allowlist view. Frozen protocol derm-governed-cohorts-v1.0.0.", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": {"logic": "AND", "conditions": [{"column_id": null, "column_name": "copyright_license", "operator": "=", "value": "CC-BY", "value_min": null, "value_max": null}]}, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-16T02:03:37.406352"}	2026-07-16 02:03:37.405192	2026-07-16 02:03:43.345738	\N	\N	t
24	7	SUCCESS	2026-07-16 02:03:43.417784+00	2026-07-16 02:03:51.537694+00	15634	3914	s3a://datafabric-silver/7-dermexp3_governed_cc_by_policy_v1	\N	\N	2	overwrite	\N	3914	\N	\N	\N	f	{"name": "dermexp3_governed_cc_by_policy_v1", "description": "Governed dermatology condition G4_CC_BY_POLICY: Experiment-defined CC-BY allowlist view. Frozen protocol derm-governed-cohorts-v1.0.0.", "source_bronze_config_id": 14, "source_bronze_version": 0, "source_bronze_dataset_id": null, "silver_bucket": "datafabric-silver", "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": {"logic": "AND", "conditions": [{"column_id": null, "column_name": "copyright_license", "operator": "=", "value": "CC-BY", "value_min": null, "value_max": null}]}, "column_transformations": null, "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false, "write_mode": "overwrite", "snapshot_at": "2026-07-16T02:03:43.417784"}	2026-07-16 02:03:43.415184	2026-07-16 02:03:51.541497	\N	\N	t
\.


--
-- Data for Name: silver_normalization_rules; Type: TABLE DATA; Schema: datasets; Owner: -
--

COPY datasets.silver_normalization_rules (id, name, description, template, regex_pattern, regex_replacement, pre_process, regex_entrada, template_saida, case_transforms, is_builtin, is_active, example_input, example_output, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	cpf_formatted	Formats an 11-digit CPF string (no punctuation) into the standard Brazilian CPF format: 000.000.000-00	{d3}.{d3}.{d3}-{d2}	^(\\d{3})(\\d{3})(\\d{3})(\\d{2})$	$1.$2.$3-$4	digits_only	(?P<g1>\\d{3})(?P<g2>\\d{3})(?P<g3>\\d{3})(?P<g4>\\d{2})	{g1}.{g2}.{g3}-{g4}	null	f	t	12345678901	123.456.789-01	2026-05-24 03:08:52.599801	2026-05-24 03:08:52.599801	\N	\N	t
2	birth_date_iso_slash	Normalises ISO date separators from hyphen to slash (YYYY-MM-DD → YYYY/MM/DD). Strips non-digits first, then re-inserts slashes. Note: reordering to DD/MM/YYYY is not supported by the template engine — use a python_rule transformation for that.	{d4}/{d2}/{d2}	^(\\d{4})(\\d{2})(\\d{2})$	$1/$2/$3	digits_only	(?P<g1>\\d{4})(?P<g2>\\d{2})(?P<g3>\\d{2})	{g1}/{g2}/{g3}	null	f	t	1968-07-22	1968/07/22	2026-05-24 03:22:11.736324	2026-05-24 03:22:11.736324	\N	\N	t
\.


--
-- Data for Name: silver_persistent_configs; Type: TABLE DATA; Schema: datasets; Owner: -
--

COPY datasets.silver_persistent_configs (id, name, description, source_bronze_config_id, source_bronze_version, source_bronze_dataset_id, silver_bucket, silver_path_prefix, column_group_ids, filters, column_transformations, image_labeling_config, llm_extractions, exclude_unified_source_columns, write_mode, merge_keys, merge_keys_source, current_delta_version, last_execution_time, last_execution_status, last_execution_rows, last_execution_error, is_active, config_snapshot, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
4	dermexp3_silver_harmonized_v3	Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved	14	0	\N	datafabric-silver	\N	[13, 14, 15, 16, 17]	null	null	null	null	f	OVERWRITE	\N	\N	2	2026-07-14 03:21:08.082018+00	SUCCESS	15634	\N	t	{"name": "dermexp3_silver_harmonized_v3", "description": "Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved", "source_bronze_config_id": 14, "source_bronze_version": 0, "silver_bucket": null, "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": null, "column_transformations": [], "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false}	2026-07-14 03:20:36.912442	2026-07-14 03:21:08.082379	\N	\N	t
3	dermexp3_silver_harmonized_v2	Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved	14	0	\N	datafabric-silver	\N	[8, 9, 10, 11, 12]	null	null	null	null	f	OVERWRITE	\N	\N	2	2026-07-13 22:26:05.2099+00	SUCCESS	15634	\N	t	{"name": "dermexp3_silver_harmonized_v2", "description": "Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved", "source_bronze_config_id": 14, "source_bronze_version": 0, "silver_bucket": null, "silver_path_prefix": null, "column_group_ids": [8, 9, 10, 11, 12], "filters": null, "column_transformations": [], "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false}	2026-07-13 22:22:09.614818	2026-07-13 22:26:05.210398	\N	\N	t
5	dermexp3_governed_derm_cancer_histo_v1	Governed dermatology condition G2_DERM_CANCER_HISTO: Histopathology-confirmed dermoscopic cancer cohort. Frozen protocol derm-governed-cohorts-v1.0.0.	14	0	\N	datafabric-silver	\N	[13, 14, 15, 16, 17]	{"logic": "AND", "conditions": [{"column_id": null, "column_name": "image_type_harmonized", "operator": "=", "value": "DERMOSCOPIC", "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_harmonized", "operator": "IN", "value": ["MEL", "BCC", "SCC"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_confirm_type", "operator": "=", "value": "histopathology", "value_min": null, "value_max": null}]}	null	null	null	f	OVERWRITE	\N	\N	2	2026-07-16 02:03:25.086829+00	SUCCESS	2689	\N	t	{"name": "dermexp3_governed_derm_cancer_histo_v1", "description": "Governed dermatology condition G2_DERM_CANCER_HISTO: Histopathology-confirmed dermoscopic cancer cohort. Frozen protocol derm-governed-cohorts-v1.0.0.", "source_bronze_config_id": 14, "source_bronze_version": 0, "silver_bucket": null, "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": {"logic": "AND", "conditions": [{"column_id": null, "column_name": "image_type_harmonized", "operator": "=", "value": "DERMOSCOPIC", "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_harmonized", "operator": "IN", "value": ["MEL", "BCC", "SCC"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_confirm_type", "operator": "=", "value": "histopathology", "value_min": null, "value_max": null}]}, "column_transformations": [], "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false}	2026-07-16 02:01:17.974341	2026-07-16 02:03:25.087191	\N	\N	t
6	dermexp3_governed_clinical_cancer_phototype_v1	Governed dermatology condition G3_CLINICAL_CANCER_PHOTOTYPE: Clinical cancer cohort with recorded phototype. Frozen protocol derm-governed-cohorts-v1.0.0.	14	0	\N	datafabric-silver	\N	[13, 14, 15, 16, 17]	{"logic": "AND", "conditions": [{"column_id": null, "column_name": "image_type_harmonized", "operator": "IN", "value": ["CLINICAL_OVERVIEW", "CLINICAL_CLOSE_UP"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_harmonized", "operator": "IN", "value": ["MEL", "BCC", "SCC"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_confirm_type", "operator": "=", "value": "histopathology", "value_min": null, "value_max": null}, {"column_id": null, "column_name": "fitzpatrick_skin_type_harmonized", "operator": "IN", "value": ["I", "II", "III", "IV", "V", "VI"], "value_min": null, "value_max": null}]}	null	null	null	f	OVERWRITE	\N	\N	2	2026-07-16 02:03:37.348828+00	SUCCESS	1299	\N	t	{"name": "dermexp3_governed_clinical_cancer_phototype_v1", "description": "Governed dermatology condition G3_CLINICAL_CANCER_PHOTOTYPE: Clinical cancer cohort with recorded phototype. Frozen protocol derm-governed-cohorts-v1.0.0.", "source_bronze_config_id": 14, "source_bronze_version": 0, "silver_bucket": null, "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": {"logic": "AND", "conditions": [{"column_id": null, "column_name": "image_type_harmonized", "operator": "IN", "value": ["CLINICAL_OVERVIEW", "CLINICAL_CLOSE_UP"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_harmonized", "operator": "IN", "value": ["MEL", "BCC", "SCC"], "value_min": null, "value_max": null}, {"column_id": null, "column_name": "diagnosis_confirm_type", "operator": "=", "value": "histopathology", "value_min": null, "value_max": null}, {"column_id": null, "column_name": "fitzpatrick_skin_type_harmonized", "operator": "IN", "value": ["I", "II", "III", "IV", "V", "VI"], "value_min": null, "value_max": null}]}, "column_transformations": [], "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false}	2026-07-16 02:02:52.53717	2026-07-16 02:03:37.349249	\N	\N	t
7	dermexp3_governed_cc_by_policy_v1	Governed dermatology condition G4_CC_BY_POLICY: Experiment-defined CC-BY allowlist view. Frozen protocol derm-governed-cohorts-v1.0.0.	14	0	\N	datafabric-silver	\N	[13, 14, 15, 16, 17]	{"logic": "AND", "conditions": [{"column_id": null, "column_name": "copyright_license", "operator": "=", "value": "CC-BY", "value_min": null, "value_max": null}]}	null	null	null	f	OVERWRITE	\N	\N	2	2026-07-16 02:03:51.53775+00	SUCCESS	3914	\N	t	{"name": "dermexp3_governed_cc_by_policy_v1", "description": "Governed dermatology condition G4_CC_BY_POLICY: Experiment-defined CC-BY allowlist view. Frozen protocol derm-governed-cohorts-v1.0.0.", "source_bronze_config_id": 14, "source_bronze_version": 0, "silver_bucket": null, "silver_path_prefix": null, "column_group_ids": [13, 14, 15, 16, 17], "filters": {"logic": "AND", "conditions": [{"column_id": null, "column_name": "copyright_license", "operator": "=", "value": "CC-BY", "value_min": null, "value_max": null}]}, "column_transformations": [], "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false}	2026-07-16 02:03:00.795307	2026-07-16 02:03:51.538131	\N	\N	t
1	hospital_federation_persistent	Persistent Silver dataset joining IDA (MySQL) and CMPD (PostgreSQL) via federated CPF. Reads always from the latest Bronze version. Applies semantic unification (Patient CPF + Biological Sex), CPF formatting, accent removal on names, and uppercase smoking status. Filters ensure only records with complete CMPD data and valid BMI are included.	1	\N	\N	datafabric-silver	\N	[1, 3]	{"logic": "AND", "conditions": [{"column_id": 48, "operator": "IS NOT NULL"}, {"column_id": 50, "operator": ">=", "value": "20"}]}	[{"column_id": 39, "type": "template", "rule_id": 2}, {"column_id": 196, "type": "remove_accents"}, {"column_id": 37, "type": "remove_accents"}, {"column_id": 38, "type": "remove_accents"}, {"column_id": 48, "type": "uppercase"}]	null	null	t	OVERWRITE	\N	\N	3	2026-05-24 03:32:46.884924+00	SUCCESS	1430	\N	t	{"name": "hospital_federation_persistent", "description": "Persistent Silver dataset joining IDA (MySQL) and CMPD (PostgreSQL) via federated CPF. Reads always from the latest Bronze version. Applies semantic unification (Patient CPF + Biological Sex), CPF formatting, accent removal on names, and uppercase smoking status. Filters ensure only records with complete CMPD data and valid BMI are included.", "source_bronze_config_id": 1, "source_bronze_version": null, "silver_bucket": null, "silver_path_prefix": null, "column_group_ids": [1, 3], "filters": {"logic": "AND", "conditions": [{"column_id": 48, "column_name": null, "operator": "IS NOT NULL", "value": null, "value_min": null, "value_max": null}, {"column_id": 50, "column_name": null, "operator": ">=", "value": 15.0, "value_min": null, "value_max": null}]}, "column_transformations": [{"column_id": 195, "type": "template", "rule_id": 1}, {"column_id": 196, "type": "remove_accents", "rule_id": null}, {"column_id": 37, "type": "remove_accents", "rule_id": null}, {"column_id": 38, "type": "remove_accents", "rule_id": null}, {"column_id": 48, "type": "uppercase", "rule_id": null}], "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": true}	2026-05-24 03:09:06.330874	2026-05-24 03:32:46.886376	\N	\N	t
2	dermexp3_silver_harmonized_v1	Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved	13	0	\N	datafabric-silver	\N	[8, 9, 10, 11, 12]	null	null	null	null	f	OVERWRITE	\N	\N	\N	2026-07-13 22:20:46.735787+00	FAILED	\N	\N	t	{"name": "dermexp3_silver_harmonized_v1", "description": "Union-based dermatology Silver cohort with versioned semantic mappings and original fields preserved", "source_bronze_config_id": 13, "source_bronze_version": 0, "silver_bucket": null, "silver_path_prefix": null, "column_group_ids": [8, 9, 10, 11, 12], "filters": null, "column_transformations": [], "image_labeling_config": null, "llm_extractions": null, "exclude_unified_source_columns": false}	2026-07-13 22:19:23.30455	2026-07-13 22:20:46.736607	\N	\N	t
\.


--
-- Data for Name: silver_virtualized_configs; Type: TABLE DATA; Schema: datasets; Owner: -
--

COPY datasets.silver_virtualized_configs (id, name, description, tables, column_group_ids, relationship_ids, filters, column_transformations, exclude_unified_source_columns, is_active, generated_sql, sql_generated_at, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
\.


--
-- Data for Name: source_relationships; Type: TABLE DATA; Schema: datasets; Owner: -
--

COPY datasets.source_relationships (id, left_table_id, left_column_id, right_table_id, right_column_id, relationship_type, join_strategy, custom_condition, is_verified, notes, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
\.


--
-- Data for Name: recipient_access_logs; Type: TABLE DATA; Schema: delta_sharing; Owner: -
--

COPY delta_sharing.recipient_access_logs (id, recipient_id, share_id, schema_id, table_id, operation, request_method, request_path, request_query_params, request_body, response_status_code, response_size_bytes, processing_time_ms, client_ip, user_agent, accessed_at, error_message) FROM stdin;
1	4	\N	\N	\N	list_shares	GET	/seed/request	\N	\N	200	\N	5	127.0.0.1	datafabric-seed	2026-07-16 02:04:18.284465+00	\N
2	4	\N	\N	\N	list_tables	GET	/seed/request	\N	\N	200	\N	14	127.0.0.1	datafabric-seed	2026-07-16 02:04:18.323214+00	\N
3	4	\N	\N	\N	get_table_version	GET	/seed/request	\N	\N	200	\N	7	127.0.0.1	datafabric-seed	2026-07-16 02:04:18.355919+00	\N
4	4	\N	\N	\N	get_table_metadata	GET	/seed/request	\N	\N	200	\N	4	127.0.0.1	datafabric-seed	2026-07-16 02:04:18.383391+00	\N
5	4	\N	\N	\N	query_table	POST	/seed/request	\N	\N	200	\N	17	127.0.0.1	datafabric-seed	2026-07-16 02:04:21.814726+00	\N
6	4	\N	\N	\N	get_table_version	GET	/seed/request	\N	\N	200	\N	26	127.0.0.1	datafabric-seed	2026-07-16 02:04:22.212887+00	\N
7	4	\N	\N	\N	get_table_metadata	GET	/seed/request	\N	\N	200	\N	3	127.0.0.1	datafabric-seed	2026-07-16 02:04:22.26381+00	\N
8	4	\N	\N	\N	query_table	POST	/seed/request	\N	\N	200	\N	26	127.0.0.1	datafabric-seed	2026-07-16 02:04:22.501571+00	\N
9	4	\N	\N	\N	get_table_version	GET	/seed/request	\N	\N	200	\N	20	127.0.0.1	datafabric-seed	2026-07-16 02:04:22.80985+00	\N
10	4	\N	\N	\N	get_table_metadata	GET	/seed/request	\N	\N	200	\N	3	127.0.0.1	datafabric-seed	2026-07-16 02:04:22.852559+00	\N
11	4	\N	\N	\N	query_table	POST	/seed/request	\N	\N	200	\N	19	127.0.0.1	datafabric-seed	2026-07-16 02:04:23.059448+00	\N
12	4	\N	\N	\N	list_shares	GET	/seed/request	\N	\N	200	\N	1	127.0.0.1	datafabric-seed	2026-07-16 02:05:15.39396+00	\N
13	4	\N	\N	\N	list_tables	GET	/seed/request	\N	\N	200	\N	6	127.0.0.1	datafabric-seed	2026-07-16 02:05:15.407833+00	\N
14	4	\N	\N	\N	get_table_version	GET	/seed/request	\N	\N	200	\N	2	127.0.0.1	datafabric-seed	2026-07-16 02:05:15.425072+00	\N
15	4	\N	\N	\N	get_table_metadata	GET	/seed/request	\N	\N	200	\N	2	127.0.0.1	datafabric-seed	2026-07-16 02:05:15.437923+00	\N
16	4	\N	\N	\N	query_table	POST	/seed/request	\N	\N	200	\N	21	127.0.0.1	datafabric-seed	2026-07-16 02:05:15.565645+00	\N
17	4	\N	\N	\N	get_table_version	GET	/seed/request	\N	\N	200	\N	15	127.0.0.1	datafabric-seed	2026-07-16 02:05:15.74566+00	\N
18	4	\N	\N	\N	get_table_metadata	GET	/seed/request	\N	\N	200	\N	1	127.0.0.1	datafabric-seed	2026-07-16 02:05:15.772985+00	\N
19	4	\N	\N	\N	query_table	POST	/seed/request	\N	\N	200	\N	16	127.0.0.1	datafabric-seed	2026-07-16 02:05:15.890369+00	\N
20	4	\N	\N	\N	get_table_version	GET	/seed/request	\N	\N	200	\N	16	127.0.0.1	datafabric-seed	2026-07-16 02:05:16.068901+00	\N
21	4	\N	\N	\N	get_table_metadata	GET	/seed/request	\N	\N	200	\N	2	127.0.0.1	datafabric-seed	2026-07-16 02:05:16.101248+00	\N
22	4	\N	\N	\N	query_table	POST	/seed/request	\N	\N	200	\N	11	127.0.0.1	datafabric-seed	2026-07-16 02:05:16.252617+00	\N
23	5	\N	\N	\N	list_schemas	GET	/seed/request	\N	\N	404	\N	9	127.0.0.1	datafabric-seed	2026-07-16 02:05:16.44121+00	\N
\.


--
-- Data for Name: recipient_shares; Type: TABLE DATA; Schema: delta_sharing; Owner: -
--

COPY delta_sharing.recipient_shares (recipient_id, share_id) FROM stdin;
1	1
1	3
2	1
2	2
2	3
3	1
4	4
\.


--
-- Data for Name: recipients; Type: TABLE DATA; Schema: delta_sharing; Owner: -
--

COPY delta_sharing.recipients (id, identifier, name, email, organization_name, authentication_type, bearer_token, token_expiry, is_active, max_requests_per_hour, max_downloads_per_day, access_logged, data_usage_agreement_accepted, agreement_accepted_at, contact_info, notes, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	recipient-1	Destinatário de teste 1	recipient-1@example.test	Organização de teste	bearer_token	dev-recipient-token-1	\N	t	1000	50	t	f	\N	\N	\N	2026-05-24 03:42:35.075889	2026-05-24 03:42:35.075889	\N	\N	t
2	recipient-2	Destinatário de teste 2	recipient-2@example.test	Organização de teste	bearer_token	dev-recipient-token-2	\N	t	5000	500	t	f	\N	\N	\N	2026-05-24 03:42:35.189738	2026-05-24 03:42:35.189738	\N	\N	t
3	recipient-3	Destinatário de teste 3	recipient-3@example.test	Organização de teste	bearer_token	dev-recipient-token-3	\N	t	200	10	t	f	\N	\N	\N	2026-05-24 03:42:35.290476	2026-05-24 03:42:35.290476	\N	\N	t
4	recipient-4	Destinatário de teste 4	\N	Organização de teste	bearer_token	dev-recipient-token-4	\N	t	1000	1000	t	f	\N	\N	\N	2026-07-16 02:03:09.811637	2026-07-16 02:03:09.811637	\N	\N	t
5	recipient-5	Destinatário de teste 5	\N	Organização de teste	bearer_token	dev-recipient-token-5	\N	t	1000	1000	t	f	\N	\N	\N	2026-07-16 02:03:09.909732	2026-07-16 02:03:09.909732	\N	\N	t
\.


--
-- Data for Name: share_schemas; Type: TABLE DATA; Schema: delta_sharing; Owner: -
--

COPY delta_sharing.share_schemas (id, share_id, name, description, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	1	hospital_data	Harmonized hospital data from IDA-CMPD federation	2026-05-24 03:41:46.044974	2026-05-24 03:41:46.044974	\N	\N	t
2	2	hospital_data	Raw unified hospital data from persistent Bronze ingestion	2026-05-24 03:41:46.229564	2026-05-24 03:41:46.229564	\N	\N	t
3	3	hospital_data	On-demand federated queries via Bronze virtualized config	2026-05-24 03:41:46.379259	2026-05-24 03:41:46.379259	\N	\N	t
4	4	cohorts	Governed cohort conditions G2-G4	2026-07-16 02:03:09.341171	2026-07-16 02:03:09.341171	\N	\N	t
\.


--
-- Data for Name: share_table_files; Type: TABLE DATA; Schema: delta_sharing; Owner: -
--

COPY delta_sharing.share_table_files (id, table_id, file_path, file_size_bytes, modification_time, data_change, partition_values, num_records, min_values, max_values, null_count, created_at_version, removed_at_version, storage_url, content_length, etag) FROM stdin;
\.


--
-- Data for Name: share_table_versions; Type: TABLE DATA; Schema: delta_sharing; Owner: -
--

COPY delta_sharing.share_table_versions (id, table_id, version, "timestamp", operation, description, protocol_version, table_metadata, schema_string, add_files, remove_files, num_files, total_size_bytes, num_records) FROM stdin;
\.


--
-- Data for Name: share_tables; Type: TABLE DATA; Schema: delta_sharing; Owner: -
--

COPY delta_sharing.share_tables (id, schema_id, name, description, dataset_id, source_type, bronze_persistent_config_id, silver_persistent_config_id, bronze_virtualized_config_id, silver_virtualized_config_id, status, share_mode, filter_condition, current_version, min_reader_version, min_writer_version, pinned_delta_version, table_format, partition_columns, schema_string, table_properties, storage_location, storage_credentials_id, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	1	hospital_federation_silver	Harmonized and normalized hospital records from IDA and CMPD with unified CPF key and biological sex equivalence	1	SILVER	\N	1	\N	\N	ACTIVE	full	\N	3	1	1	\N	delta	\N	\N	\N	datafabric-silver/1-hospital_federation_persistent	\N	2026-05-24 03:42:04.514194	2026-05-24 03:42:04.514194	\N	\N	t
2	2	hospital_federation_bronze	Raw ingested hospital data from IDA-CMPD federation with federated joins enabled	2	BRONZE	1	\N	\N	\N	ACTIVE	full	\N	3	1	1	\N	delta	\N	\N	\N	datafabric-bronze/1-hospital_federation_persistent/unified	\N	2026-05-24 03:42:09.314089	2026-05-24 03:42:09.314089	\N	\N	t
3	3	hospital_federation_virtual	On-demand federated view across IDA (MySQL) and CMPD (PostgreSQL) via Trino, no local materialization	\N	BRONZE_VIRTUALIZED	\N	\N	1	\N	ACTIVE	full	\N	1	1	1	\N	virtualized	\N	\N	\N	\N	\N	2026-05-24 03:42:15.024275	2026-05-24 03:42:15.024275	\N	\N	t
4	4	derm_cancer_histo	Frozen governed condition G2_DERM_CANCER_HISTO, pinned to Delta version 0	3	SILVER	\N	5	\N	\N	ACTIVE	full	\N	1	1	1	0	delta	\N	\N	\N	datafabric-silver/5-dermexp3_governed_derm_cancer_histo_v1	\N	2026-07-16 02:03:09.449793	2026-07-16 02:03:09.449793	\N	\N	t
5	4	clinical_cancer_phototype	Frozen governed condition G3_CLINICAL_CANCER_PHOTOTYPE, pinned to Delta version 0	4	SILVER	\N	6	\N	\N	ACTIVE	full	\N	1	1	1	0	delta	\N	\N	\N	datafabric-silver/6-dermexp3_governed_clinical_cancer_phototype_v1	\N	2026-07-16 02:03:09.624984	2026-07-16 02:03:09.624984	\N	\N	t
6	4	cc_by_policy	Frozen governed condition G4_CC_BY_POLICY, pinned to Delta version 0	5	SILVER	\N	7	\N	\N	ACTIVE	full	\N	1	1	1	0	delta	\N	\N	\N	datafabric-silver/7-dermexp3_governed_cc_by_policy_v1	\N	2026-07-16 02:03:09.707677	2026-07-16 02:03:09.707677	\N	\N	t
\.


--
-- Data for Name: shares; Type: TABLE DATA; Schema: delta_sharing; Owner: -
--

COPY delta_sharing.shares (id, name, description, organization_id, status, owner_email, contact_info, terms_of_use, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	clinical-analytics	Silver clean data for clinical teams	1	ACTIVE	\N	\N	\N	2026-05-24 03:37:26.720274	2026-05-24 03:41:04.065239	\N	\N	t
2	raw-hospital-data	Bronze persistent raw hospital data from IDA and CMPD federation	1	ACTIVE	\N	\N	\N	2026-05-24 03:37:59.439958	2026-05-24 03:41:12.966408	\N	\N	t
3	data-exploration	Bronze virtualized on-demand federated queries across IDA and CMPD	1	ACTIVE	\N	\N	\N	2026-05-24 03:38:17.280877	2026-05-24 03:41:12.988762	\N	\N	t
4	dermexp3_governed_release_v1	Pinned governed dermatology cohorts for reproducibility review	1	ACTIVE	owner@example.test	\N	Research artifact; source license labels and original provenance are retained.	2026-07-16 02:03:09.255543	2026-07-16 02:03:09.255543	\N	\N	t
\.


--
-- Data for Name: column_groups; Type: TABLE DATA; Schema: equivalence; Owner: -
--

COPY equivalence.column_groups (id, name, description, semantic_domain_id, data_dictionary_term_id, properties, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
2	Patient Date of Birth	Birth date across both hospital systems. IDA stores it as data_nascimento, CMPD as nascimento. Both are DATE type — semantically identical, no transformation needed.	1	3	{"requires_transformation": false}	2026-05-24 01:10:27.415262	2026-05-24 01:10:27.415262	\N	\N	t
4	Smoking Status	Patient smoking history from CMPD preventive care registry. Values nunca/ex/atual already match the dictionary standard — no transformation needed, but grouped for semantic discoverability.	5	11	{"requires_value_mapping": false}	2026-05-24 01:10:27.519991	2026-05-24 01:10:27.519991	\N	\N	t
5	Oncology Treatment Modality	Therapeutic modality used in oncology protocols at IDA. Maps modalidade_terapia column to the standard treatment_modality dictionary term.	4	9	{"source_system": "IDA", "clinical_area": "oncology"}	2026-05-24 01:10:27.566898	2026-05-24 01:10:27.566898	\N	\N	t
6	Diagnosis Code (ICD-10 / ICD-11)	Diagnosis classification codes across systems. IDA uses codigo_cid10 (ICD-10, CHAR 4) from histopathology reports; CMPD uses grupo_cid11 (ICD-11 group code) from clinical history. Conceptually equivalent — note the revision difference in notes.	2	5	{"cross_revision": true, "ida_revision": "ICD-10", "cmpd_revision": "ICD-11"}	2026-05-24 01:10:27.600528	2026-05-24 01:10:27.600528	\N	\N	t
7	Body Mass Index (BMI)	Patient BMI from CMPD preventive health registry. Stored as DECIMAL(5,2), calculated from weight and height. The indicadores_vitais table also carries peso_kg and altura_cm for back-calculation.	3	8	{"source_system": "CMPD", "derivable_from": ["peso_kg", "altura_cm"]}	2026-05-24 01:10:27.624986	2026-05-24 01:10:27.624986	\N	\N	t
1	patient_cpf	Cross-database federation key. Maps cpf_titular (IDA MySQL) to numero_cpf (CMPD PostgreSQL). Both CHAR(11) — no value transformation needed.	1	1	{"federation_key": true, "is_join_key": true, "cross_database": true}	2026-05-24 01:10:27.37706	2026-05-24 03:09:56.557041	\N	\N	t
3	biological_sex	Normalises patient sex and gender across systems. IDA uses sexo_biologico (M/F single char), CMPD uses genero_identidade (masculino/feminino). Value mappings convert CMPD values to the standard M/F/I.	1	2	{"requires_value_mapping": true, "source_formats": ["single_char", "full_text"]}	2026-05-24 01:10:27.470141	2026-05-24 03:09:56.599943	\N	\N	t
8	diagnosis_harmonized	Cross-source diagnosis_harmonized for Dermatology Experiment 3	6	12	{"experiment": "dermatology_exp3", "catalog_version": "derm-semantic-v1.0.0"}	2026-07-13 22:18:41.611767	2026-07-13 22:18:41.611767	\N	\N	t
9	recorded_sex	Cross-source recorded_sex for Dermatology Experiment 3	6	13	{"experiment": "dermatology_exp3", "catalog_version": "derm-semantic-v1.0.0"}	2026-07-13 22:18:42.312857	2026-07-13 22:18:42.312857	\N	\N	t
10	image_type_harmonized	Cross-source image_type_harmonized for Dermatology Experiment 3	6	14	{"experiment": "dermatology_exp3", "catalog_version": "derm-semantic-v1.0.0"}	2026-07-13 22:18:42.508011	2026-07-13 22:18:42.508011	\N	\N	t
11	fitzpatrick_skin_type_harmonized	Cross-source fitzpatrick_skin_type_harmonized for Dermatology Experiment 3	6	15	{"experiment": "dermatology_exp3", "catalog_version": "derm-semantic-v1.0.0"}	2026-07-13 22:18:42.846331	2026-07-13 22:18:42.846331	\N	\N	t
12	anatom_site_harmonized	Cross-source anatom_site_harmonized for Dermatology Experiment 3	6	16	{"experiment": "dermatology_exp3", "catalog_version": "derm-semantic-v1.0.0"}	2026-07-13 22:18:43.186597	2026-07-13 22:18:43.186597	\N	\N	t
13	diagnosis_harmonized	Cross-source diagnosis_harmonized for Dermatology Experiment 3	6	12	{"experiment": "dermatology_exp3", "catalog_version": "derm-semantic-v1.1.0"}	2026-07-14 03:20:35.258561	2026-07-14 03:20:35.258561	\N	\N	t
14	recorded_sex	Cross-source recorded_sex for Dermatology Experiment 3	6	13	{"experiment": "dermatology_exp3", "catalog_version": "derm-semantic-v1.1.0"}	2026-07-14 03:20:35.91278	2026-07-14 03:20:35.91278	\N	\N	t
15	image_type_harmonized	Cross-source image_type_harmonized for Dermatology Experiment 3	6	14	{"experiment": "dermatology_exp3", "catalog_version": "derm-semantic-v1.1.0"}	2026-07-14 03:20:36.152884	2026-07-14 03:20:36.152884	\N	\N	t
16	fitzpatrick_skin_type_harmonized	Cross-source fitzpatrick_skin_type_harmonized for Dermatology Experiment 3	6	15	{"experiment": "dermatology_exp3", "catalog_version": "derm-semantic-v1.1.0"}	2026-07-14 03:20:36.453567	2026-07-14 03:20:36.453567	\N	\N	t
17	anatom_site_harmonized	Cross-source anatom_site_harmonized for Dermatology Experiment 3	6	16	{"experiment": "dermatology_exp3", "catalog_version": "derm-semantic-v1.1.0"}	2026-07-14 03:20:36.722375	2026-07-14 03:20:36.722375	\N	\N	t
\.


--
-- Data for Name: column_mappings; Type: TABLE DATA; Schema: equivalence; Owner: -
--

COPY equivalence.column_mappings (id, group_id, column_id, transformation_rule, confidence_score, notes, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	1	195	\N	1.0000	IDA MySQL — triagem.ficha_dermato.cpf_titular — primary patient identifier, federation join key	2026-05-24 01:10:50.165755	2026-05-24 01:10:50.165755	\N	\N	t
2	1	36	\N	1.0000	CMPD PostgreSQL — cadastro_beneficiario.perfil_saude.numero_cpf — primary beneficiary identifier, federation join key	2026-05-24 01:10:50.165755	2026-05-24 01:10:50.165755	\N	\N	t
3	2	197	\N	1.0000	IDA — ficha_dermato.data_nascimento (DATE)	2026-05-24 01:10:50.193104	2026-05-24 01:10:50.193104	\N	\N	t
4	2	39	\N	1.0000	CMPD — perfil_saude.nascimento (DATE)	2026-05-24 01:10:50.193104	2026-05-24 01:10:50.193104	\N	\N	t
5	3	198	\N	1.0000	IDA — ficha_dermato.sexo_biologico CHAR(1): M or F — already in standard format	2026-05-24 01:10:50.224954	2026-05-24 01:10:50.224954	\N	\N	t
6	3	40	LOWER(TRIM(value)) mapped via value_mappings to standard M/F/I	0.9000	CMPD — perfil_saude.genero_identidade VARCHAR(30): masculino/feminino — requires value mapping to M/F/I standard	2026-05-24 01:10:50.224954	2026-05-24 01:10:50.224954	\N	\N	t
7	4	48	\N	1.0000	CMPD — perfil_saude.fumante_status — 3 values: nunca/ex/atual — matches standard exactly	2026-05-24 01:10:50.252984	2026-05-24 01:10:50.252984	\N	\N	t
8	5	172	\N	1.0000	IDA — protocolo_tratamento.modalidade_terapia — 4 values: cirurgia_ampliada, imunoterapia, terapia_alvo, combinado	2026-05-24 01:10:50.279877	2026-05-24 01:10:50.279877	\N	\N	t
9	6	60	\N	1.0000	IDA — laudo_histopatologico.codigo_cid10 — ICD-10 revision, CHAR(4), values like C43x (melanoma)	2026-05-24 01:10:50.307586	2026-05-24 01:10:50.307586	\N	\N	t
10	6	3	ICD-10 to ICD-11 code mapping required for full equivalence	0.8000	CMPD — antecedentes_clinicos.grupo_cid11 — ICD-11 revision, VARCHAR(10) — conceptually equivalent but different revision; cross-map requires lookup table	2026-05-24 01:10:50.307586	2026-05-24 01:10:50.307586	\N	\N	t
11	7	50	\N	1.0000	CMPD — perfil_saude.imc_atual DECIMAL(5,2) — pre-computed BMI. Can be cross-validated against peso_kg and altura_cm in indicadores_vitais	2026-05-24 01:10:50.32972	2026-05-24 01:10:50.32972	\N	\N	t
12	1	317	\N	1.0000	REH cpf_paciente	2026-06-03 03:21:02.820306	2026-06-03 03:21:02.820306	\N	\N	t
13	1	495	\N	1.0000	CDI cpf_pessoa	2026-06-03 03:21:02.820306	2026-06-03 03:21:02.820306	\N	\N	t
14	1	341	\N	1.0000	RFA cpf_cliente	2026-06-03 03:21:02.820306	2026-06-03 03:21:02.820306	\N	\N	t
15	3	320	\N	1.0000	REH sexo_biologico	2026-06-03 03:21:02.857933	2026-06-03 03:21:02.857933	\N	\N	t
16	3	498	\N	1.0000	CDI sexo_biologico	2026-06-03 03:21:02.857933	2026-06-03 03:21:02.857933	\N	\N	t
17	3	344	\N	1.0000	RFA sexo_biologico	2026-06-03 03:21:02.857933	2026-06-03 03:21:02.857933	\N	\N	t
18	2	319	\N	1.0000	REH data_nascimento	2026-06-03 03:21:02.87951	2026-06-03 03:21:02.87951	\N	\N	t
19	2	497	\N	1.0000	CDI data_nascimento	2026-06-03 03:21:02.87951	2026-06-03 03:21:02.87951	\N	\N	t
20	2	343	\N	1.0000	RFA data_nascimento	2026-06-03 03:21:02.87951	2026-06-03 03:21:02.87951	\N	\N	t
21	8	558	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:18:41.640255	2026-07-13 22:18:41.640255	\N	\N	t
22	8	613	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:18:41.666138	2026-07-13 22:18:41.666138	\N	\N	t
23	8	672	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:18:41.673046	2026-07-13 22:18:41.673046	\N	\N	t
24	9	564	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:18:42.33096	2026-07-13 22:18:42.33096	\N	\N	t
25	9	621	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:18:42.340699	2026-07-13 22:18:42.340699	\N	\N	t
26	9	678	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:18:42.350855	2026-07-13 22:18:42.350855	\N	\N	t
27	10	561	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:18:42.537168	2026-07-13 22:18:42.537168	\N	\N	t
28	10	617	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:18:42.558715	2026-07-13 22:18:42.558715	\N	\N	t
29	10	675	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:18:42.574393	2026-07-13 22:18:42.574393	\N	\N	t
30	11	616	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:18:42.867837	2026-07-13 22:18:42.867837	\N	\N	t
31	11	674	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:18:42.885201	2026-07-13 22:18:42.885201	\N	\N	t
32	12	551	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:18:43.209752	2026-07-13 22:18:43.209752	\N	\N	t
33	12	606	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:18:43.22631	2026-07-13 22:18:43.22631	\N	\N	t
34	12	663	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:18:43.245122	2026-07-13 22:18:43.245122	\N	\N	t
35	8	727	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:21:55.796656	2026-07-13 22:21:55.796656	\N	\N	t
36	8	782	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:21:55.810167	2026-07-13 22:21:55.810167	\N	\N	t
37	8	841	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:21:55.822576	2026-07-13 22:21:55.822576	\N	\N	t
38	9	733	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:21:56.316416	2026-07-13 22:21:56.316416	\N	\N	t
39	9	790	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:21:56.327456	2026-07-13 22:21:56.327456	\N	\N	t
40	9	847	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:21:56.336539	2026-07-13 22:21:56.336539	\N	\N	t
41	10	730	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:21:56.466668	2026-07-13 22:21:56.466668	\N	\N	t
42	10	786	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:21:56.481823	2026-07-13 22:21:56.481823	\N	\N	t
43	10	844	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:21:56.495919	2026-07-13 22:21:56.495919	\N	\N	t
44	11	785	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:21:56.71023	2026-07-13 22:21:56.71023	\N	\N	t
45	11	843	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:21:56.726929	2026-07-13 22:21:56.726929	\N	\N	t
46	12	720	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:21:56.972561	2026-07-13 22:21:56.972561	\N	\N	t
47	12	775	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:21:56.984937	2026-07-13 22:21:56.984937	\N	\N	t
48	12	832	\N	1.0000	Predefined Experiment 3 mapping	2026-07-13 22:21:57.001091	2026-07-13 22:21:57.001091	\N	\N	t
49	13	727	\N	1.0000	Predefined Experiment 3 mapping	2026-07-14 03:20:35.291057	2026-07-14 03:20:35.291057	\N	\N	t
50	13	782	\N	1.0000	Predefined Experiment 3 mapping	2026-07-14 03:20:35.316015	2026-07-14 03:20:35.316015	\N	\N	t
51	13	841	\N	1.0000	Predefined Experiment 3 mapping	2026-07-14 03:20:35.337551	2026-07-14 03:20:35.337551	\N	\N	t
52	14	733	\N	1.0000	Predefined Experiment 3 mapping	2026-07-14 03:20:35.94139	2026-07-14 03:20:35.94139	\N	\N	t
53	14	790	\N	1.0000	Predefined Experiment 3 mapping	2026-07-14 03:20:35.962404	2026-07-14 03:20:35.962404	\N	\N	t
54	14	847	\N	1.0000	Predefined Experiment 3 mapping	2026-07-14 03:20:35.981473	2026-07-14 03:20:35.981473	\N	\N	t
55	15	730	\N	1.0000	Predefined Experiment 3 mapping	2026-07-14 03:20:36.181875	2026-07-14 03:20:36.181875	\N	\N	t
56	15	786	\N	1.0000	Predefined Experiment 3 mapping	2026-07-14 03:20:36.196521	2026-07-14 03:20:36.196521	\N	\N	t
57	15	844	\N	1.0000	Predefined Experiment 3 mapping	2026-07-14 03:20:36.212434	2026-07-14 03:20:36.212434	\N	\N	t
58	16	785	\N	1.0000	Predefined Experiment 3 mapping	2026-07-14 03:20:36.485257	2026-07-14 03:20:36.485257	\N	\N	t
59	16	843	\N	1.0000	Predefined Experiment 3 mapping	2026-07-14 03:20:36.503053	2026-07-14 03:20:36.503053	\N	\N	t
60	17	720	\N	1.0000	Predefined Experiment 3 mapping	2026-07-14 03:20:36.756474	2026-07-14 03:20:36.756474	\N	\N	t
61	17	775	\N	1.0000	Predefined Experiment 3 mapping	2026-07-14 03:20:36.785587	2026-07-14 03:20:36.785587	\N	\N	t
62	17	832	\N	1.0000	Predefined Experiment 3 mapping	2026-07-14 03:20:36.802037	2026-07-14 03:20:36.802037	\N	\N	t
\.


--
-- Data for Name: data_dictionary; Type: TABLE DATA; Schema: equivalence; Owner: -
--

COPY equivalence.data_dictionary (id, name, display_name, description, semantic_domain_id, data_type, standard_values, validation_rules, example_values, synonyms, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	patient_cpf	Patient CPF	Brazilian individual taxpayer identification number (CPF). 11-digit string without punctuation. Serves as the cross-database federation key between hospital systems.	1	STRING	\N	{"pattern": "^[0-9]{11}$", "length": 11}	{}	{cpf,cpf_titular,numero_cpf,tax_id,patient_id}	2026-05-24 01:10:06.673344	2026-05-24 01:10:06.673344	\N	\N	t
2	biological_sex	Biological Sex	Biological sex assigned at birth. Standard values: M (male), F (female), I (indeterminate/intersex).	1	ENUM	{M,F,I}	{}	{}	{sexo_biologico,sex,gender_birth,sexo}	2026-05-24 01:10:06.718452	2026-05-24 01:10:06.718452	\N	\N	t
3	birth_date	Date of Birth	Patient date of birth. ISO-8601 date (YYYY-MM-DD).	1	DATE	\N	{}	{}	{data_nascimento,nascimento,dob,date_of_birth}	2026-05-24 01:10:06.760314	2026-05-24 01:10:06.760314	\N	\N	t
4	gender_identity	Gender Identity	Self-reported gender identity. Standard values: masculino, feminino, nao_binario, outro, nao_informado.	1	ENUM	{masculino,feminino,nao_binario,outro,nao_informado}	{}	{}	{genero_identidade,gender,genero}	2026-05-24 01:10:06.793916	2026-05-24 01:10:06.793916	\N	\N	t
5	icd10_code	ICD-10 Code	International Classification of Diseases, 10th revision diagnosis code (e.g. C43.9 for malignant melanoma). 3–4 character alphanumeric code.	2	STRING	\N	{"pattern": "^[A-Z][0-9]{2}(\\\\.?[0-9A-Z])?$"}	{}	{codigo_cid10,cid10,diagnosis_code,icd10}	2026-05-24 01:10:06.829564	2026-05-24 01:10:06.829564	\N	\N	t
6	tnm_staging	TNM Staging	Tumor-Node-Metastasis oncological staging system. Standard values from melanoma dataset: T1aN0M0 through T4bN1M0.	2	STRING	{T1aN0M0,T2aN0M0,T2bN0M0,T3aN0M0,T3bN1M0,T4bN1M0}	{"pattern": "^T[0-9][a-z]?N[0-9]M[0-9]$"}	{}	{estadiamento_tnm,staging,tnm}	2026-05-24 01:10:06.865921	2026-05-24 01:10:06.865921	\N	\N	t
7	condition_severity	Clinical Condition Severity	Severity classification of a clinical condition or diagnosis. Standard values: leve (mild), moderada (moderate), grave (severe).	2	ENUM	{leve,moderada,grave}	{}	{}	{gravidade,severity,condition_level}	2026-05-24 01:10:06.903405	2026-05-24 01:10:06.903405	\N	\N	t
8	body_mass_index	Body Mass Index (BMI)	BMI calculated as weight(kg) / height(m)^2. Stored as DECIMAL(5,2). Normal range: 18.5–24.9.	3	DECIMAL	\N	{"min": 10.0, "max": 70.0}	{}	{imc,imc_atual,bmi}	2026-05-24 01:10:06.936844	2026-05-24 01:10:06.936844	\N	\N	t
9	treatment_modality	Treatment Modality	Primary therapeutic approach. Standard values: cirurgia_ampliada, imunoterapia, terapia_alvo, combinado.	4	ENUM	{cirurgia_ampliada,imunoterapia,terapia_alvo,combinado,radioterapia,quimioterapia}	{}	{}	{modalidade_terapia,treatment_type,therapy_type}	2026-05-24 01:10:06.979432	2026-05-24 01:10:06.979432	\N	\N	t
10	treatment_protocol_status	Treatment Protocol Status	Current status of a therapeutic protocol. Standard values: ativo, concluido, suspenso, cancelado.	4	ENUM	{ativo,concluido,suspenso,cancelado}	{}	{}	{status_protocolo,protocol_status,treatment_status}	2026-05-24 01:10:07.02282	2026-05-24 01:10:07.02282	\N	\N	t
11	smoking_status	Smoking Status	Patient smoking status. Standard values: nunca (never smoker), ex (former smoker), atual (current smoker).	5	ENUM	{nunca,ex,atual}	{}	{}	{fumante_status,smoker,tabagismo,smoking}	2026-05-24 01:10:07.065079	2026-05-24 01:10:07.065079	\N	\N	t
13	dermexp3_recorded_sex	Recorded sex	Dermatology Experiment 3 canonical field: Recorded sex	6	ENUM	{FEMALE,MALE,UNRESOLVED}	{"experiment": "dermatology_exp3"}	{"values": ["FEMALE", "MALE", "UNRESOLVED"]}	{sex,sexo}	2026-07-13 22:18:42.276263	2026-07-13 22:18:42.276263	\N	\N	t
14	dermexp3_image_type	Image modality	Dermatology Experiment 3 canonical field: Image modality	6	ENUM	{DERMOSCOPIC,CLINICAL_OVERVIEW,CLINICAL_CLOSE_UP}	{"experiment": "dermatology_exp3"}	{"values": ["DERMOSCOPIC", "CLINICAL_OVERVIEW", "CLINICAL_CLOSE_UP"]}	{image_type,modality}	2026-07-13 22:18:42.473643	2026-07-13 22:18:42.473643	\N	\N	t
15	dermexp3_fitzpatrick	Recorded Fitzpatrick phototype	Dermatology Experiment 3 canonical field: Recorded Fitzpatrick phototype	6	ENUM	{I,II,III,IV,V,VI}	{"experiment": "dermatology_exp3"}	{"values": ["I", "II", "III"]}	{fitzpatrick_skin_type,phototype}	2026-07-13 22:18:42.815317	2026-07-13 22:18:42.815317	\N	\N	t
16	dermexp3_anatom_site	Broad anatomical site	Dermatology Experiment 3 canonical field: Broad anatomical site	6	ENUM	{"Anogenital region","Head and neck","Lower extremity",Trunk,"Upper extremity"}	{"experiment": "dermatology_exp3"}	{"values": ["Anogenital region", "Head and neck", "Lower extremity"]}	{anatom_site_1,localization,"anatomical site"}	2026-07-13 22:18:43.156022	2026-07-13 22:18:43.156022	\N	\N	t
12	dermexp3_diagnosis	Harmonized diagnosis	Dermatology Experiment 3 canonical field: Harmonized diagnosis	6	ENUM	{MEL,NV,BCC,SCC,AK,BKL,DF,UNRESOLVED}	{"experiment": "dermatology_exp3"}	{"values": ["MEL", "NV", "BCC"]}	{diagnosis_3,diagnostic,dx}	2026-07-13 22:18:41.577495	2026-07-14 03:20:35.222579	\N	\N	t
\.


--
-- Data for Name: semantic_domains; Type: TABLE DATA; Schema: equivalence; Owner: -
--

COPY equivalence.semantic_domains (id, name, description, parent_domain_id, color, domain_rules, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	Patient Identity	Core patient identification: CPF, full name, birth date, sex and gender identity.	\N	#6366f1	{}	2026-05-24 01:09:41.612595	2026-05-24 01:09:41.612595	\N	\N	t
2	Clinical Diagnosis	Diagnostic codes and clinical classifications: ICD-10, WHO classification, TNM staging, Breslow thickness.	\N	#ef4444	{}	2026-05-24 01:09:41.642039	2026-05-24 01:09:41.642039	\N	\N	t
3	Vitals & Labs	Physiological measurements and laboratory results: BMI, blood pressure, glycemia, lipid panel, O2 saturation.	\N	#10b981	{}	2026-05-24 01:09:41.665383	2026-05-24 01:09:41.665383	\N	\N	t
4	Treatment & Oncology	Therapeutic protocols and oncology treatment data: modality, medication, cycles, protocol status, clinical evolution.	\N	#f59e0b	{}	2026-05-24 01:09:41.694501	2026-05-24 01:09:41.694501	\N	\N	t
5	Risk & Prevention	Lifestyle and risk factors: smoking status, physical activity, solar exposure history, family history, Fitzpatrick skin type.	\N	#8b5cf6	{}	2026-05-24 01:09:41.723132	2026-05-24 01:09:41.723132	\N	\N	t
6	dermexp3_dermatology	Versioned dermatology concepts for Experiment 3	\N	#4477AA	{"experiment": "dermatology_exp3", "version": "1.0.0"}	2026-07-13 22:18:41.526423	2026-07-13 22:18:41.526423	\N	\N	t
\.


--
-- Data for Name: value_mappings; Type: TABLE DATA; Schema: equivalence; Owner: -
--

COPY equivalence.value_mappings (id, group_id, source_column_id, source_value, standard_value, description, record_count, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	3	40	masculino	M	CMPD full-text male → standard M	0	2026-05-24 01:11:04.103755	2026-05-24 01:11:04.103755	\N	\N	t
2	3	40	feminino	F	CMPD full-text female → standard F	0	2026-05-24 01:11:04.103755	2026-05-24 01:11:04.103755	\N	\N	t
6	5	172	cirurgia_ampliada	cirurgia_ampliada	Wide local excision — standard surgical approach for melanoma	0	2026-05-24 01:11:04.202033	2026-05-24 01:11:04.202033	\N	\N	t
7	5	172	imunoterapia	imunoterapia	Immunotherapy — Pembrolizumab / anti-PD-1	0	2026-05-24 01:11:04.202033	2026-05-24 01:11:04.202033	\N	\N	t
8	5	172	terapia_alvo	terapia_alvo	Targeted therapy — Vemurafenib / BRAF inhibitor	0	2026-05-24 01:11:04.202033	2026-05-24 01:11:04.202033	\N	\N	t
9	5	172	combinado	combinado	Combined modalities (surgery + systemic therapy)	0	2026-05-24 01:11:04.202033	2026-05-24 01:11:04.202033	\N	\N	t
10	8	558	Melanoma, NOS	MEL	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.692126	2026-07-13 22:18:41.692126	\N	\N	t
11	8	558	Nevus	NV	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.708686	2026-07-13 22:18:41.708686	\N	\N	t
12	8	558	Basal cell carcinoma	BCC	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.724526	2026-07-13 22:18:41.724526	\N	\N	t
13	8	558	Squamous cell carcinoma, NOS	SCC	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.738419	2026-07-13 22:18:41.738419	\N	\N	t
14	8	558	Solar or actinic keratosis	AK	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.757922	2026-07-13 22:18:41.757922	\N	\N	t
15	8	558	Dermatofibroma	DF	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.768236	2026-07-13 22:18:41.768236	\N	\N	t
16	8	558	Pigmented benign keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.775571	2026-07-13 22:18:41.775571	\N	\N	t
17	8	558	Seborrheic keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.782867	2026-07-13 22:18:41.782867	\N	\N	t
18	8	558	Solar lentigo	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.79249	2026-07-13 22:18:41.79249	\N	\N	t
19	8	558	Lichen planus like keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.803794	2026-07-13 22:18:41.803794	\N	\N	t
20	8	613	Melanoma, NOS	MEL	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.81964	2026-07-13 22:18:41.81964	\N	\N	t
21	8	613	Nevus	NV	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.838345	2026-07-13 22:18:41.838345	\N	\N	t
22	8	613	Basal cell carcinoma	BCC	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.85735	2026-07-13 22:18:41.85735	\N	\N	t
23	8	613	Squamous cell carcinoma, NOS	SCC	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.873309	2026-07-13 22:18:41.873309	\N	\N	t
24	8	613	Solar or actinic keratosis	AK	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.890394	2026-07-13 22:18:41.890394	\N	\N	t
25	8	613	Dermatofibroma	DF	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.907452	2026-07-13 22:18:41.907452	\N	\N	t
26	8	613	Pigmented benign keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.922687	2026-07-13 22:18:41.922687	\N	\N	t
27	8	613	Seborrheic keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.938922	2026-07-13 22:18:41.938922	\N	\N	t
28	8	613	Solar lentigo	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.95525	2026-07-13 22:18:41.95525	\N	\N	t
29	8	613	Lichen planus like keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.973755	2026-07-13 22:18:41.973755	\N	\N	t
30	8	672	Melanoma, NOS	MEL	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:41.993886	2026-07-13 22:18:41.993886	\N	\N	t
31	8	672	Nevus	NV	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.010394	2026-07-13 22:18:42.010394	\N	\N	t
32	8	672	Basal cell carcinoma	BCC	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.02856	2026-07-13 22:18:42.02856	\N	\N	t
33	8	672	Squamous cell carcinoma, NOS	SCC	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.046558	2026-07-13 22:18:42.046558	\N	\N	t
34	8	672	Solar or actinic keratosis	AK	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.061528	2026-07-13 22:18:42.061528	\N	\N	t
35	8	672	Dermatofibroma	DF	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.075913	2026-07-13 22:18:42.075913	\N	\N	t
36	8	672	Pigmented benign keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.095209	2026-07-13 22:18:42.095209	\N	\N	t
37	8	672	Seborrheic keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.120079	2026-07-13 22:18:42.120079	\N	\N	t
38	8	672	Solar lentigo	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.141997	2026-07-13 22:18:42.141997	\N	\N	t
39	8	672	Lichen planus like keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.161829	2026-07-13 22:18:42.161829	\N	\N	t
40	9	564	female	FEMALE	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.366644	2026-07-13 22:18:42.366644	\N	\N	t
41	9	564	male	MALE	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.378689	2026-07-13 22:18:42.378689	\N	\N	t
42	9	621	female	FEMALE	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.391707	2026-07-13 22:18:42.391707	\N	\N	t
43	9	621	male	MALE	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.404571	2026-07-13 22:18:42.404571	\N	\N	t
44	9	678	female	FEMALE	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.412937	2026-07-13 22:18:42.412937	\N	\N	t
45	9	678	male	MALE	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.425274	2026-07-13 22:18:42.425274	\N	\N	t
46	10	561	dermoscopic	DERMOSCOPIC	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.604195	2026-07-13 22:18:42.604195	\N	\N	t
47	10	561	clinical: overview	CLINICAL_OVERVIEW	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.621428	2026-07-13 22:18:42.621428	\N	\N	t
48	10	561	clinical: close-up	CLINICAL_CLOSE_UP	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.641406	2026-07-13 22:18:42.641406	\N	\N	t
49	10	617	dermoscopic	DERMOSCOPIC	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.662776	2026-07-13 22:18:42.662776	\N	\N	t
50	10	617	clinical: overview	CLINICAL_OVERVIEW	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.687051	2026-07-13 22:18:42.687051	\N	\N	t
51	10	617	clinical: close-up	CLINICAL_CLOSE_UP	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.709404	2026-07-13 22:18:42.709404	\N	\N	t
52	10	675	dermoscopic	DERMOSCOPIC	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.727293	2026-07-13 22:18:42.727293	\N	\N	t
53	10	675	clinical: overview	CLINICAL_OVERVIEW	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.745585	2026-07-13 22:18:42.745585	\N	\N	t
54	10	675	clinical: close-up	CLINICAL_CLOSE_UP	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.763302	2026-07-13 22:18:42.763302	\N	\N	t
55	11	616	I	I	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.9141	2026-07-13 22:18:42.9141	\N	\N	t
56	11	616	II	II	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.936822	2026-07-13 22:18:42.936822	\N	\N	t
57	11	616	III	III	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.959334	2026-07-13 22:18:42.959334	\N	\N	t
58	11	616	IV	IV	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.976636	2026-07-13 22:18:42.976636	\N	\N	t
59	11	616	V	V	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:42.997306	2026-07-13 22:18:42.997306	\N	\N	t
60	11	616	VI	VI	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:43.020339	2026-07-13 22:18:43.020339	\N	\N	t
61	11	674	I	I	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:43.034278	2026-07-13 22:18:43.034278	\N	\N	t
62	11	674	II	II	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:43.050267	2026-07-13 22:18:43.050267	\N	\N	t
63	11	674	III	III	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:43.068681	2026-07-13 22:18:43.068681	\N	\N	t
64	11	674	IV	IV	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:43.082894	2026-07-13 22:18:43.082894	\N	\N	t
65	11	674	V	V	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:43.094592	2026-07-13 22:18:43.094592	\N	\N	t
66	11	674	VI	VI	Versioned Experiment 3 value mapping	0	2026-07-13 22:18:43.107474	2026-07-13 22:18:43.107474	\N	\N	t
67	8	727	Melanoma, NOS	MEL	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:55.848623	2026-07-13 22:21:55.848623	\N	\N	t
68	8	727	Nevus	NV	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:55.861008	2026-07-13 22:21:55.861008	\N	\N	t
69	8	727	Basal cell carcinoma	BCC	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:55.874705	2026-07-13 22:21:55.874705	\N	\N	t
70	8	727	Squamous cell carcinoma, NOS	SCC	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:55.894687	2026-07-13 22:21:55.894687	\N	\N	t
71	8	727	Solar or actinic keratosis	AK	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:55.909842	2026-07-13 22:21:55.909842	\N	\N	t
72	8	727	Dermatofibroma	DF	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:55.921864	2026-07-13 22:21:55.921864	\N	\N	t
73	8	727	Pigmented benign keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:55.931277	2026-07-13 22:21:55.931277	\N	\N	t
74	8	727	Seborrheic keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:55.943095	2026-07-13 22:21:55.943095	\N	\N	t
75	8	727	Solar lentigo	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:55.961962	2026-07-13 22:21:55.961962	\N	\N	t
76	8	727	Lichen planus like keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:55.98135	2026-07-13 22:21:55.98135	\N	\N	t
77	8	782	Melanoma, NOS	MEL	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.000219	2026-07-13 22:21:56.000219	\N	\N	t
78	8	782	Nevus	NV	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.020835	2026-07-13 22:21:56.020835	\N	\N	t
79	8	782	Basal cell carcinoma	BCC	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.03515	2026-07-13 22:21:56.03515	\N	\N	t
80	8	782	Squamous cell carcinoma, NOS	SCC	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.049915	2026-07-13 22:21:56.049915	\N	\N	t
81	8	782	Solar or actinic keratosis	AK	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.065216	2026-07-13 22:21:56.065216	\N	\N	t
82	8	782	Dermatofibroma	DF	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.080922	2026-07-13 22:21:56.080922	\N	\N	t
83	8	782	Pigmented benign keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.096051	2026-07-13 22:21:56.096051	\N	\N	t
84	8	782	Seborrheic keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.108843	2026-07-13 22:21:56.108843	\N	\N	t
85	8	782	Solar lentigo	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.124108	2026-07-13 22:21:56.124108	\N	\N	t
86	8	782	Lichen planus like keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.138595	2026-07-13 22:21:56.138595	\N	\N	t
87	8	841	Melanoma, NOS	MEL	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.15626	2026-07-13 22:21:56.15626	\N	\N	t
88	8	841	Nevus	NV	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.177087	2026-07-13 22:21:56.177087	\N	\N	t
89	8	841	Basal cell carcinoma	BCC	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.193224	2026-07-13 22:21:56.193224	\N	\N	t
90	8	841	Squamous cell carcinoma, NOS	SCC	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.206629	2026-07-13 22:21:56.206629	\N	\N	t
91	8	841	Solar or actinic keratosis	AK	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.220092	2026-07-13 22:21:56.220092	\N	\N	t
92	8	841	Dermatofibroma	DF	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.232576	2026-07-13 22:21:56.232576	\N	\N	t
93	8	841	Pigmented benign keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.241286	2026-07-13 22:21:56.241286	\N	\N	t
94	8	841	Seborrheic keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.251826	2026-07-13 22:21:56.251826	\N	\N	t
95	8	841	Solar lentigo	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.262307	2026-07-13 22:21:56.262307	\N	\N	t
96	8	841	Lichen planus like keratosis	UNRESOLVED	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.270747	2026-07-13 22:21:56.270747	\N	\N	t
97	9	733	female	FEMALE	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.352763	2026-07-13 22:21:56.352763	\N	\N	t
98	9	733	male	MALE	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.366949	2026-07-13 22:21:56.366949	\N	\N	t
99	9	790	female	FEMALE	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.378474	2026-07-13 22:21:56.378474	\N	\N	t
100	9	790	male	MALE	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.38896	2026-07-13 22:21:56.38896	\N	\N	t
101	9	847	female	FEMALE	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.398067	2026-07-13 22:21:56.398067	\N	\N	t
102	9	847	male	MALE	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.405717	2026-07-13 22:21:56.405717	\N	\N	t
103	10	730	dermoscopic	DERMOSCOPIC	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.517575	2026-07-13 22:21:56.517575	\N	\N	t
104	10	730	clinical: overview	CLINICAL_OVERVIEW	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.530271	2026-07-13 22:21:56.530271	\N	\N	t
105	10	730	clinical: close-up	CLINICAL_CLOSE_UP	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.540384	2026-07-13 22:21:56.540384	\N	\N	t
106	10	786	dermoscopic	DERMOSCOPIC	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.556498	2026-07-13 22:21:56.556498	\N	\N	t
107	10	786	clinical: overview	CLINICAL_OVERVIEW	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.57194	2026-07-13 22:21:56.57194	\N	\N	t
108	10	786	clinical: close-up	CLINICAL_CLOSE_UP	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.592064	2026-07-13 22:21:56.592064	\N	\N	t
109	10	844	dermoscopic	DERMOSCOPIC	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.611604	2026-07-13 22:21:56.611604	\N	\N	t
110	10	844	clinical: overview	CLINICAL_OVERVIEW	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.626206	2026-07-13 22:21:56.626206	\N	\N	t
111	10	844	clinical: close-up	CLINICAL_CLOSE_UP	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.641887	2026-07-13 22:21:56.641887	\N	\N	t
112	11	785	I	I	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.751606	2026-07-13 22:21:56.751606	\N	\N	t
113	11	785	II	II	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.76885	2026-07-13 22:21:56.76885	\N	\N	t
114	11	785	III	III	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.782987	2026-07-13 22:21:56.782987	\N	\N	t
115	11	785	IV	IV	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.796018	2026-07-13 22:21:56.796018	\N	\N	t
116	11	785	V	V	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.80857	2026-07-13 22:21:56.80857	\N	\N	t
117	11	785	VI	VI	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.818793	2026-07-13 22:21:56.818793	\N	\N	t
118	11	843	I	I	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.829958	2026-07-13 22:21:56.829958	\N	\N	t
119	11	843	II	II	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.839922	2026-07-13 22:21:56.839922	\N	\N	t
120	11	843	III	III	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.850495	2026-07-13 22:21:56.850495	\N	\N	t
121	11	843	IV	IV	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.865205	2026-07-13 22:21:56.865205	\N	\N	t
122	11	843	V	V	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.881181	2026-07-13 22:21:56.881181	\N	\N	t
123	11	843	VI	VI	Versioned Experiment 3 value mapping	0	2026-07-13 22:21:56.899587	2026-07-13 22:21:56.899587	\N	\N	t
124	13	727	Melanoma, NOS	MEL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.370708	2026-07-14 03:20:35.370708	\N	\N	t
125	13	727	Nevus	NV	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.391191	2026-07-14 03:20:35.391191	\N	\N	t
126	13	727	Basal cell carcinoma	BCC	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.409462	2026-07-14 03:20:35.409462	\N	\N	t
127	13	727	Squamous cell carcinoma, NOS	SCC	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.429163	2026-07-14 03:20:35.429163	\N	\N	t
128	13	727	Solar or actinic keratosis	AK	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.446855	2026-07-14 03:20:35.446855	\N	\N	t
129	13	727	Dermatofibroma	DF	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.466437	2026-07-14 03:20:35.466437	\N	\N	t
130	13	727	Pigmented benign keratosis	BKL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.48526	2026-07-14 03:20:35.48526	\N	\N	t
131	13	727	Seborrheic keratosis	BKL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.503132	2026-07-14 03:20:35.503132	\N	\N	t
132	13	727	Solar lentigo	BKL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.520809	2026-07-14 03:20:35.520809	\N	\N	t
133	13	727	Lichen planus like keratosis	BKL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.53998	2026-07-14 03:20:35.53998	\N	\N	t
134	13	782	Melanoma, NOS	MEL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.560229	2026-07-14 03:20:35.560229	\N	\N	t
135	13	782	Nevus	NV	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.583277	2026-07-14 03:20:35.583277	\N	\N	t
136	13	782	Basal cell carcinoma	BCC	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.607067	2026-07-14 03:20:35.607067	\N	\N	t
137	13	782	Squamous cell carcinoma, NOS	SCC	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.625983	2026-07-14 03:20:35.625983	\N	\N	t
138	13	782	Solar or actinic keratosis	AK	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.641167	2026-07-14 03:20:35.641167	\N	\N	t
139	13	782	Dermatofibroma	DF	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.65662	2026-07-14 03:20:35.65662	\N	\N	t
140	13	782	Pigmented benign keratosis	BKL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.671658	2026-07-14 03:20:35.671658	\N	\N	t
141	13	782	Seborrheic keratosis	BKL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.688181	2026-07-14 03:20:35.688181	\N	\N	t
142	13	782	Solar lentigo	BKL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.702525	2026-07-14 03:20:35.702525	\N	\N	t
143	13	782	Lichen planus like keratosis	BKL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.71201	2026-07-14 03:20:35.71201	\N	\N	t
144	13	841	Melanoma, NOS	MEL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.719391	2026-07-14 03:20:35.719391	\N	\N	t
145	13	841	Nevus	NV	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.72623	2026-07-14 03:20:35.72623	\N	\N	t
146	13	841	Basal cell carcinoma	BCC	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.734177	2026-07-14 03:20:35.734177	\N	\N	t
147	13	841	Squamous cell carcinoma, NOS	SCC	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.744026	2026-07-14 03:20:35.744026	\N	\N	t
148	13	841	Solar or actinic keratosis	AK	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.757032	2026-07-14 03:20:35.757032	\N	\N	t
149	13	841	Dermatofibroma	DF	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.770994	2026-07-14 03:20:35.770994	\N	\N	t
150	13	841	Pigmented benign keratosis	BKL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.786655	2026-07-14 03:20:35.786655	\N	\N	t
151	13	841	Seborrheic keratosis	BKL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.803416	2026-07-14 03:20:35.803416	\N	\N	t
152	13	841	Solar lentigo	BKL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.822434	2026-07-14 03:20:35.822434	\N	\N	t
153	13	841	Lichen planus like keratosis	BKL	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:35.841155	2026-07-14 03:20:35.841155	\N	\N	t
154	14	733	female	FEMALE	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.007698	2026-07-14 03:20:36.007698	\N	\N	t
155	14	733	male	MALE	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.021405	2026-07-14 03:20:36.021405	\N	\N	t
156	14	790	female	FEMALE	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.040501	2026-07-14 03:20:36.040501	\N	\N	t
157	14	790	male	MALE	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.055332	2026-07-14 03:20:36.055332	\N	\N	t
158	14	847	female	FEMALE	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.068707	2026-07-14 03:20:36.068707	\N	\N	t
159	14	847	male	MALE	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.084316	2026-07-14 03:20:36.084316	\N	\N	t
160	15	730	dermoscopic	DERMOSCOPIC	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.236814	2026-07-14 03:20:36.236814	\N	\N	t
161	15	730	clinical: overview	CLINICAL_OVERVIEW	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.255451	2026-07-14 03:20:36.255451	\N	\N	t
162	15	730	clinical: close-up	CLINICAL_CLOSE_UP	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.271417	2026-07-14 03:20:36.271417	\N	\N	t
163	15	786	dermoscopic	DERMOSCOPIC	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.291504	2026-07-14 03:20:36.291504	\N	\N	t
164	15	786	clinical: overview	CLINICAL_OVERVIEW	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.310346	2026-07-14 03:20:36.310346	\N	\N	t
165	15	786	clinical: close-up	CLINICAL_CLOSE_UP	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.325629	2026-07-14 03:20:36.325629	\N	\N	t
166	15	844	dermoscopic	DERMOSCOPIC	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.342464	2026-07-14 03:20:36.342464	\N	\N	t
167	15	844	clinical: overview	CLINICAL_OVERVIEW	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.360184	2026-07-14 03:20:36.360184	\N	\N	t
168	15	844	clinical: close-up	CLINICAL_CLOSE_UP	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.377844	2026-07-14 03:20:36.377844	\N	\N	t
169	16	785	I	I	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.52866	2026-07-14 03:20:36.52866	\N	\N	t
170	16	785	II	II	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.544825	2026-07-14 03:20:36.544825	\N	\N	t
171	16	785	III	III	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.56467	2026-07-14 03:20:36.56467	\N	\N	t
172	16	785	IV	IV	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.578676	2026-07-14 03:20:36.578676	\N	\N	t
173	16	785	V	V	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.590975	2026-07-14 03:20:36.590975	\N	\N	t
174	16	785	VI	VI	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.601808	2026-07-14 03:20:36.601808	\N	\N	t
175	16	843	I	I	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.609161	2026-07-14 03:20:36.609161	\N	\N	t
176	16	843	II	II	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.616806	2026-07-14 03:20:36.616806	\N	\N	t
177	16	843	III	III	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.625297	2026-07-14 03:20:36.625297	\N	\N	t
178	16	843	IV	IV	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.635087	2026-07-14 03:20:36.635087	\N	\N	t
179	16	843	V	V	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.645963	2026-07-14 03:20:36.645963	\N	\N	t
180	16	843	VI	VI	Versioned Experiment 3 value mapping	0	2026-07-14 03:20:36.659395	2026-07-14 03:20:36.659395	\N	\N	t
\.


--
-- Data for Name: column_tags; Type: TABLE DATA; Schema: metadata; Owner: -
--

COPY metadata.column_tags (id, column_id, tag_name, tag_type, confidence, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
\.


--
-- Data for Name: external_catalogs; Type: TABLE DATA; Schema: metadata; Owner: -
--

COPY metadata.external_catalogs (id, connection_id, catalog_name, catalog_type, external_reference, properties, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	3	cmpd___centro_de_medicina_preventiva_e_diagn_stico_3	postgresql	cmpd___centro_de_medicina_preventiva_e_diagn_stico_3	{}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
2	4	ida___instituto_de_dermatologia_avan_ada_4	mysql	ida___instituto_de_dermatologia_avan_ada_4	{}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
3	5	reh___rede_de_emerg_ncias_hospitalares_5	postgresql	reh___rede_de_emerg_ncias_hospitalares_5	{}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
4	7	rfa___rede_de_farm_cias_e_ades_o_7	mysql	rfa___rede_de_farm_cias_e_ades_o_7	{}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
5	6	cdi___centro_de_diagn_stico_por_imagem_6	postgresql	cdi___centro_de_diagn_stico_por_imagem_6	{}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
6	8	dermexp3_ham10000_collection_212_8	postgresql	dermexp3_ham10000_collection_212_8	{}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
7	9	dermexp3_hiba_collection_251_9	postgresql	dermexp3_hiba_collection_251_9	{}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
8	10	dermexp3_pad_ufes_20_collection_406_10	mysql	dermexp3_pad_ufes_20_collection_406_10	{}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
9	11	dermexp3_v2_ham10000_collection_212_11	postgresql	dermexp3_v2_ham10000_collection_212_11	{}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
10	12	dermexp3_v2_hiba_collection_251_12	postgresql	dermexp3_v2_hiba_collection_251_12	{}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
11	13	dermexp3_v2_pad_ufes_20_collection_406_13	mysql	dermexp3_v2_pad_ufes_20_collection_406_13	{}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
\.


--
-- Data for Name: external_columns; Type: TABLE DATA; Schema: metadata; Owner: -
--

COPY metadata.external_columns (id, table_id, column_name, external_reference, data_type, is_nullable, column_position, max_length, numeric_precision, numeric_scale, is_primary_key, is_unique, is_indexed, is_foreign_key, fk_referenced_table_id, fk_referenced_column_id, fk_constraint_name, default_value, description, is_image_path, image_connection_id, statistics, sample_values, properties, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
3	1	grupo_cid11	antecedentes_clinicos.grupo_cid11	varchar(10)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(10)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
4	1	descricao_condicao	antecedentes_clinicos.descricao_condicao	varchar(200)	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(200)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
5	1	ano_diagnostico	antecedentes_clinicos.ano_diagnostico	smallint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
6	1	em_tratamento_ativo	antecedentes_clinicos.em_tratamento_ativo	boolean	f	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "boolean"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
46	5	plano_saude_ans	perfil_saude.plano_saude_ans	varchar(20)	t	12	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
47	5	renda_faixa	perfil_saude.renda_faixa	varchar(2)	t	13	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(2)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
53	6	patologista_crm	laudo_histopatologico.patologista_crm	varchar(12)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(12)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
54	6	classificacao_who	laudo_histopatologico.classificacao_who	varchar(80)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(80)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
55	6	espessura_breslow_mm	laudo_histopatologico.espessura_breslow_mm	decimal(5,3)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(5,3)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
142	24	medico_requisitante	requisicao_exame.medico_requisitante	varchar(12)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(12)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
143	24	painel_exames	requisicao_exame.painel_exames	json	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "json"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
144	24	prioridade	requisicao_exame.prioridade	varchar(10)	f	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(10)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
146	24	data_emissao	requisicao_exame.data_emissao	date	f	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
147	24	instrucoes_preparo	requisicao_exame.instrucoes_preparo	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
159	26	analito	resultado_exame.analito	varchar(80)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(80)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
160	26	valor_numerico	resultado_exame.valor_numerico	decimal(12,4)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(12,4)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
161	26	unidade_medida	resultado_exame.unidade_medida	varchar(20)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
162	26	valor_referencia_min	resultado_exame.valor_referencia_min	decimal(12,4)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(12,4)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
150	25	data_consulta	evolucao_clinica.data_consulta	date	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
151	25	ciclo_atual	evolucao_clinica.ciclo_atual	smallint	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
152	25	resposta_ecog	evolucao_clinica.resposta_ecog	tinyint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "tinyint"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
153	25	dimensao_lesao_mm	evolucao_clinica.dimensao_lesao_mm	decimal(6,2)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(6,2)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
154	25	toxicidade_grau	evolucao_clinica.toxicidade_grau	tinyint	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "tinyint"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
155	25	ajuste_dose	evolucao_clinica.ajuste_dose	tinyint	f	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "tinyint"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
9	2	solicitacao_id	biopsia_solicitacao.solicitacao_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.889639	2026-05-24 00:54:41.110981	\N	\N	t
29	4	marcador_id	imunohistoquimica.marcador_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.889639	2026-05-24 00:54:41.117275	\N	\N	t
30	4	laudo_id	imunohistoquimica.laudo_id	integer	f	2	\N	\N	\N	f	f	f	t	6	51	fk_marcador_laudo	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.889639	2026-05-24 00:54:41.131985	\N	\N	t
51	6	laudo_id	laudo_histopatologico.laudo_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.889639	2026-05-24 00:54:41.137501	\N	\N	t
52	6	solicitacao_id	laudo_histopatologico.solicitacao_id	integer	f	2	\N	\N	\N	f	f	f	t	2	9	fk_laudo_solic	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.889639	2026-05-24 00:54:41.14968	\N	\N	t
246	38	privilege_type	table_privileges.privilege_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
247	38	is_grantable	table_privileges.is_grantable	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
248	38	with_hierarchy	table_privileges.with_hierarchy	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
249	39	table_catalog	tables.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
250	39	table_schema	tables.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
251	39	table_name	tables.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
252	39	table_type	tables.table_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
253	40	table_catalog	views.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
254	40	table_schema	views.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
255	40	table_name	views.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
293	45	sato2	sinal_vital_serie.sato2	decimal(4,1)	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(4,1)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
294	45	glasgow	sinal_vital_serie.glasgow	smallint	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
295	45	dor_eva	sinal_vital_serie.dor_eva	smallint	t	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
298	46	data_entrada	atendimento_emergencia.data_entrada	timestamp(6) with time zone	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
299	46	data_saida	atendimento_emergencia.data_saida	timestamp(6) with time zone	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
337	50	meta_aderencia_pct	programa_adesao.meta_aderencia_pct	decimal(5,2)	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(5,2)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
338	50	descricao	programa_adesao.descricao	varchar(65535)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
339	50	vigente	programa_adesao.vigente	tinyint	f	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "tinyint"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
341	51	cpf_cliente	cliente_farmacia.cpf_cliente	char(11)	f	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(11)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
342	51	nome_completo	cliente_farmacia.nome_completo	varchar(150)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(150)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
343	51	data_nascimento	cliente_farmacia.data_nascimento	date	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
383	55	detectada_em	interacao_medicamentosa.detectada_em	date	f	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
384	56	grantee	applicable_roles.grantee	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
385	56	grantee_type	applicable_roles.grantee_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
386	56	role_name	applicable_roles.role_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
431	65	dose_efetiva_msv	dose_radiacao.dose_efetiva_msv	decimal(8,4)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(8,4)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
432	65	registrado_em	dose_radiacao.registrado_em	timestamp(6) with time zone	f	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
434	66	modalidade	equipamento.modalidade	varchar(10)	f	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(10)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
435	66	fabricante	equipamento.fabricante	varchar(60)	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(60)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
436	66	modelo	equipamento.modelo	varchar(60)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(60)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
478	74	grantee	table_privileges.grantee	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
479	74	grantee_type	table_privileges.grantee_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
480	74	table_catalog	table_privileges.table_catalog	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
7	1	medicacao_continua	antecedentes_clinicos.medicacao_continua	varchar(200)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(200)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
8	1	gravidade	antecedentes_clinicos.gravidade	varchar(10)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(10)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
10	2	lesao_id	biopsia_solicitacao.lesao_id	integer	f	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
11	2	medico_solicitante_crm	biopsia_solicitacao.medico_solicitante_crm	varchar(12)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(12)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
12	2	tecnica_biopsia	biopsia_solicitacao.tecnica_biopsia	varchar(40)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(40)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
13	2	urgencia	biopsia_solicitacao.urgencia	varchar(10)	f	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(10)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
14	2	data_solicitacao	biopsia_solicitacao.data_solicitacao	date	f	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
15	2	observacoes_clinicas	biopsia_solicitacao.observacoes_clinicas	varchar(65535)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
18	3	data_aferimento	indicadores_vitais.data_aferimento	timestamp(6) with time zone	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
19	3	pressao_sistolica	indicadores_vitais.pressao_sistolica	smallint	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
20	3	pressao_diastolica	indicadores_vitais.pressao_diastolica	smallint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
21	3	glicemia_jejum_mg	indicadores_vitais.glicemia_jejum_mg	decimal(6,2)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(6,2)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
22	3	colesterol_total	indicadores_vitais.colesterol_total	decimal(6,2)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(6,2)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
23	3	hdl	indicadores_vitais.hdl	decimal(5,2)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(5,2)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
24	3	ldl	indicadores_vitais.ldl	decimal(5,2)	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(5,2)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
25	3	triglicerideos	indicadores_vitais.triglicerideos	decimal(6,2)	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(6,2)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
26	3	saturacao_o2	indicadores_vitais.saturacao_o2	decimal(4,1)	t	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(4,1)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
27	3	peso_kg	indicadores_vitais.peso_kg	decimal(6,2)	t	12	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(6,2)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
28	3	altura_cm	indicadores_vitais.altura_cm	decimal(5,1)	t	13	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(5,1)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
31	4	anticorpo	imunohistoquimica.anticorpo	varchar(40)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(40)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
32	4	resultado	imunohistoquimica.resultado	varchar(20)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
33	4	intensidade	imunohistoquimica.intensidade	varchar(10)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(10)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
34	4	percentual_celulas	imunohistoquimica.percentual_celulas	decimal(5,2)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(5,2)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
36	5	numero_cpf	perfil_saude.numero_cpf	char(11)	f	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(11)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
37	5	prenome	perfil_saude.prenome	varchar(60)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(60)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
38	5	sobrenome	perfil_saude.sobrenome	varchar(90)	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(90)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
39	5	nascimento	perfil_saude.nascimento	date	f	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
40	5	genero_identidade	perfil_saude.genero_identidade	varchar(30)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(30)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
41	5	telefone_celular	perfil_saude.telefone_celular	varchar(15)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(15)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
42	5	email_contato	perfil_saude.email_contato	varchar(120)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(120)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
43	5	cep_residencia	perfil_saude.cep_residencia	char(8)	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(8)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
44	5	municipio	perfil_saude.municipio	varchar(80)	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(80)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
45	5	uf_sigla	perfil_saude.uf_sigla	char(2)	t	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(2)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
35	5	beneficiario_id	perfil_saude.beneficiario_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.888377	2026-06-11 01:58:53.015486	\N	\N	t
1	1	antecedente_id	antecedentes_clinicos.antecedente_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.888377	2026-06-11 01:58:53.018929	\N	\N	t
2	1	beneficiario_id	antecedentes_clinicos.beneficiario_id	integer	f	2	\N	\N	\N	f	f	f	t	5	35	antecedentes_clinicos_beneficiario_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.888377	2026-06-11 01:58:53.02351	\N	\N	t
48	5	fumante_status	perfil_saude.fumante_status	varchar(15)	t	14	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(15)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
49	5	pratica_atividade_fisica	perfil_saude.pratica_atividade_fisica	boolean	f	15	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "boolean"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
50	5	imc_atual	perfil_saude.imc_atual	decimal(5,2)	t	16	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(5,2)"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
63	7	grantee	applicable_roles.grantee	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
64	7	grantee_type	applicable_roles.grantee_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
65	7	role_name	applicable_roles.role_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
66	7	is_grantable	applicable_roles.is_grantable	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
71	9	table_catalog	columns.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
72	9	table_schema	columns.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
73	9	table_name	columns.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
74	9	column_name	columns.column_name	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
75	9	ordinal_position	columns.ordinal_position	bigint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
76	9	column_default	columns.column_default	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
77	9	is_nullable	columns.is_nullable	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
78	9	data_type	columns.data_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
87	11	role_name	enabled_roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
88	13	role_name	roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
90	14	catalog_name	schemata.catalog_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
91	14	schema_name	schemata.schema_name	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
93	16	grantor	table_privileges.grantor	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
94	16	grantor_type	table_privileges.grantor_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
95	16	grantee	table_privileges.grantee	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
96	16	grantee_type	table_privileges.grantee_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
97	16	table_catalog	table_privileges.table_catalog	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
98	16	table_schema	table_privileges.table_schema	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
99	16	table_name	table_privileges.table_name	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
100	16	privilege_type	table_privileges.privilege_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
101	16	is_grantable	table_privileges.is_grantable	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
102	16	with_hierarchy	table_privileges.with_hierarchy	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
105	18	table_catalog	tables.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
106	18	table_schema	tables.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
107	18	table_name	tables.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
108	18	table_type	tables.table_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
123	21	table_catalog	views.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
124	21	table_schema	views.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
125	21	table_name	views.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
126	21	view_definition	views.view_definition	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
129	22	modalidade_imagem	achado_imagem.modalidade_imagem	varchar(20)	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
130	22	regiao_anatomica	achado_imagem.regiao_anatomica	varchar(80)	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(80)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
131	22	classificacao_bi_rads	achado_imagem.classificacao_bi_rads	smallint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
132	22	descricao_radiologica	achado_imagem.descricao_radiologica	varchar	f	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
133	22	recomendacao	achado_imagem.recomendacao	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
134	22	laudado_por	achado_imagem.laudado_por	varchar(12)	f	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(12)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
135	22	data_laudo_imagem	achado_imagem.data_laudo_imagem	date	f	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
56	6	nivel_clark	laudo_histopatologico.nivel_clark	tinyint	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "tinyint"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
57	6	margem_livre	laudo_histopatologico.margem_livre	tinyint	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "tinyint"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
58	6	indice_mitose	laudo_histopatologico.indice_mitose	decimal(4,1)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(4,1)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
59	6	estadiamento_tnm	laudo_histopatologico.estadiamento_tnm	varchar(10)	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(10)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
60	6	codigo_cid10	laudo_histopatologico.codigo_cid10	char(4)	f	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(4)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
61	6	data_laudo	laudo_histopatologico.data_laudo	date	f	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
62	6	numero_protocolo	laudo_histopatologico.numero_protocolo	varchar(30)	f	12	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(30)"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
67	8	grantee	applicable_roles.grantee	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
68	8	grantee_type	applicable_roles.grantee_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
69	8	role_name	applicable_roles.role_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
70	8	is_grantable	applicable_roles.is_grantable	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
79	10	table_catalog	columns.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
80	10	table_schema	columns.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
81	10	table_name	columns.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
82	10	column_name	columns.column_name	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
83	10	ordinal_position	columns.ordinal_position	bigint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
84	10	column_default	columns.column_default	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
85	10	is_nullable	columns.is_nullable	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
86	10	data_type	columns.data_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
89	12	role_name	enabled_roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
92	15	role_name	roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
103	17	catalog_name	schemata.catalog_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
104	17	schema_name	schemata.schema_name	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
109	19	grantor	table_privileges.grantor	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
110	19	grantor_type	table_privileges.grantor_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
111	19	grantee	table_privileges.grantee	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
112	19	grantee_type	table_privileges.grantee_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
113	19	table_catalog	table_privileges.table_catalog	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
114	19	table_schema	table_privileges.table_schema	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
115	19	table_name	table_privileges.table_name	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
116	19	privilege_type	table_privileges.privilege_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
117	19	is_grantable	table_privileges.is_grantable	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
118	19	with_hierarchy	table_privileges.with_hierarchy	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
119	20	table_catalog	tables.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
120	20	table_schema	tables.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
121	20	table_name	tables.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
122	20	table_type	tables.table_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
136	23	table_catalog	views.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
137	23	table_schema	views.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
138	23	table_name	views.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
139	23	view_definition	views.view_definition	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
163	26	valor_referencia_max	resultado_exame.valor_referencia_max	decimal(12,4)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(12,4)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
164	26	interpretacao	resultado_exame.interpretacao	varchar(20)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
165	26	metodo_analitico	resultado_exame.metodo_analitico	varchar(60)	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(60)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
166	26	data_coleta	resultado_exame.data_coleta	timestamp(6) with time zone	f	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
167	26	data_resultado	resultado_exame.data_resultado	timestamp(6) with time zone	t	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
168	26	laboratorio_executante	resultado_exame.laboratorio_executante	varchar(80)	t	12	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(80)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
183	28	data_ingresso	inscricao_programa.data_ingresso	date	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
184	28	proxima_realizacao	inscricao_programa.proxima_realizacao	date	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
185	28	risco_calculado	inscricao_programa.risco_calculado	varchar(15)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(15)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
186	28	motivo_ingresso	inscricao_programa.motivo_ingresso	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
205	30	denominacao	programa_prevencao.denominacao	varchar(120)	f	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(120)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
206	30	orgao_alvo	programa_prevencao.orgao_alvo	varchar(60)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(60)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
207	30	faixa_etaria_min	programa_prevencao.faixa_etaria_min	smallint	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
208	30	faixa_etaria_max	programa_prevencao.faixa_etaria_max	smallint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
209	30	periodicidade_meses	programa_prevencao.periodicidade_meses	smallint	f	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
210	30	metodo_exame	programa_prevencao.metodo_exame	varchar(200)	f	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(200)"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
211	30	criterio_inclusao	programa_prevencao.criterio_inclusao	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
212	30	vigente	programa_prevencao.vigente	boolean	f	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "boolean"}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
140	24	requisicao_id	requisicao_exame.requisicao_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.978048	2026-06-11 01:58:53.179836	\N	\N	t
141	24	beneficiario_id	requisicao_exame.beneficiario_id	integer	f	2	\N	\N	\N	f	f	f	t	5	35	requisicao_exame_beneficiario_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.978048	2026-06-11 01:58:53.187108	\N	\N	t
145	24	inscricao_id	requisicao_exame.inscricao_id	integer	t	6	\N	\N	\N	f	f	f	t	28	180	requisicao_exame_inscricao_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.978048	2026-06-11 01:58:53.193437	\N	\N	t
157	26	resultado_id	resultado_exame.resultado_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.978048	2026-06-11 01:58:53.196576	\N	\N	t
158	26	requisicao_id	resultado_exame.requisicao_id	integer	f	2	\N	\N	\N	f	f	f	t	24	140	resultado_exame_requisicao_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.978048	2026-06-11 01:58:53.202412	\N	\N	t
182	28	programa_id	inscricao_programa.programa_id	integer	f	3	\N	\N	\N	f	f	f	t	30	204	inscricao_programa_programa_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.978048	2026-06-11 01:58:54.360565	\N	\N	t
204	30	programa_id	programa_prevencao.programa_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.978048	2026-06-11 01:58:54.364794	\N	\N	t
180	28	inscricao_id	inscricao_programa.inscricao_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.978048	2026-06-11 01:58:54.370544	\N	\N	t
156	25	anotacao_medica	evolucao_clinica.anotacao_medica	varchar(65535)	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
170	27	laudo_id	protocolo_tratamento.laudo_id	integer	f	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
171	27	oncologista_crm	protocolo_tratamento.oncologista_crm	varchar(12)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(12)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
172	27	modalidade_terapia	protocolo_tratamento.modalidade_terapia	varchar(50)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(50)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
173	27	medicamento_principal	protocolo_tratamento.medicamento_principal	varchar(100)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(100)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
174	27	dose_mg	protocolo_tratamento.dose_mg	decimal(8,3)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(8,3)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
175	27	ciclos_previstos	protocolo_tratamento.ciclos_previstos	smallint	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
176	27	intervalo_dias	protocolo_tratamento.intervalo_dias	smallint	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
177	27	data_inicio	protocolo_tratamento.data_inicio	date	f	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
178	27	data_fim_prevista	protocolo_tratamento.data_fim_prevista	date	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
238	37	schema_name	schemata.schema_name	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
179	27	status_protocolo	protocolo_tratamento.status_protocolo	varchar(20)	f	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
189	29	medico_crm	agendamentos_ida.medico_crm	varchar(12)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(12)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
190	29	modalidade	agendamentos_ida.modalidade	varchar(30)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(30)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
191	29	data_hora_marcada	agendamentos_ida.data_hora_marcada	timestamp(0)	f	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(0)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
192	29	sala_numero	agendamentos_ida.sala_numero	smallint	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
193	29	status_agenda	agendamentos_ida.status_agenda	varchar(20)	f	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
195	31	cpf_titular	ficha_dermato.cpf_titular	char(11)	f	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(11)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
196	31	nome_completo	ficha_dermato.nome_completo	varchar(150)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(150)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
197	31	data_nascimento	ficha_dermato.data_nascimento	date	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
198	31	sexo_biologico	ficha_dermato.sexo_biologico	char(1)	f	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(1)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
199	31	cor_pele_fitzpatrick	ficha_dermato.cor_pele_fitzpatrick	smallint	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
200	31	historico_solar	ficha_dermato.historico_solar	varchar(65535)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
201	31	historico_familiar_melanoma	ficha_dermato.historico_familiar_melanoma	tinyint	f	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "tinyint"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
202	31	data_primeiro_atendimento	ficha_dermato.data_primeiro_atendimento	date	f	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
203	31	convenio_codigo	ficha_dermato.convenio_codigo	varchar(20)	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
215	32	localizacao_anatomica	lesoes_fotografadas.localizacao_anatomica	varchar(80)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(80)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
216	32	tamanho_mm	lesoes_fotografadas.tamanho_mm	decimal(6,2)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(6,2)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
217	32	formato_abcde	lesoes_fotografadas.formato_abcde	json	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "json"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
218	32	caminho_imagem_s3	lesoes_fotografadas.caminho_imagem_s3	varchar(65535)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
219	32	resolucao_dpi	lesoes_fotografadas.resolucao_dpi	bigint	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
220	32	equipamento_usado	lesoes_fotografadas.equipamento_usado	varchar(60)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(60)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
221	32	data_foto	lesoes_fotografadas.data_foto	timestamp(0)	f	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(0)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
222	32	revisado_por	lesoes_fotografadas.revisado_por	varchar(80)	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(80)"}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
148	25	evolucao_id	evolucao_clinica.evolucao_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.983062	2026-05-24 00:54:41.304188	\N	\N	t
149	25	protocolo_id	evolucao_clinica.protocolo_id	integer	f	2	\N	\N	\N	f	f	f	t	27	169	fk_evolucao_protocolo	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.983062	2026-05-24 00:54:41.313958	\N	\N	t
169	27	protocolo_id	protocolo_tratamento.protocolo_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.983062	2026-05-24 00:54:41.318288	\N	\N	t
187	29	agendamento_id	agendamentos_ida.agendamento_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.983062	2026-05-24 00:54:41.458863	\N	\N	t
188	29	ficha_id	agendamentos_ida.ficha_id	integer	f	2	\N	\N	\N	f	f	f	t	31	194	fk_agenda_ficha	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.983062	2026-05-24 00:54:41.463915	\N	\N	t
194	31	ficha_id	ficha_dermato.ficha_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.983062	2026-05-24 00:54:41.466362	\N	\N	t
213	32	lesao_id	lesoes_fotografadas.lesao_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.983062	2026-05-24 00:54:41.46896	\N	\N	t
214	32	ficha_id	lesoes_fotografadas.ficha_id	integer	f	2	\N	\N	\N	f	f	f	t	31	194	fk_lesao_ficha	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.983062	2026-05-24 00:54:41.47311	\N	\N	t
223	33	grantee	applicable_roles.grantee	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
224	33	grantee_type	applicable_roles.grantee_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
225	33	role_name	applicable_roles.role_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
226	33	is_grantable	applicable_roles.is_grantable	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
227	34	table_catalog	columns.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
228	34	table_schema	columns.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
229	34	table_name	columns.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
230	34	column_name	columns.column_name	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
231	34	ordinal_position	columns.ordinal_position	bigint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
232	34	column_default	columns.column_default	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
233	34	is_nullable	columns.is_nullable	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
234	34	data_type	columns.data_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
235	35	role_name	enabled_roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
236	36	role_name	roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
237	37	catalog_name	schemata.catalog_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
239	38	grantor	table_privileges.grantor	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
240	38	grantor_type	table_privileges.grantor_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
241	38	grantee	table_privileges.grantee	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
242	38	grantee_type	table_privileges.grantee_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
243	38	table_catalog	table_privileges.table_catalog	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
244	38	table_schema	table_privileges.table_schema	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
245	38	table_name	table_privileges.table_name	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
16	3	vital_id	indicadores_vitais.vital_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.888377	2026-06-11 01:58:53.02604	\N	\N	t
17	3	beneficiario_id	indicadores_vitais.beneficiario_id	integer	f	2	\N	\N	\N	f	f	f	t	5	35	indicadores_vitais_beneficiario_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.888377	2026-06-11 01:58:53.030451	\N	\N	t
127	22	achado_id	achado_imagem.achado_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.978048	2026-06-11 01:58:53.205473	\N	\N	t
128	22	requisicao_id	achado_imagem.requisicao_id	integer	f	2	\N	\N	\N	f	f	f	t	24	140	achado_imagem_requisicao_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.978048	2026-06-11 01:58:53.211051	\N	\N	t
181	28	beneficiario_id	inscricao_programa.beneficiario_id	integer	f	2	\N	\N	\N	f	f	f	t	5	35	inscricao_programa_beneficiario_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-05-24 00:42:37.978048	2026-06-11 01:58:54.388946	\N	\N	t
256	40	view_definition	views.view_definition	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
260	41	data_admissao	admissao_hospitalar.data_admissao	timestamp(6) with time zone	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
261	41	data_alta	admissao_hospitalar.data_alta	timestamp(6) with time zone	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
262	41	cid10_principal	admissao_hospitalar.cid10_principal	char(4)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(4)"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
263	41	desfecho	admissao_hospitalar.desfecho	varchar(15)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(15)"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
264	41	diaria_custo	admissao_hospitalar.diaria_custo	decimal(10,2)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(10,2)"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
266	42	setor	leito.setor	varchar(40)	f	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(40)"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
267	42	tipo_leito	leito.tipo_leito	varchar(15)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(15)"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
268	42	numero	leito.numero	varchar(10)	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(10)"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
269	42	ativo	leito.ativo	boolean	f	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "boolean"}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
272	43	codigo_tuss	procedimento_realizado.codigo_tuss	varchar(12)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(12)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
273	43	descricao	procedimento_realizado.descricao	varchar(200)	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(200)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
274	43	equipe	procedimento_realizado.equipe	varchar(80)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(80)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
275	43	data_hora	procedimento_realizado.data_hora	timestamp(6) with time zone	f	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
276	43	custo	procedimento_realizado.custo	decimal(10,2)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(10,2)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
279	44	medicamento	prescricao_urgencia.medicamento	varchar(120)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(120)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
280	44	dose	prescricao_urgencia.dose	varchar(40)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(40)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
281	44	via	prescricao_urgencia.via	varchar(20)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
282	44	frequencia	prescricao_urgencia.frequencia	varchar(40)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(40)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
283	44	prescrito_em	prescricao_urgencia.prescrito_em	timestamp(6) with time zone	f	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
284	44	medico_crm	prescricao_urgencia.medico_crm	varchar(12)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(12)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
287	45	aferido_em	sinal_vital_serie.aferido_em	timestamp(6) with time zone	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
288	45	pa_sistolica	sinal_vital_serie.pa_sistolica	smallint	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
289	45	pa_diastolica	sinal_vital_serie.pa_diastolica	smallint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
290	45	fc	sinal_vital_serie.fc	smallint	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
291	45	fr	sinal_vital_serie.fr	smallint	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
292	45	temperatura	sinal_vital_serie.temperatura	decimal(4,1)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(4,1)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
300	46	via_chegada	atendimento_emergencia.via_chegada	varchar(15)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(15)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
301	46	queixa_principal	atendimento_emergencia.queixa_principal	varchar(200)	f	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(200)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
302	46	pa_sistolica_ini	atendimento_emergencia.pa_sistolica_ini	smallint	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
303	46	pa_diastolica_ini	atendimento_emergencia.pa_diastolica_ini	smallint	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
304	46	fc_inicial	atendimento_emergencia.fc_inicial	smallint	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
305	46	sato2_inicial	atendimento_emergencia.sato2_inicial	decimal(4,1)	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(4,1)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
306	46	temperatura_ini	atendimento_emergencia.temperatura_ini	decimal(4,1)	t	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(4,1)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
307	46	desfecho_atend	atendimento_emergencia.desfecho_atend	varchar(20)	t	12	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
310	47	cor_risco	classificacao_manchester.cor_risco	varchar(10)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(10)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
311	47	tempo_alvo_min	classificacao_manchester.tempo_alvo_min	smallint	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
312	47	discriminador	classificacao_manchester.discriminador	varchar(120)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(120)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
313	47	fluxograma	classificacao_manchester.fluxograma	varchar(80)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(80)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
314	47	enfermeiro_coren	classificacao_manchester.enfermeiro_coren	varchar(12)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(12)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
315	47	classificado_em	classificacao_manchester.classificado_em	timestamp(6) with time zone	f	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
317	48	cpf_paciente	paciente_emergencia.cpf_paciente	char(11)	f	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(11)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
318	48	nome_completo	paciente_emergencia.nome_completo	varchar(150)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(150)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
319	48	data_nascimento	paciente_emergencia.data_nascimento	date	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
320	48	sexo_biologico	paciente_emergencia.sexo_biologico	char(1)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(1)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
321	48	tipo_sanguineo	paciente_emergencia.tipo_sanguineo	varchar(3)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(3)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
322	48	cartao_sus	paciente_emergencia.cartao_sus	varchar(15)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(15)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
323	48	municipio	paciente_emergencia.municipio	varchar(80)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(80)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
324	48	uf_sigla	paciente_emergencia.uf_sigla	char(2)	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(2)"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
325	48	cadastrado_em	paciente_emergencia.cadastrado_em	timestamp(6) with time zone	f	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
327	49	cliente_id	acompanhamento_adesao.cliente_id	integer	f	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
329	49	mes_referencia	acompanhamento_adesao.mes_referencia	date	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
330	49	doses_previstas	acompanhamento_adesao.doses_previstas	smallint	f	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
331	49	doses_retiradas	acompanhamento_adesao.doses_retiradas	smallint	f	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
332	49	indice_adesao_pct	acompanhamento_adesao.indice_adesao_pct	decimal(5,2)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(5,2)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
333	49	status_adesao	acompanhamento_adesao.status_adesao	varchar(15)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(15)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
335	50	nome_programa	programa_adesao.nome_programa	varchar(120)	f	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(120)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
336	50	doenca_alvo	programa_adesao.doenca_alvo	varchar(40)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(40)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
326	49	acompanhamento_id	acompanhamento_adesao.acompanhamento_id	bigint	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-06-03 02:33:33.403031	2026-06-11 01:56:52.244974	\N	\N	t
328	49	programa_id	acompanhamento_adesao.programa_id	integer	f	3	\N	\N	\N	f	f	f	t	50	334	fk_acomp_programa	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:33.403031	2026-06-11 01:56:52.254988	\N	\N	t
334	50	programa_id	programa_adesao.programa_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:33.403031	2026-06-11 01:56:52.26259	\N	\N	t
344	51	sexo_biologico	cliente_farmacia.sexo_biologico	char(1)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(1)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
345	51	telefone	cliente_farmacia.telefone	varchar(15)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(15)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
346	51	municipio	cliente_farmacia.municipio	varchar(80)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(80)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
347	51	uf_sigla	cliente_farmacia.uf_sigla	char(2)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(2)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
348	51	aceita_generico	cliente_farmacia.aceita_generico	tinyint	f	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "tinyint"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
349	51	cadastrado_em	cliente_farmacia.cadastrado_em	timestamp(0)	f	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(0)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
352	52	medicamento	item_dispensado.medicamento	varchar(120)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(120)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
353	52	principio_ativo	item_dispensado.principio_ativo	varchar(120)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(120)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
354	52	apresentacao	item_dispensado.apresentacao	varchar(60)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(60)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
355	52	quantidade	item_dispensado.quantidade	integer	f	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
356	52	lote	item_dispensado.lote	varchar(30)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(30)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
357	52	preco_unitario	item_dispensado.preco_unitario	decimal(10,2)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(10,2)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
358	52	valor_total	item_dispensado.valor_total	decimal(10,2)	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(10,2)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
359	52	data_retirada	item_dispensado.data_retirada	timestamp(0)	f	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(0)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
362	53	medico_crm	receita_medica.medico_crm	varchar(12)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(12)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
363	53	tipo_receita	receita_medica.tipo_receita	varchar(15)	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(15)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
364	53	data_prescricao	receita_medica.data_prescricao	date	f	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
365	53	validade	receita_medica.validade	date	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
366	53	cid10_associado	receita_medica.cid10_associado	char(4)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(4)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
367	53	origem_atendimento	receita_medica.origem_atendimento	varchar(40)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(40)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
369	54	cliente_id	evento_adverso.cliente_id	integer	f	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
370	54	medicamento_suspeito	evento_adverso.medicamento_suspeito	varchar(120)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(120)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
371	54	descricao_evento	evento_adverso.descricao_evento	varchar(65535)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
372	54	gravidade	evento_adverso.gravidade	varchar(10)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(10)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
373	54	desfecho	evento_adverso.desfecho	varchar(20)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
374	54	notificado_anvisa	evento_adverso.notificado_anvisa	tinyint	f	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "tinyint"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
375	54	data_evento	evento_adverso.data_evento	date	f	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
377	55	cliente_id	interacao_medicamentosa.cliente_id	integer	f	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
378	55	farmaco_a	interacao_medicamentosa.farmaco_a	varchar(120)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(120)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
379	55	farmaco_b	interacao_medicamentosa.farmaco_b	varchar(120)	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(120)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
380	55	severidade	interacao_medicamentosa.severidade	varchar(12)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(12)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
381	55	mecanismo	interacao_medicamentosa.mecanismo	varchar(200)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(200)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
382	55	recomendacao	interacao_medicamentosa.recomendacao	varchar(65535)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
350	52	item_id	item_dispensado.item_id	bigint	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-06-03 02:33:33.403031	2026-06-11 01:56:52.355418	\N	\N	t
387	56	is_grantable	applicable_roles.is_grantable	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
388	57	table_catalog	columns.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
389	57	table_schema	columns.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
390	57	table_name	columns.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
391	57	column_name	columns.column_name	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
392	57	ordinal_position	columns.ordinal_position	bigint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
393	57	column_default	columns.column_default	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
394	57	is_nullable	columns.is_nullable	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
395	57	data_type	columns.data_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
396	58	role_name	enabled_roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
397	59	role_name	roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
398	60	catalog_name	schemata.catalog_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
399	60	schema_name	schemata.schema_name	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
400	61	grantor	table_privileges.grantor	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
401	61	grantor_type	table_privileges.grantor_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
402	61	grantee	table_privileges.grantee	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
403	61	grantee_type	table_privileges.grantee_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
404	61	table_catalog	table_privileges.table_catalog	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
405	61	table_schema	table_privileges.table_schema	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
406	61	table_name	table_privileges.table_name	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
407	61	privilege_type	table_privileges.privilege_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
408	61	is_grantable	table_privileges.is_grantable	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
409	61	with_hierarchy	table_privileges.with_hierarchy	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
410	62	table_catalog	tables.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
411	62	table_schema	tables.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
412	62	table_name	tables.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
413	62	table_type	tables.table_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
414	63	table_catalog	views.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
415	63	table_schema	views.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
416	63	table_name	views.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
417	63	view_definition	views.view_definition	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
420	64	agente	contraste_administrado.agente	varchar(60)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(60)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
421	64	volume_ml	contraste_administrado.volume_ml	decimal(6,1)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(6,1)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
422	64	via	contraste_administrado.via	varchar(15)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(15)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
423	64	reacao_adversa	contraste_administrado.reacao_adversa	varchar(20)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
424	64	administrado_em	contraste_administrado.administrado_em	timestamp(6) with time zone	f	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
427	65	dose_mgy	dose_radiacao.dose_mgy	decimal(8,3)	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(8,3)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
428	65	dlp_mgycm	dose_radiacao.dlp_mgycm	decimal(10,3)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(10,3)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
429	65	kvp	dose_radiacao.kvp	smallint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "smallint"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
430	65	mas	dose_radiacao.mas	decimal(8,2)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(8,2)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
437	66	sala	equipamento.sala	varchar(20)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
438	66	tesla_ou_canais	equipamento.tesla_ou_canais	varchar(20)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
439	66	ativo	equipamento.ativo	boolean	f	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "boolean"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
442	67	radiologista_crm	laudo_radiologico.radiologista_crm	varchar(12)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(12)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
443	67	achados	laudo_radiologico.achados	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
444	67	impressao	laudo_radiologico.impressao	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
445	67	sistema_classif	laudo_radiologico.sistema_classif	varchar(10)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(10)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
446	67	categoria_classif	laudo_radiologico.categoria_classif	varchar(6)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(6)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
447	67	achado_critico	laudo_radiologico.achado_critico	boolean	f	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "boolean"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
448	67	data_laudo	laudo_radiologico.data_laudo	timestamp(6) with time zone	f	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
452	68	modalidade	ordem_exame.modalidade	varchar(10)	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(10)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
453	68	regiao_anatomica	ordem_exame.regiao_anatomica	varchar(80)	f	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(80)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
454	68	medico_solicitante	ordem_exame.medico_solicitante	varchar(12)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(12)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
455	68	indicacao_clinica	ordem_exame.indicacao_clinica	varchar(200)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(200)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
456	68	data_agendada	ordem_exame.data_agendada	timestamp(6) with time zone	f	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
457	68	data_realizada	ordem_exame.data_realizada	timestamp(6) with time zone	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
458	68	status_ordem	ordem_exame.status_ordem	varchar(15)	f	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(15)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
459	68	prioridade	ordem_exame.prioridade	varchar(10)	t	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(10)"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
460	69	grantee	applicable_roles.grantee	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
461	69	grantee_type	applicable_roles.grantee_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
462	69	role_name	applicable_roles.role_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
463	69	is_grantable	applicable_roles.is_grantable	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
464	70	table_catalog	columns.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
465	70	table_schema	columns.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
466	70	table_name	columns.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
467	70	column_name	columns.column_name	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
468	70	ordinal_position	columns.ordinal_position	bigint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
469	70	column_default	columns.column_default	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
470	70	is_nullable	columns.is_nullable	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
471	70	data_type	columns.data_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
472	71	role_name	enabled_roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
473	72	role_name	roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
474	73	catalog_name	schemata.catalog_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
475	73	schema_name	schemata.schema_name	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
476	74	grantor	table_privileges.grantor	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
477	74	grantor_type	table_privileges.grantor_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
481	74	table_schema	table_privileges.table_schema	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
482	74	table_name	table_privileges.table_name	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
483	74	privilege_type	table_privileges.privilege_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
484	74	is_grantable	table_privileges.is_grantable	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
485	74	with_hierarchy	table_privileges.with_hierarchy	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
486	75	table_catalog	tables.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
487	75	table_schema	tables.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
488	75	table_name	tables.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
489	75	table_type	tables.table_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
490	76	table_catalog	views.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
491	76	table_schema	views.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
492	76	table_name	views.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
493	76	view_definition	views.view_definition	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
495	77	cpf_pessoa	cadastro_paciente.cpf_pessoa	char(11)	f	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(11)"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
496	77	nome_completo	cadastro_paciente.nome_completo	varchar(150)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(150)"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
497	77	data_nascimento	cadastro_paciente.data_nascimento	date	f	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
498	77	sexo_biologico	cadastro_paciente.sexo_biologico	char(1)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(1)"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
499	77	peso_kg	cadastro_paciente.peso_kg	decimal(5,2)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(5,2)"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
500	77	altura_cm	cadastro_paciente.altura_cm	decimal(5,1)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "decimal(5,1)"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
501	77	alergia_contraste	cadastro_paciente.alergia_contraste	boolean	f	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "boolean"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
502	77	telefone	cadastro_paciente.telefone	varchar(15)	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(15)"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
503	77	municipio	cadastro_paciente.municipio	varchar(80)	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(80)"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
504	77	uf_sigla	cadastro_paciente.uf_sigla	char(2)	t	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "char(2)"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
505	77	cadastrado_em	cadastro_paciente.cadastrado_em	timestamp(6) with time zone	f	12	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "timestamp(6) with time zone"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
508	78	operadora_ans	convenio_vinculo.operadora_ans	varchar(20)	f	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
509	78	nome_plano	convenio_vinculo.nome_plano	varchar(80)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(80)"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
510	78	tipo_acomodacao	convenio_vinculo.tipo_acomodacao	varchar(20)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(20)"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
511	78	carteirinha	convenio_vinculo.carteirinha	varchar(30)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(30)"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
512	78	validade	convenio_vinculo.validade	date	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "date"}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
258	41	atendimento_id	admissao_hospitalar.atendimento_id	integer	f	2	\N	\N	\N	f	f	f	t	46	296	admissao_hospitalar_atendimento_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:27.910198	2026-06-11 01:56:36.057551	\N	\N	t
259	41	leito_id	admissao_hospitalar.leito_id	integer	f	3	\N	\N	\N	f	f	f	t	42	265	admissao_hospitalar_leito_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:27.910198	2026-06-11 01:56:36.06974	\N	\N	t
257	41	admissao_id	admissao_hospitalar.admissao_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:27.910198	2026-06-11 01:56:36.074548	\N	\N	t
265	42	leito_id	leito.leito_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:27.910198	2026-06-11 01:56:36.078919	\N	\N	t
271	43	admissao_id	procedimento_realizado.admissao_id	integer	f	2	\N	\N	\N	f	f	f	t	41	257	procedimento_realizado_admissao_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:28.085078	2026-06-11 01:56:36.094084	\N	\N	t
270	43	procedimento_id	procedimento_realizado.procedimento_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:28.085078	2026-06-11 01:56:36.09784	\N	\N	t
286	45	admissao_id	sinal_vital_serie.admissao_id	integer	f	2	\N	\N	\N	f	f	f	t	41	257	sinal_vital_serie_admissao_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:28.085078	2026-06-11 01:56:36.205996	\N	\N	t
285	45	vital_id	sinal_vital_serie.vital_id	bigint	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-06-03 02:33:28.085078	2026-06-11 01:56:36.210713	\N	\N	t
278	44	admissao_id	prescricao_urgencia.admissao_id	integer	f	2	\N	\N	\N	f	f	f	t	41	257	prescricao_urgencia_admissao_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:28.085078	2026-06-11 01:56:36.222654	\N	\N	t
277	44	prescricao_id	prescricao_urgencia.prescricao_id	bigint	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-06-03 02:33:28.085078	2026-06-11 01:56:36.229747	\N	\N	t
316	48	paciente_id	paciente_emergencia.paciente_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:28.085078	2026-06-11 01:56:37.341393	\N	\N	t
297	46	paciente_id	atendimento_emergencia.paciente_id	integer	f	2	\N	\N	\N	f	f	f	t	48	316	atendimento_emergencia_paciente_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:28.085078	2026-06-11 01:56:37.353926	\N	\N	t
296	46	atendimento_id	atendimento_emergencia.atendimento_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:28.085078	2026-06-11 01:56:37.359428	\N	\N	t
309	47	atendimento_id	classificacao_manchester.atendimento_id	integer	f	2	\N	\N	\N	f	f	f	t	46	296	classificacao_manchester_atendimento_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:28.085078	2026-06-11 01:56:37.366446	\N	\N	t
308	47	classificacao_id	classificacao_manchester.classificacao_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:28.085078	2026-06-11 01:56:37.370803	\N	\N	t
340	51	cliente_id	cliente_farmacia.cliente_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:33.403031	2026-06-11 01:56:52.349261	\N	\N	t
351	52	receita_id	item_dispensado.receita_id	integer	f	2	\N	\N	\N	f	f	f	t	53	360	fk_item_receita	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:33.403031	2026-06-11 01:56:52.362648	\N	\N	t
360	53	receita_id	receita_medica.receita_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:33.403031	2026-06-11 01:56:52.366257	\N	\N	t
361	53	cliente_id	receita_medica.cliente_id	integer	f	2	\N	\N	\N	f	f	f	t	51	340	fk_receita_cliente	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:33.403031	2026-06-11 01:56:52.373624	\N	\N	t
368	54	evento_id	evento_adverso.evento_id	bigint	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-06-03 02:33:33.403031	2026-06-11 01:56:52.462947	\N	\N	t
376	55	interacao_id	interacao_medicamentosa.interacao_id	bigint	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-06-03 02:33:33.403031	2026-06-11 01:56:52.467442	\N	\N	t
419	64	ordem_id	contraste_administrado.ordem_id	integer	f	2	\N	\N	\N	f	f	f	t	68	449	contraste_administrado_ordem_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:40.712157	2026-06-11 01:57:25.571068	\N	\N	t
418	64	contraste_id	contraste_administrado.contraste_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:40.712157	2026-06-11 01:57:25.573785	\N	\N	t
426	65	ordem_id	dose_radiacao.ordem_id	integer	f	2	\N	\N	\N	f	f	f	t	68	449	dose_radiacao_ordem_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:40.712157	2026-06-11 01:57:25.577644	\N	\N	t
425	65	dose_id	dose_radiacao.dose_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:40.712157	2026-06-11 01:57:25.581126	\N	\N	t
451	68	equip_id	ordem_exame.equip_id	integer	t	3	\N	\N	\N	f	f	f	t	66	433	ordem_exame_equip_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:40.712157	2026-06-11 01:57:25.69095	\N	\N	t
450	68	paciente_id	ordem_exame.paciente_id	integer	f	2	\N	\N	\N	f	f	f	t	77	494	ordem_exame_paciente_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:40.712157	2026-06-11 01:57:25.696297	\N	\N	t
449	68	ordem_id	ordem_exame.ordem_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:40.712157	2026-06-11 01:57:25.6997	\N	\N	t
433	66	equip_id	equipamento.equip_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:40.712157	2026-06-11 01:57:25.702633	\N	\N	t
441	67	ordem_id	laudo_radiologico.ordem_id	integer	f	2	\N	\N	\N	f	f	f	t	68	449	laudo_radiologico_ordem_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:40.712157	2026-06-11 01:57:25.708301	\N	\N	t
440	67	laudo_id	laudo_radiologico.laudo_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:40.712157	2026-06-11 01:57:25.711196	\N	\N	t
494	77	paciente_id	cadastro_paciente.paciente_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:40.786894	2026-06-11 01:57:25.913189	\N	\N	t
507	78	paciente_id	convenio_vinculo.paciente_id	integer	f	2	\N	\N	\N	f	f	f	t	77	494	convenio_vinculo_paciente_id_fkey	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:40.786894	2026-06-11 01:57:25.923999	\N	\N	t
506	78	vinculo_id	convenio_vinculo.vinculo_id	integer	f	1	\N	\N	\N	t	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "integer"}	2026-06-03 02:33:40.786894	2026-06-11 01:57:25.929288	\N	\N	t
513	79	grantee	applicable_roles.grantee	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
514	79	grantee_type	applicable_roles.grantee_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
515	79	role_name	applicable_roles.role_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
516	79	is_grantable	applicable_roles.is_grantable	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
517	80	table_catalog	columns.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
518	80	table_schema	columns.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
519	80	table_name	columns.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
520	80	column_name	columns.column_name	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
521	80	ordinal_position	columns.ordinal_position	bigint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
522	80	column_default	columns.column_default	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
523	80	is_nullable	columns.is_nullable	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
524	80	data_type	columns.data_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
525	81	role_name	enabled_roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
526	82	role_name	roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
527	83	catalog_name	schemata.catalog_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
528	83	schema_name	schemata.schema_name	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
529	84	grantor	table_privileges.grantor	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
530	84	grantor_type	table_privileges.grantor_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
531	84	grantee	table_privileges.grantee	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
532	84	grantee_type	table_privileges.grantee_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
533	84	table_catalog	table_privileges.table_catalog	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
534	84	table_schema	table_privileges.table_schema	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
535	84	table_name	table_privileges.table_name	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
536	84	privilege_type	table_privileges.privilege_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
537	84	is_grantable	table_privileges.is_grantable	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
538	84	with_hierarchy	table_privileges.with_hierarchy	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
539	85	table_catalog	tables.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
540	85	table_schema	tables.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
541	85	table_name	tables.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
542	85	table_type	tables.table_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
543	86	table_catalog	views.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
544	86	table_schema	views.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
545	86	table_name	views.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
546	86	view_definition	views.view_definition	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
547	87	isic_id	ham10000_metadata.isic_id	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
548	87	attribution	ham10000_metadata.attribution	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
549	87	copyright_license	ham10000_metadata.copyright_license	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
550	87	age_approx	ham10000_metadata.age_approx	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
551	87	anatom_site_1	ham10000_metadata.anatom_site_1	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
552	87	anatom_site_2	ham10000_metadata.anatom_site_2	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
553	87	anatom_site_3	ham10000_metadata.anatom_site_3	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
554	87	anatom_site_special	ham10000_metadata.anatom_site_special	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
555	87	concomitant_biopsy	ham10000_metadata.concomitant_biopsy	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
556	87	diagnosis_1	ham10000_metadata.diagnosis_1	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
557	87	diagnosis_2	ham10000_metadata.diagnosis_2	varchar	t	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
558	87	diagnosis_3	ham10000_metadata.diagnosis_3	varchar	t	12	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
559	87	diagnosis_confirm_type	ham10000_metadata.diagnosis_confirm_type	varchar	t	13	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
560	87	image_manipulation	ham10000_metadata.image_manipulation	varchar	t	14	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
561	87	image_type	ham10000_metadata.image_type	varchar	t	15	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
562	87	lesion_id	ham10000_metadata.lesion_id	varchar	t	16	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
563	87	melanocytic	ham10000_metadata.melanocytic	varchar	t	17	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
564	87	sex	ham10000_metadata.sex	varchar	t	18	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
565	87	source_collection_id	ham10000_metadata.source_collection_id	varchar	f	19	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
566	87	source_collection_name	ham10000_metadata.source_collection_name	varchar	f	20	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
567	87	source_snapshot_sha256	ham10000_metadata.source_snapshot_sha256	varchar	f	21	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
568	88	grantee	applicable_roles.grantee	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
569	88	grantee_type	applicable_roles.grantee_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
570	88	role_name	applicable_roles.role_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
571	88	is_grantable	applicable_roles.is_grantable	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
572	89	table_catalog	columns.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
573	89	table_schema	columns.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
574	89	table_name	columns.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
575	89	column_name	columns.column_name	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
576	89	ordinal_position	columns.ordinal_position	bigint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
577	89	column_default	columns.column_default	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
578	89	is_nullable	columns.is_nullable	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
579	89	data_type	columns.data_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
580	90	role_name	enabled_roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
581	91	role_name	roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
582	92	catalog_name	schemata.catalog_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
583	92	schema_name	schemata.schema_name	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
584	93	grantor	table_privileges.grantor	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
585	93	grantor_type	table_privileges.grantor_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
586	93	grantee	table_privileges.grantee	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
587	93	grantee_type	table_privileges.grantee_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
588	93	table_catalog	table_privileges.table_catalog	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
589	93	table_schema	table_privileges.table_schema	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
590	93	table_name	table_privileges.table_name	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
591	93	privilege_type	table_privileges.privilege_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
592	93	is_grantable	table_privileges.is_grantable	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
593	93	with_hierarchy	table_privileges.with_hierarchy	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
594	94	table_catalog	tables.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
595	94	table_schema	tables.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
596	94	table_name	tables.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
597	94	table_type	tables.table_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
598	95	table_catalog	views.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
599	95	table_schema	views.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
600	95	table_name	views.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
601	95	view_definition	views.view_definition	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
602	96	isic_id	hiba_metadata.isic_id	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
603	96	attribution	hiba_metadata.attribution	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
604	96	copyright_license	hiba_metadata.copyright_license	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
605	96	age_approx	hiba_metadata.age_approx	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
606	96	anatom_site_1	hiba_metadata.anatom_site_1	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
607	96	anatom_site_2	hiba_metadata.anatom_site_2	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
608	96	anatom_site_special	hiba_metadata.anatom_site_special	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
609	96	concomitant_biopsy	hiba_metadata.concomitant_biopsy	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
610	96	dermoscopic_type	hiba_metadata.dermoscopic_type	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
611	96	diagnosis_1	hiba_metadata.diagnosis_1	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
612	96	diagnosis_2	hiba_metadata.diagnosis_2	varchar	t	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
613	96	diagnosis_3	hiba_metadata.diagnosis_3	varchar	t	12	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
614	96	diagnosis_confirm_type	hiba_metadata.diagnosis_confirm_type	varchar	t	13	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
615	96	family_hx_mm	hiba_metadata.family_hx_mm	varchar	t	14	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
616	96	fitzpatrick_skin_type	hiba_metadata.fitzpatrick_skin_type	varchar	t	15	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
617	96	image_type	hiba_metadata.image_type	varchar	t	16	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
618	96	lesion_id	hiba_metadata.lesion_id	varchar	t	17	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
619	96	patient_id	hiba_metadata.patient_id	varchar	t	18	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
620	96	personal_hx_mm	hiba_metadata.personal_hx_mm	varchar	t	19	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
621	96	sex	hiba_metadata.sex	varchar	t	20	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
622	96	source_collection_id	hiba_metadata.source_collection_id	varchar	f	21	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
623	96	source_collection_name	hiba_metadata.source_collection_name	varchar	f	22	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
624	96	source_snapshot_sha256	hiba_metadata.source_snapshot_sha256	varchar	f	23	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
625	97	grantee	applicable_roles.grantee	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
626	97	grantee_type	applicable_roles.grantee_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
627	97	role_name	applicable_roles.role_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
628	97	is_grantable	applicable_roles.is_grantable	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
629	98	table_catalog	columns.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
630	98	table_schema	columns.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
631	98	table_name	columns.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
632	98	column_name	columns.column_name	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
633	98	ordinal_position	columns.ordinal_position	bigint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
634	98	column_default	columns.column_default	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
635	98	is_nullable	columns.is_nullable	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
636	98	data_type	columns.data_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
637	99	role_name	enabled_roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
638	100	role_name	roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
639	101	catalog_name	schemata.catalog_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
640	101	schema_name	schemata.schema_name	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
641	102	grantor	table_privileges.grantor	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
642	102	grantor_type	table_privileges.grantor_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
643	102	grantee	table_privileges.grantee	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
644	102	grantee_type	table_privileges.grantee_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
645	102	table_catalog	table_privileges.table_catalog	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
646	102	table_schema	table_privileges.table_schema	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
647	102	table_name	table_privileges.table_name	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
648	102	privilege_type	table_privileges.privilege_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
649	102	is_grantable	table_privileges.is_grantable	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
650	102	with_hierarchy	table_privileges.with_hierarchy	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
651	103	table_catalog	tables.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
652	103	table_schema	tables.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
653	103	table_name	tables.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
654	103	table_type	tables.table_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
655	104	table_catalog	views.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
656	104	table_schema	views.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
657	104	table_name	views.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
658	104	view_definition	views.view_definition	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
659	105	isic_id	pad_ufes_20_metadata.isic_id	varchar(65535)	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
660	105	attribution	pad_ufes_20_metadata.attribution	varchar(65535)	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
661	105	copyright_license	pad_ufes_20_metadata.copyright_license	varchar(65535)	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
662	105	age_approx	pad_ufes_20_metadata.age_approx	varchar(65535)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
663	105	anatom_site_1	pad_ufes_20_metadata.anatom_site_1	varchar(65535)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
664	105	anatom_site_2	pad_ufes_20_metadata.anatom_site_2	varchar(65535)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
665	105	anatom_site_3	pad_ufes_20_metadata.anatom_site_3	varchar(65535)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
666	105	anatom_site_4	pad_ufes_20_metadata.anatom_site_4	varchar(65535)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
667	105	anatom_site_5	pad_ufes_20_metadata.anatom_site_5	varchar(65535)	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
668	105	anatom_site_special	pad_ufes_20_metadata.anatom_site_special	varchar(65535)	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
669	105	clin_size_long_diam_mm	pad_ufes_20_metadata.clin_size_long_diam_mm	varchar(65535)	t	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
670	105	diagnosis_1	pad_ufes_20_metadata.diagnosis_1	varchar(65535)	t	12	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
671	105	diagnosis_2	pad_ufes_20_metadata.diagnosis_2	varchar(65535)	t	13	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
672	105	diagnosis_3	pad_ufes_20_metadata.diagnosis_3	varchar(65535)	t	14	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
673	105	diagnosis_confirm_type	pad_ufes_20_metadata.diagnosis_confirm_type	varchar(65535)	t	15	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
674	105	fitzpatrick_skin_type	pad_ufes_20_metadata.fitzpatrick_skin_type	varchar(65535)	t	16	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
675	105	image_type	pad_ufes_20_metadata.image_type	varchar(65535)	t	17	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
676	105	lesion_id	pad_ufes_20_metadata.lesion_id	varchar(65535)	t	18	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
677	105	patient_id	pad_ufes_20_metadata.patient_id	varchar(65535)	t	19	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
678	105	sex	pad_ufes_20_metadata.sex	varchar(65535)	t	20	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
679	105	source_collection_id	pad_ufes_20_metadata.source_collection_id	varchar(16)	f	21	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(16)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
680	105	source_collection_name	pad_ufes_20_metadata.source_collection_name	varchar(100)	f	22	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(100)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
681	105	source_snapshot_sha256	pad_ufes_20_metadata.source_snapshot_sha256	varchar(64)	f	23	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(64)"}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
682	106	grantee	applicable_roles.grantee	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
683	106	grantee_type	applicable_roles.grantee_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
684	106	role_name	applicable_roles.role_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
685	106	is_grantable	applicable_roles.is_grantable	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
686	107	table_catalog	columns.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
687	107	table_schema	columns.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
688	107	table_name	columns.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
689	107	column_name	columns.column_name	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
690	107	ordinal_position	columns.ordinal_position	bigint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
691	107	column_default	columns.column_default	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
692	107	is_nullable	columns.is_nullable	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
693	107	data_type	columns.data_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
694	108	role_name	enabled_roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
695	109	role_name	roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
696	110	catalog_name	schemata.catalog_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
697	110	schema_name	schemata.schema_name	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
698	111	grantor	table_privileges.grantor	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
699	111	grantor_type	table_privileges.grantor_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
700	111	grantee	table_privileges.grantee	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
701	111	grantee_type	table_privileges.grantee_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
702	111	table_catalog	table_privileges.table_catalog	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
703	111	table_schema	table_privileges.table_schema	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
704	111	table_name	table_privileges.table_name	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
705	111	privilege_type	table_privileges.privilege_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
706	111	is_grantable	table_privileges.is_grantable	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
707	111	with_hierarchy	table_privileges.with_hierarchy	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
708	112	table_catalog	tables.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
709	112	table_schema	tables.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
710	112	table_name	tables.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
711	112	table_type	tables.table_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
712	113	table_catalog	views.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
713	113	table_schema	views.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
714	113	table_name	views.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
715	113	view_definition	views.view_definition	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
716	114	isic_id	metadata.isic_id	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
717	114	attribution	metadata.attribution	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
718	114	copyright_license	metadata.copyright_license	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
719	114	age_approx	metadata.age_approx	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
720	114	anatom_site_1	metadata.anatom_site_1	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
721	114	anatom_site_2	metadata.anatom_site_2	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
722	114	anatom_site_3	metadata.anatom_site_3	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
723	114	anatom_site_special	metadata.anatom_site_special	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
724	114	concomitant_biopsy	metadata.concomitant_biopsy	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
725	114	diagnosis_1	metadata.diagnosis_1	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
726	114	diagnosis_2	metadata.diagnosis_2	varchar	t	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
727	114	diagnosis_3	metadata.diagnosis_3	varchar	t	12	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
728	114	diagnosis_confirm_type	metadata.diagnosis_confirm_type	varchar	t	13	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
729	114	image_manipulation	metadata.image_manipulation	varchar	t	14	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
730	114	image_type	metadata.image_type	varchar	t	15	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
731	114	lesion_id	metadata.lesion_id	varchar	t	16	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
732	114	melanocytic	metadata.melanocytic	varchar	t	17	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
733	114	sex	metadata.sex	varchar	t	18	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
734	114	source_collection_id	metadata.source_collection_id	varchar	f	19	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
735	114	source_collection_name	metadata.source_collection_name	varchar	f	20	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
736	114	source_snapshot_sha256	metadata.source_snapshot_sha256	varchar	f	21	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
737	115	grantee	applicable_roles.grantee	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
738	115	grantee_type	applicable_roles.grantee_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
739	115	role_name	applicable_roles.role_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
740	115	is_grantable	applicable_roles.is_grantable	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
741	116	table_catalog	columns.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
742	116	table_schema	columns.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
743	116	table_name	columns.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
744	116	column_name	columns.column_name	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
745	116	ordinal_position	columns.ordinal_position	bigint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
746	116	column_default	columns.column_default	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
747	116	is_nullable	columns.is_nullable	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
748	116	data_type	columns.data_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
749	117	role_name	enabled_roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
750	118	role_name	roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
751	119	catalog_name	schemata.catalog_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
752	119	schema_name	schemata.schema_name	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
753	120	grantor	table_privileges.grantor	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
754	120	grantor_type	table_privileges.grantor_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
755	120	grantee	table_privileges.grantee	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
756	120	grantee_type	table_privileges.grantee_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
757	120	table_catalog	table_privileges.table_catalog	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
758	120	table_schema	table_privileges.table_schema	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
759	120	table_name	table_privileges.table_name	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
760	120	privilege_type	table_privileges.privilege_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
761	120	is_grantable	table_privileges.is_grantable	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
762	120	with_hierarchy	table_privileges.with_hierarchy	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
763	121	table_catalog	tables.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
764	121	table_schema	tables.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
765	121	table_name	tables.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
766	121	table_type	tables.table_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
767	122	table_catalog	views.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
768	122	table_schema	views.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
769	122	table_name	views.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
770	122	view_definition	views.view_definition	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
771	123	isic_id	metadata.isic_id	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
772	123	attribution	metadata.attribution	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
773	123	copyright_license	metadata.copyright_license	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
774	123	age_approx	metadata.age_approx	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
775	123	anatom_site_1	metadata.anatom_site_1	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
776	123	anatom_site_2	metadata.anatom_site_2	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
777	123	anatom_site_special	metadata.anatom_site_special	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
778	123	concomitant_biopsy	metadata.concomitant_biopsy	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
779	123	dermoscopic_type	metadata.dermoscopic_type	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
780	123	diagnosis_1	metadata.diagnosis_1	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
781	123	diagnosis_2	metadata.diagnosis_2	varchar	t	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
782	123	diagnosis_3	metadata.diagnosis_3	varchar	t	12	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
783	123	diagnosis_confirm_type	metadata.diagnosis_confirm_type	varchar	t	13	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
784	123	family_hx_mm	metadata.family_hx_mm	varchar	t	14	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
785	123	fitzpatrick_skin_type	metadata.fitzpatrick_skin_type	varchar	t	15	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
786	123	image_type	metadata.image_type	varchar	t	16	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
787	123	lesion_id	metadata.lesion_id	varchar	t	17	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
788	123	patient_id	metadata.patient_id	varchar	t	18	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
789	123	personal_hx_mm	metadata.personal_hx_mm	varchar	t	19	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
790	123	sex	metadata.sex	varchar	t	20	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
791	123	source_collection_id	metadata.source_collection_id	varchar	f	21	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
792	123	source_collection_name	metadata.source_collection_name	varchar	f	22	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
793	123	source_snapshot_sha256	metadata.source_snapshot_sha256	varchar	f	23	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
794	124	grantee	applicable_roles.grantee	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
795	124	grantee_type	applicable_roles.grantee_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
796	124	role_name	applicable_roles.role_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
797	124	is_grantable	applicable_roles.is_grantable	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
798	125	table_catalog	columns.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
799	125	table_schema	columns.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
800	125	table_name	columns.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
801	125	column_name	columns.column_name	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
802	125	ordinal_position	columns.ordinal_position	bigint	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "bigint"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
803	125	column_default	columns.column_default	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
804	125	is_nullable	columns.is_nullable	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
805	125	data_type	columns.data_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
806	126	role_name	enabled_roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
807	127	role_name	roles.role_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
808	128	catalog_name	schemata.catalog_name	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
809	128	schema_name	schemata.schema_name	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
810	129	grantor	table_privileges.grantor	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
811	129	grantor_type	table_privileges.grantor_type	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
812	129	grantee	table_privileges.grantee	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
813	129	grantee_type	table_privileges.grantee_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
814	129	table_catalog	table_privileges.table_catalog	varchar	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
815	129	table_schema	table_privileges.table_schema	varchar	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
816	129	table_name	table_privileges.table_name	varchar	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
817	129	privilege_type	table_privileges.privilege_type	varchar	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
818	129	is_grantable	table_privileges.is_grantable	varchar	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
819	129	with_hierarchy	table_privileges.with_hierarchy	varchar	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
820	130	table_catalog	tables.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
821	130	table_schema	tables.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
822	130	table_name	tables.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
823	130	table_type	tables.table_type	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
824	131	table_catalog	views.table_catalog	varchar	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
825	131	table_schema	views.table_schema	varchar	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
826	131	table_name	views.table_name	varchar	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
827	131	view_definition	views.view_definition	varchar	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
828	132	isic_id	metadata.isic_id	varchar(65535)	t	1	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
829	132	attribution	metadata.attribution	varchar(65535)	t	2	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
830	132	copyright_license	metadata.copyright_license	varchar(65535)	t	3	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
831	132	age_approx	metadata.age_approx	varchar(65535)	t	4	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
832	132	anatom_site_1	metadata.anatom_site_1	varchar(65535)	t	5	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
833	132	anatom_site_2	metadata.anatom_site_2	varchar(65535)	t	6	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
834	132	anatom_site_3	metadata.anatom_site_3	varchar(65535)	t	7	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
835	132	anatom_site_4	metadata.anatom_site_4	varchar(65535)	t	8	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
836	132	anatom_site_5	metadata.anatom_site_5	varchar(65535)	t	9	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
837	132	anatom_site_special	metadata.anatom_site_special	varchar(65535)	t	10	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
838	132	clin_size_long_diam_mm	metadata.clin_size_long_diam_mm	varchar(65535)	t	11	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
839	132	diagnosis_1	metadata.diagnosis_1	varchar(65535)	t	12	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
840	132	diagnosis_2	metadata.diagnosis_2	varchar(65535)	t	13	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
841	132	diagnosis_3	metadata.diagnosis_3	varchar(65535)	t	14	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
842	132	diagnosis_confirm_type	metadata.diagnosis_confirm_type	varchar(65535)	t	15	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
843	132	fitzpatrick_skin_type	metadata.fitzpatrick_skin_type	varchar(65535)	t	16	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
844	132	image_type	metadata.image_type	varchar(65535)	t	17	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
845	132	lesion_id	metadata.lesion_id	varchar(65535)	t	18	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
846	132	patient_id	metadata.patient_id	varchar(65535)	t	19	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
847	132	sex	metadata.sex	varchar(65535)	t	20	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(65535)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
848	132	source_collection_id	metadata.source_collection_id	varchar(16)	f	21	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(16)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
849	132	source_collection_name	metadata.source_collection_name	varchar(100)	f	22	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(100)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
850	132	source_snapshot_sha256	metadata.source_snapshot_sha256	varchar(64)	f	23	\N	\N	\N	f	f	f	f	\N	\N	\N	\N	\N	f	\N	{}	[]	{"full_data_type": "varchar(64)"}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
\.


--
-- Data for Name: external_schemas; Type: TABLE DATA; Schema: metadata; Owner: -
--

COPY metadata.external_schemas (id, catalog_id, connection_id, schema_name, external_reference, is_system_schema, properties, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	1	3	cadastro_beneficiario	cmpd___centro_de_medicina_preventiva_e_diagn_stico_3.cadastro_beneficiario	f	{}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
2	2	4	anatomopatologia	ida___instituto_de_dermatologia_avan_ada_4.anatomopatologia	f	{}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
3	1	3	information_schema	cmpd___centro_de_medicina_preventiva_e_diagn_stico_3.information_schema	t	{}	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
4	2	4	information_schema	ida___instituto_de_dermatologia_avan_ada_4.information_schema	t	{}	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
5	1	3	laboratorio	cmpd___centro_de_medicina_preventiva_e_diagn_stico_3.laboratorio	f	{}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
6	2	4	oncologia_pele	ida___instituto_de_dermatologia_avan_ada_4.oncologia_pele	f	{}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
7	1	3	pg_catalog	cmpd___centro_de_medicina_preventiva_e_diagn_stico_3.pg_catalog	t	{}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
8	1	3	public	cmpd___centro_de_medicina_preventiva_e_diagn_stico_3.public	f	{}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
9	2	4	performance_schema	ida___instituto_de_dermatologia_avan_ada_4.performance_schema	t	{}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
10	1	3	rastreamento	cmpd___centro_de_medicina_preventiva_e_diagn_stico_3.rastreamento	f	{}	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
11	2	4	triagem	ida___instituto_de_dermatologia_avan_ada_4.triagem	f	{}	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
12	3	5	information_schema	reh___rede_de_emerg_ncias_hospitalares_5.information_schema	t	{}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
13	3	5	internacao	reh___rede_de_emerg_ncias_hospitalares_5.internacao	f	{}	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
14	3	5	monitoramento	reh___rede_de_emerg_ncias_hospitalares_5.monitoramento	f	{}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
15	3	5	pg_catalog	reh___rede_de_emerg_ncias_hospitalares_5.pg_catalog	t	{}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
16	3	5	pronto_socorro	reh___rede_de_emerg_ncias_hospitalares_5.pronto_socorro	f	{}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
17	3	5	public	reh___rede_de_emerg_ncias_hospitalares_5.public	f	{}	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
18	4	7	adesao_terapeutica	rfa___rede_de_farm_cias_e_ades_o_7.adesao_terapeutica	f	{}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
19	4	7	dispensacao	rfa___rede_de_farm_cias_e_ades_o_7.dispensacao	f	{}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
20	4	7	farmacovigilancia	rfa___rede_de_farm_cias_e_ades_o_7.farmacovigilancia	f	{}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
21	4	7	information_schema	rfa___rede_de_farm_cias_e_ades_o_7.information_schema	t	{}	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
22	4	7	performance_schema	rfa___rede_de_farm_cias_e_ades_o_7.performance_schema	t	{}	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
23	5	6	dosimetria	cdi___centro_de_diagn_stico_por_imagem_6.dosimetria	f	{}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
24	5	6	exames	cdi___centro_de_diagn_stico_por_imagem_6.exames	f	{}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
25	5	6	information_schema	cdi___centro_de_diagn_stico_por_imagem_6.information_schema	t	{}	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
26	5	6	pacientes	cdi___centro_de_diagn_stico_por_imagem_6.pacientes	f	{}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
27	5	6	pg_catalog	cdi___centro_de_diagn_stico_por_imagem_6.pg_catalog	t	{}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
28	5	6	public	cdi___centro_de_diagn_stico_por_imagem_6.public	f	{}	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
29	6	8	information_schema	dermexp3_ham10000_collection_212_8.information_schema	t	{}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
30	6	8	isic	dermexp3_ham10000_collection_212_8.isic	f	{}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
31	6	8	pg_catalog	dermexp3_ham10000_collection_212_8.pg_catalog	t	{}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
32	6	8	public	dermexp3_ham10000_collection_212_8.public	f	{}	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
33	7	9	information_schema	dermexp3_hiba_collection_251_9.information_schema	t	{}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
34	7	9	isic	dermexp3_hiba_collection_251_9.isic	f	{}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
35	7	9	pg_catalog	dermexp3_hiba_collection_251_9.pg_catalog	t	{}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
36	7	9	public	dermexp3_hiba_collection_251_9.public	f	{}	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
37	8	10	information_schema	dermexp3_pad_ufes_20_collection_406_10.information_schema	t	{}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
38	8	10	isic	dermexp3_pad_ufes_20_collection_406_10.isic	f	{}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
39	8	10	performance_schema	dermexp3_pad_ufes_20_collection_406_10.performance_schema	t	{}	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
40	9	11	information_schema	dermexp3_v2_ham10000_collection_212_11.information_schema	t	{}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
41	9	11	isic	dermexp3_v2_ham10000_collection_212_11.isic	f	{}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
42	9	11	pg_catalog	dermexp3_v2_ham10000_collection_212_11.pg_catalog	t	{}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
43	9	11	public	dermexp3_v2_ham10000_collection_212_11.public	f	{}	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
44	10	12	information_schema	dermexp3_v2_hiba_collection_251_12.information_schema	t	{}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
45	10	12	isic	dermexp3_v2_hiba_collection_251_12.isic	f	{}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
46	10	12	pg_catalog	dermexp3_v2_hiba_collection_251_12.pg_catalog	t	{}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
47	10	12	public	dermexp3_v2_hiba_collection_251_12.public	f	{}	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
48	11	13	information_schema	dermexp3_v2_pad_ufes_20_collection_406_13.information_schema	t	{}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
49	11	13	isic	dermexp3_v2_pad_ufes_20_collection_406_13.isic	f	{}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
50	11	13	performance_schema	dermexp3_v2_pad_ufes_20_collection_406_13.performance_schema	t	{}	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
\.


--
-- Data for Name: external_tables; Type: TABLE DATA; Schema: metadata; Owner: -
--

COPY metadata.external_tables (id, schema_id, connection_id, table_name, external_reference, table_type, estimated_row_count, total_size_bytes, last_analyzed, properties, description, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	1	3	antecedentes_clinicos	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."cadastro_beneficiario"."antecedentes_clinicos"	table	1706	0	\N	{}	\N	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
2	2	4	biopsia_solicitacao	"ida___instituto_de_dermatologia_avan_ada_4"."anatomopatologia"."biopsia_solicitacao"	table	672	0	\N	{}	\N	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
3	1	3	indicadores_vitais	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."cadastro_beneficiario"."indicadores_vitais"	table	3008	0	\N	{}	\N	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
4	2	4	imunohistoquimica	"ida___instituto_de_dermatologia_avan_ada_4"."anatomopatologia"."imunohistoquimica"	table	1348	0	\N	{}	\N	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
5	1	3	perfil_saude	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."cadastro_beneficiario"."perfil_saude"	table	1505	0	\N	{}	\N	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
6	2	4	laudo_histopatologico	"ida___instituto_de_dermatologia_avan_ada_4"."anatomopatologia"."laudo_histopatologico"	table	672	0	\N	{}	\N	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
7	3	3	applicable_roles	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."information_schema"."applicable_roles"	table	0	0	\N	{}	\N	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
8	4	4	applicable_roles	"ida___instituto_de_dermatologia_avan_ada_4"."information_schema"."applicable_roles"	table	0	0	\N	{}	\N	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
9	3	3	columns	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."information_schema"."columns"	table	116	0	\N	{}	\N	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
10	4	4	columns	"ida___instituto_de_dermatologia_avan_ada_4"."information_schema"."columns"	table	106	0	\N	{}	\N	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
11	3	3	enabled_roles	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."information_schema"."enabled_roles"	table	0	0	\N	{}	\N	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
12	4	4	enabled_roles	"ida___instituto_de_dermatologia_avan_ada_4"."information_schema"."enabled_roles"	table	0	0	\N	{}	\N	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
13	3	3	roles	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."information_schema"."roles"	table	0	0	\N	{}	\N	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
14	3	3	schemata	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."information_schema"."schemata"	table	6	0	\N	{}	\N	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
15	4	4	roles	"ida___instituto_de_dermatologia_avan_ada_4"."information_schema"."roles"	table	0	0	\N	{}	\N	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
16	3	3	table_privileges	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."information_schema"."table_privileges"	table	0	0	\N	{}	\N	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
17	4	4	schemata	"ida___instituto_de_dermatologia_avan_ada_4"."information_schema"."schemata"	table	5	0	\N	{}	\N	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
18	3	3	tables	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."information_schema"."tables"	table	16	0	\N	{}	\N	2026-05-24 00:42:37.888377	2026-05-24 00:42:37.888377	\N	\N	t
19	4	4	table_privileges	"ida___instituto_de_dermatologia_avan_ada_4"."information_schema"."table_privileges"	table	0	0	\N	{}	\N	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
20	4	4	tables	"ida___instituto_de_dermatologia_avan_ada_4"."information_schema"."tables"	table	16	0	\N	{}	\N	2026-05-24 00:42:37.889639	2026-05-24 00:42:37.889639	\N	\N	t
21	3	3	views	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."information_schema"."views"	table	0	0	\N	{}	\N	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
22	5	3	achado_imagem	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."laboratorio"."achado_imagem"	table	303	0	\N	{}	\N	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
23	4	4	views	"ida___instituto_de_dermatologia_avan_ada_4"."information_schema"."views"	table	0	0	\N	{}	\N	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
24	5	3	requisicao_exame	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."laboratorio"."requisicao_exame"	table	1505	0	\N	{}	\N	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
25	6	4	evolucao_clinica	"ida___instituto_de_dermatologia_avan_ada_4"."oncologia_pele"."evolucao_clinica"	table	1012	0	\N	{}	\N	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
26	5	3	resultado_exame	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."laboratorio"."resultado_exame"	table	4517	0	\N	{}	\N	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
27	6	4	protocolo_tratamento	"ida___instituto_de_dermatologia_avan_ada_4"."oncologia_pele"."protocolo_tratamento"	table	337	0	\N	{}	\N	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
28	10	3	inscricao_programa	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."rastreamento"."inscricao_programa"	table	2109	0	\N	{}	\N	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
29	11	4	agendamentos_ida	"ida___instituto_de_dermatologia_avan_ada_4"."triagem"."agendamentos_ida"	table	1508	0	\N	{}	\N	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
30	10	3	programa_prevencao	"cmpd___centro_de_medicina_preventiva_e_diagn_stico_3"."rastreamento"."programa_prevencao"	table	5	0	\N	{}	\N	2026-05-24 00:42:37.978048	2026-05-24 00:42:37.978048	\N	\N	t
31	11	4	ficha_dermato	"ida___instituto_de_dermatologia_avan_ada_4"."triagem"."ficha_dermato"	table	1005	0	\N	{}	\N	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
32	11	4	lesoes_fotografadas	"ida___instituto_de_dermatologia_avan_ada_4"."triagem"."lesoes_fotografadas"	table	1506	0	\N	{}	\N	2026-05-24 00:42:37.983062	2026-05-24 00:42:37.983062	\N	\N	t
33	12	5	applicable_roles	"reh___rede_de_emerg_ncias_hospitalares_5"."information_schema"."applicable_roles"	table	0	0	\N	{}	\N	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
34	12	5	columns	"reh___rede_de_emerg_ncias_hospitalares_5"."information_schema"."columns"	table	103	0	\N	{}	\N	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
35	12	5	enabled_roles	"reh___rede_de_emerg_ncias_hospitalares_5"."information_schema"."enabled_roles"	table	0	0	\N	{}	\N	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
36	12	5	roles	"reh___rede_de_emerg_ncias_hospitalares_5"."information_schema"."roles"	table	0	0	\N	{}	\N	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
37	12	5	schemata	"reh___rede_de_emerg_ncias_hospitalares_5"."information_schema"."schemata"	table	6	0	\N	{}	\N	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
38	12	5	table_privileges	"reh___rede_de_emerg_ncias_hospitalares_5"."information_schema"."table_privileges"	table	0	0	\N	{}	\N	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
39	12	5	tables	"reh___rede_de_emerg_ncias_hospitalares_5"."information_schema"."tables"	table	16	0	\N	{}	\N	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
40	12	5	views	"reh___rede_de_emerg_ncias_hospitalares_5"."information_schema"."views"	table	0	0	\N	{}	\N	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
41	13	5	admissao_hospitalar	"reh___rede_de_emerg_ncias_hospitalares_5"."internacao"."admissao_hospitalar"	table	4500002	0	\N	{}	\N	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
42	13	5	leito	"reh___rede_de_emerg_ncias_hospitalares_5"."internacao"."leito"	table	303	0	\N	{}	\N	2026-06-03 02:33:27.910198	2026-06-03 02:33:27.910198	\N	\N	t
43	13	5	procedimento_realizado	"reh___rede_de_emerg_ncias_hospitalares_5"."internacao"."procedimento_realizado"	table	4500002	0	\N	{}	\N	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
44	14	5	prescricao_urgencia	"reh___rede_de_emerg_ncias_hospitalares_5"."monitoramento"."prescricao_urgencia"	table	9000003	0	\N	{}	\N	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
45	14	5	sinal_vital_serie	"reh___rede_de_emerg_ncias_hospitalares_5"."monitoramento"."sinal_vital_serie"	table	13500004	0	\N	{}	\N	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
46	16	5	atendimento_emergencia	"reh___rede_de_emerg_ncias_hospitalares_5"."pronto_socorro"."atendimento_emergencia"	table	15000004	0	\N	{}	\N	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
47	16	5	classificacao_manchester	"reh___rede_de_emerg_ncias_hospitalares_5"."pronto_socorro"."classificacao_manchester"	table	15000004	0	\N	{}	\N	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
48	16	5	paciente_emergencia	"reh___rede_de_emerg_ncias_hospitalares_5"."pronto_socorro"."paciente_emergencia"	table	15000004	0	\N	{}	\N	2026-06-03 02:33:28.085078	2026-06-03 02:33:28.085078	\N	\N	t
49	18	7	acompanhamento_adesao	"rfa___rede_de_farm_cias_e_ades_o_7"."adesao_terapeutica"."acompanhamento_adesao"	table	39600002	0	\N	{}	\N	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
50	18	7	programa_adesao	"rfa___rede_de_farm_cias_e_ades_o_7"."adesao_terapeutica"."programa_adesao"	table	8	0	\N	{}	\N	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
51	19	7	cliente_farmacia	"rfa___rede_de_farm_cias_e_ades_o_7"."dispensacao"."cliente_farmacia"	table	22000004	0	\N	{}	\N	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
52	19	7	item_dispensado	"rfa___rede_de_farm_cias_e_ades_o_7"."dispensacao"."item_dispensado"	table	66000004	0	\N	{}	\N	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
53	19	7	receita_medica	"rfa___rede_de_farm_cias_e_ades_o_7"."dispensacao"."receita_medica"	table	22000004	0	\N	{}	\N	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
54	20	7	evento_adverso	"rfa___rede_de_farm_cias_e_ades_o_7"."farmacovigilancia"."evento_adverso"	table	1100002	0	\N	{}	\N	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
55	20	7	interacao_medicamentosa	"rfa___rede_de_farm_cias_e_ades_o_7"."farmacovigilancia"."interacao_medicamentosa"	table	2200001	0	\N	{}	\N	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
56	21	7	applicable_roles	"rfa___rede_de_farm_cias_e_ades_o_7"."information_schema"."applicable_roles"	table	0	0	\N	{}	\N	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
57	21	7	columns	"rfa___rede_de_farm_cias_e_ades_o_7"."information_schema"."columns"	table	92	0	\N	{}	\N	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
58	21	7	enabled_roles	"rfa___rede_de_farm_cias_e_ades_o_7"."information_schema"."enabled_roles"	table	0	0	\N	{}	\N	2026-06-03 02:33:33.403031	2026-06-03 02:33:33.403031	\N	\N	t
59	21	7	roles	"rfa___rede_de_farm_cias_e_ades_o_7"."information_schema"."roles"	table	0	0	\N	{}	\N	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
60	21	7	schemata	"rfa___rede_de_farm_cias_e_ades_o_7"."information_schema"."schemata"	table	5	0	\N	{}	\N	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
61	21	7	table_privileges	"rfa___rede_de_farm_cias_e_ades_o_7"."information_schema"."table_privileges"	table	0	0	\N	{}	\N	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
62	21	7	tables	"rfa___rede_de_farm_cias_e_ades_o_7"."information_schema"."tables"	table	15	0	\N	{}	\N	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
63	21	7	views	"rfa___rede_de_farm_cias_e_ades_o_7"."information_schema"."views"	table	0	0	\N	{}	\N	2026-06-03 02:33:33.462154	2026-06-03 02:33:33.462154	\N	\N	t
64	23	6	contraste_administrado	"cdi___centro_de_diagn_stico_por_imagem_6"."dosimetria"."contraste_administrado"	table	6000003	0	\N	{}	\N	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
65	23	6	dose_radiacao	"cdi___centro_de_diagn_stico_por_imagem_6"."dosimetria"."dose_radiacao"	table	12000003	0	\N	{}	\N	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
66	24	6	equipamento	"cdi___centro_de_diagn_stico_por_imagem_6"."exames"."equipamento"	table	43	0	\N	{}	\N	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
67	24	6	laudo_radiologico	"cdi___centro_de_diagn_stico_por_imagem_6"."exames"."laudo_radiologico"	table	16000004	0	\N	{}	\N	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
68	24	6	ordem_exame	"cdi___centro_de_diagn_stico_por_imagem_6"."exames"."ordem_exame"	table	20000004	0	\N	{}	\N	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
69	25	6	applicable_roles	"cdi___centro_de_diagn_stico_por_imagem_6"."information_schema"."applicable_roles"	table	0	0	\N	{}	\N	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
70	25	6	columns	"cdi___centro_de_diagn_stico_por_imagem_6"."information_schema"."columns"	table	95	0	\N	{}	\N	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
71	25	6	enabled_roles	"cdi___centro_de_diagn_stico_por_imagem_6"."information_schema"."enabled_roles"	table	0	0	\N	{}	\N	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
72	25	6	roles	"cdi___centro_de_diagn_stico_por_imagem_6"."information_schema"."roles"	table	0	0	\N	{}	\N	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
73	25	6	schemata	"cdi___centro_de_diagn_stico_por_imagem_6"."information_schema"."schemata"	table	6	0	\N	{}	\N	2026-06-03 02:33:40.712157	2026-06-03 02:33:40.712157	\N	\N	t
74	25	6	table_privileges	"cdi___centro_de_diagn_stico_por_imagem_6"."information_schema"."table_privileges"	table	0	0	\N	{}	\N	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
75	25	6	tables	"cdi___centro_de_diagn_stico_por_imagem_6"."information_schema"."tables"	table	15	0	\N	{}	\N	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
76	25	6	views	"cdi___centro_de_diagn_stico_por_imagem_6"."information_schema"."views"	table	0	0	\N	{}	\N	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
77	26	6	cadastro_paciente	"cdi___centro_de_diagn_stico_por_imagem_6"."pacientes"."cadastro_paciente"	table	20000005	0	\N	{}	\N	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
78	26	6	convenio_vinculo	"cdi___centro_de_diagn_stico_por_imagem_6"."pacientes"."convenio_vinculo"	table	14000003	0	\N	{}	\N	2026-06-03 02:33:40.786894	2026-06-03 02:33:40.786894	\N	\N	t
79	29	8	applicable_roles	"dermexp3_ham10000_collection_212_8"."information_schema"."applicable_roles"	table	0	0	\N	{}	\N	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
80	29	8	columns	"dermexp3_ham10000_collection_212_8"."information_schema"."columns"	table	55	0	\N	{}	\N	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
81	29	8	enabled_roles	"dermexp3_ham10000_collection_212_8"."information_schema"."enabled_roles"	table	0	0	\N	{}	\N	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
82	29	8	roles	"dermexp3_ham10000_collection_212_8"."information_schema"."roles"	table	0	0	\N	{}	\N	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
83	29	8	schemata	"dermexp3_ham10000_collection_212_8"."information_schema"."schemata"	table	4	0	\N	{}	\N	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
84	29	8	table_privileges	"dermexp3_ham10000_collection_212_8"."information_schema"."table_privileges"	table	0	0	\N	{}	\N	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
85	29	8	tables	"dermexp3_ham10000_collection_212_8"."information_schema"."tables"	table	9	0	\N	{}	\N	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
86	29	8	views	"dermexp3_ham10000_collection_212_8"."information_schema"."views"	table	0	0	\N	{}	\N	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
87	30	8	ham10000_metadata	"dermexp3_ham10000_collection_212_8"."isic"."ham10000_metadata"	table	11720	0	\N	{}	\N	2026-07-13 22:18:36.458573	2026-07-13 22:18:36.458573	\N	\N	t
88	33	9	applicable_roles	"dermexp3_hiba_collection_251_9"."information_schema"."applicable_roles"	table	0	0	\N	{}	\N	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
89	33	9	columns	"dermexp3_hiba_collection_251_9"."information_schema"."columns"	table	57	0	\N	{}	\N	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
90	33	9	enabled_roles	"dermexp3_hiba_collection_251_9"."information_schema"."enabled_roles"	table	0	0	\N	{}	\N	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
91	33	9	roles	"dermexp3_hiba_collection_251_9"."information_schema"."roles"	table	0	0	\N	{}	\N	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
92	33	9	schemata	"dermexp3_hiba_collection_251_9"."information_schema"."schemata"	table	4	0	\N	{}	\N	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
93	33	9	table_privileges	"dermexp3_hiba_collection_251_9"."information_schema"."table_privileges"	table	0	0	\N	{}	\N	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
94	33	9	tables	"dermexp3_hiba_collection_251_9"."information_schema"."tables"	table	9	0	\N	{}	\N	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
95	33	9	views	"dermexp3_hiba_collection_251_9"."information_schema"."views"	table	0	0	\N	{}	\N	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
96	34	9	hiba_metadata	"dermexp3_hiba_collection_251_9"."isic"."hiba_metadata"	table	1616	0	\N	{}	\N	2026-07-13 22:18:38.156624	2026-07-13 22:18:38.156624	\N	\N	t
97	37	10	applicable_roles	"dermexp3_pad_ufes_20_collection_406_10"."information_schema"."applicable_roles"	table	0	0	\N	{}	\N	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
98	37	10	columns	"dermexp3_pad_ufes_20_collection_406_10"."information_schema"."columns"	table	57	0	\N	{}	\N	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
99	37	10	enabled_roles	"dermexp3_pad_ufes_20_collection_406_10"."information_schema"."enabled_roles"	table	0	0	\N	{}	\N	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
100	37	10	roles	"dermexp3_pad_ufes_20_collection_406_10"."information_schema"."roles"	table	0	0	\N	{}	\N	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
101	37	10	schemata	"dermexp3_pad_ufes_20_collection_406_10"."information_schema"."schemata"	table	3	0	\N	{}	\N	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
102	37	10	table_privileges	"dermexp3_pad_ufes_20_collection_406_10"."information_schema"."table_privileges"	table	0	0	\N	{}	\N	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
103	37	10	tables	"dermexp3_pad_ufes_20_collection_406_10"."information_schema"."tables"	table	9	0	\N	{}	\N	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
104	37	10	views	"dermexp3_pad_ufes_20_collection_406_10"."information_schema"."views"	table	0	0	\N	{}	\N	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
105	38	10	pad_ufes_20_metadata	"dermexp3_pad_ufes_20_collection_406_10"."isic"."pad_ufes_20_metadata"	table	2298	0	\N	{}	\N	2026-07-13 22:18:41.297618	2026-07-13 22:18:41.297618	\N	\N	t
106	40	11	applicable_roles	"dermexp3_v2_ham10000_collection_212_11"."information_schema"."applicable_roles"	table	0	0	\N	{}	\N	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
107	40	11	columns	"dermexp3_v2_ham10000_collection_212_11"."information_schema"."columns"	table	55	0	\N	{}	\N	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
108	40	11	enabled_roles	"dermexp3_v2_ham10000_collection_212_11"."information_schema"."enabled_roles"	table	0	0	\N	{}	\N	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
109	40	11	roles	"dermexp3_v2_ham10000_collection_212_11"."information_schema"."roles"	table	0	0	\N	{}	\N	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
110	40	11	schemata	"dermexp3_v2_ham10000_collection_212_11"."information_schema"."schemata"	table	4	0	\N	{}	\N	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
111	40	11	table_privileges	"dermexp3_v2_ham10000_collection_212_11"."information_schema"."table_privileges"	table	0	0	\N	{}	\N	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
112	40	11	tables	"dermexp3_v2_ham10000_collection_212_11"."information_schema"."tables"	table	9	0	\N	{}	\N	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
113	40	11	views	"dermexp3_v2_ham10000_collection_212_11"."information_schema"."views"	table	0	0	\N	{}	\N	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
114	41	11	metadata	"dermexp3_v2_ham10000_collection_212_11"."isic"."metadata"	table	11720	0	\N	{}	\N	2026-07-13 22:21:53.234331	2026-07-13 22:21:53.234331	\N	\N	t
115	44	12	applicable_roles	"dermexp3_v2_hiba_collection_251_12"."information_schema"."applicable_roles"	table	0	0	\N	{}	\N	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
116	44	12	columns	"dermexp3_v2_hiba_collection_251_12"."information_schema"."columns"	table	57	0	\N	{}	\N	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
117	44	12	enabled_roles	"dermexp3_v2_hiba_collection_251_12"."information_schema"."enabled_roles"	table	0	0	\N	{}	\N	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
118	44	12	roles	"dermexp3_v2_hiba_collection_251_12"."information_schema"."roles"	table	0	0	\N	{}	\N	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
119	44	12	schemata	"dermexp3_v2_hiba_collection_251_12"."information_schema"."schemata"	table	4	0	\N	{}	\N	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
120	44	12	table_privileges	"dermexp3_v2_hiba_collection_251_12"."information_schema"."table_privileges"	table	0	0	\N	{}	\N	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
121	44	12	tables	"dermexp3_v2_hiba_collection_251_12"."information_schema"."tables"	table	9	0	\N	{}	\N	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
122	44	12	views	"dermexp3_v2_hiba_collection_251_12"."information_schema"."views"	table	0	0	\N	{}	\N	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
123	45	12	metadata	"dermexp3_v2_hiba_collection_251_12"."isic"."metadata"	table	1616	0	\N	{}	\N	2026-07-13 22:21:54.500232	2026-07-13 22:21:54.500232	\N	\N	t
124	48	13	applicable_roles	"dermexp3_v2_pad_ufes_20_collection_406_13"."information_schema"."applicable_roles"	table	0	0	\N	{}	\N	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
125	48	13	columns	"dermexp3_v2_pad_ufes_20_collection_406_13"."information_schema"."columns"	table	57	0	\N	{}	\N	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
126	48	13	enabled_roles	"dermexp3_v2_pad_ufes_20_collection_406_13"."information_schema"."enabled_roles"	table	0	0	\N	{}	\N	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
127	48	13	roles	"dermexp3_v2_pad_ufes_20_collection_406_13"."information_schema"."roles"	table	0	0	\N	{}	\N	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
128	48	13	schemata	"dermexp3_v2_pad_ufes_20_collection_406_13"."information_schema"."schemata"	table	3	0	\N	{}	\N	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
129	48	13	table_privileges	"dermexp3_v2_pad_ufes_20_collection_406_13"."information_schema"."table_privileges"	table	0	0	\N	{}	\N	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
130	48	13	tables	"dermexp3_v2_pad_ufes_20_collection_406_13"."information_schema"."tables"	table	9	0	\N	{}	\N	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
131	48	13	views	"dermexp3_v2_pad_ufes_20_collection_406_13"."information_schema"."views"	table	0	0	\N	{}	\N	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
132	49	13	metadata	"dermexp3_v2_pad_ufes_20_collection_406_13"."isic"."metadata"	table	2298	0	\N	{}	\N	2026-07-13 22:21:55.634215	2026-07-13 22:21:55.634215	\N	\N	t
\.


--
-- Data for Name: federation_connections; Type: TABLE DATA; Schema: metadata; Owner: -
--

COPY metadata.federation_connections (id, federation_id, connection_id) FROM stdin;
9	6	5
10	6	6
11	6	7
\.


--
-- Data for Name: federation_tables; Type: TABLE DATA; Schema: metadata; Owner: -
--

COPY metadata.federation_tables (id, federation_id, table_id) FROM stdin;
3	4	31
4	4	5
7	6	48
8	6	77
9	6	51
\.


--
-- Data for Name: federations; Type: TABLE DATA; Schema: metadata; Owner: -
--

COPY metadata.federations (id, name, description, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
4	Hospital Federation — IDA + CMPD (CPF Link)	Federated view linking IDA (MySQL) and CMPD (PostgreSQL) through the patient CPF identifier. Scope restricted to the two bridge tables: triagem.ficha_dermato (IDA) and cadastro_beneficiario.perfil_saude (CMPD).	2026-05-24 01:04:02.995418	2026-05-24 01:04:02.995418	\N	\N	t
6	Rede Federada (REH-CDI-RFA)	Cadeia de federação por CPF: REH (emergência) ↔ CDI (imagem/hub) ↔ RFA (farmácia). REH e RFA não compartilham CPF diretamente.	2026-06-03 02:39:33.675177	2026-06-03 02:39:33.675177	\N	\N	t
\.


--
-- Data for Name: relationship_suggestions; Type: TABLE DATA; Schema: metadata; Owner: -
--

COPY metadata.relationship_suggestions (id, left_table_id, left_column_id, right_table_id, right_column_id, suggestion_reason, confidence_score, status, details, generated_at, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
4	31	194	29	188	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "fk_agenda_ficha", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:54:41.481213+00	2026-05-24 00:54:41.481213	2026-05-24 00:54:45.328049	\N	\N	t
5	31	194	32	214	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "fk_lesao_ficha", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:54:41.481213+00	2026-05-24 00:54:41.481213	2026-05-24 00:54:47.074147	\N	\N	t
6	5	35	1	2	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "antecedentes_clinicos_beneficiario_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:06.425755+00	2026-05-24 00:55:06.425755	2026-05-24 00:55:08.863632	\N	\N	t
11	5	35	3	17	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "indicadores_vitais_beneficiario_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:06.425755+00	2026-05-24 00:55:06.425755	2026-05-24 00:55:10.315074	\N	\N	t
7	5	35	24	141	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "requisicao_exame_beneficiario_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:06.425755+00	2026-05-24 00:55:06.425755	2026-05-24 00:55:36.331493	\N	\N	t
8	28	180	24	145	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "requisicao_exame_inscricao_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:06.425755+00	2026-05-24 00:55:06.425755	2026-05-24 00:55:37.525788	\N	\N	t
9	24	140	26	158	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "resultado_exame_requisicao_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:06.425755+00	2026-05-24 00:55:06.425755	2026-05-24 00:55:40.999477	\N	\N	t
10	30	204	28	182	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "inscricao_programa_programa_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:06.425755+00	2026-05-24 00:55:06.425755	2026-05-24 00:55:49.054302	\N	\N	t
12	24	140	22	128	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "achado_imagem_requisicao_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:06.425755+00	2026-05-24 00:55:06.425755	2026-05-24 00:55:51.088144	\N	\N	t
13	5	35	28	181	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "inscricao_programa_beneficiario_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:06.425755+00	2026-05-24 00:55:06.425755	2026-05-24 00:55:52.43372	\N	\N	t
14	46	296	41	258	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "admissao_hospitalar_atendimento_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:37.538329+00	2026-06-11 01:56:37.538329	2026-06-11 01:56:39.784969	\N	\N	t
15	42	265	41	259	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "admissao_hospitalar_leito_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:37.538329+00	2026-06-11 01:56:37.538329	2026-06-11 01:56:40.733961	\N	\N	t
16	41	257	43	271	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "procedimento_realizado_admissao_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:37.538329+00	2026-06-11 01:56:37.538329	2026-06-11 01:56:41.386184	\N	\N	t
17	41	257	44	278	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "prescricao_urgencia_admissao_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:37.538329+00	2026-06-11 01:56:37.538329	2026-06-11 01:56:42.204342	\N	\N	t
1	6	51	4	30	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "fk_marcador_laudo", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:54:41.481213+00	2026-05-24 00:54:41.481213	2026-06-11 01:59:04.150341	\N	\N	t
2	2	9	6	52	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "fk_laudo_solic", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:54:41.481213+00	2026-05-24 00:54:41.481213	2026-06-11 01:59:05.307079	\N	\N	t
3	27	169	25	149	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "fk_evolucao_protocolo", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:54:41.481213+00	2026-05-24 00:54:41.481213	2026-06-11 01:59:06.528946	\N	\N	t
18	41	257	45	286	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "sinal_vital_serie_admissao_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:37.538329+00	2026-06-11 01:56:37.538329	2026-06-11 01:56:42.971717	\N	\N	t
19	48	316	46	297	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "atendimento_emergencia_paciente_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:37.538329+00	2026-06-11 01:56:37.538329	2026-06-11 01:56:43.775643	\N	\N	t
20	46	296	47	309	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "classificacao_manchester_atendimento_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:37.538329+00	2026-06-11 01:56:37.538329	2026-06-11 01:56:44.668185	\N	\N	t
22	53	360	52	351	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "fk_item_receita", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:52.606559+00	2026-06-11 01:56:52.606559	2026-06-11 01:56:57.84511	\N	\N	t
23	51	340	53	361	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "fk_receita_cliente", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:52.606559+00	2026-06-11 01:56:52.606559	2026-06-11 01:56:58.835934	\N	\N	t
24	68	449	64	419	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "contraste_administrado_ordem_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:57:27.011931+00	2026-06-11 01:57:27.011931	2026-06-11 01:57:28.914451	\N	\N	t
25	68	449	65	426	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "dose_radiacao_ordem_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:57:27.011931+00	2026-06-11 01:57:27.011931	2026-06-11 01:57:29.58254	\N	\N	t
26	68	449	67	441	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "laudo_radiologico_ordem_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:57:27.011931+00	2026-06-11 01:57:27.011931	2026-06-11 01:57:30.245123	\N	\N	t
28	77	494	68	450	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "ordem_exame_paciente_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:57:27.011931+00	2026-06-11 01:57:27.011931	2026-06-11 01:57:30.926983	\N	\N	t
27	66	433	68	451	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "ordem_exame_equip_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:57:27.011931+00	2026-06-11 01:57:27.011931	2026-06-11 01:57:31.687023	\N	\N	t
29	77	494	78	507	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "convenio_vinculo_paciente_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:57:27.011931+00	2026-06-11 01:57:27.011931	2026-06-11 01:57:33.49236	\N	\N	t
21	50	334	49	328	foreign_key_constraint	1	accepted	{"reason": "foreign_key_constraint", "constraint_name": "fk_acomp_programa", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:52.606559+00	2026-06-11 01:56:52.606559	2026-06-11 01:57:44.115139	\N	\N	t
\.


--
-- Data for Name: semantic_column_links; Type: TABLE DATA; Schema: metadata; Owner: -
--

COPY metadata.semantic_column_links (id, column_id, linked_column_id, semantic_type, source, confidence_score, is_verified, is_active, notes, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
\.


--
-- Data for Name: table_relationships; Type: TABLE DATA; Schema: metadata; Owner: -
--

COPY metadata.table_relationships (id, left_table_id, left_column_id, right_table_id, right_column_id, name, description, scope, source, cardinality, default_join_type, confidence_score, is_verified, is_active, properties, discovery_details, data_criacao, data_atualizacao, id_usuario_criacao, id_usuario_atualizacao, fl_ativo) FROM stdin;
1	31	194	29	188	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "fk_agenda_ficha", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:54:45.315042	2026-05-24 00:54:45.315042	\N	\N	t
2	31	194	32	214	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "fk_lesao_ficha", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:54:47.064105	2026-05-24 00:54:47.064105	\N	\N	t
3	5	35	1	2	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "antecedentes_clinicos_beneficiario_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:08.854901	2026-05-24 00:55:08.854901	\N	\N	t
4	5	35	3	17	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "indicadores_vitais_beneficiario_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:10.310068	2026-05-24 00:55:10.310068	\N	\N	t
5	5	35	24	141	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "requisicao_exame_beneficiario_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:36.326705	2026-05-24 00:55:36.326705	\N	\N	t
6	28	180	24	145	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "requisicao_exame_inscricao_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:37.517344	2026-05-24 00:55:37.517344	\N	\N	t
7	24	140	26	158	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "resultado_exame_requisicao_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:40.977599	2026-05-24 00:55:40.977599	\N	\N	t
8	30	204	28	182	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "inscricao_programa_programa_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:49.045746	2026-05-24 00:55:49.045746	\N	\N	t
9	24	140	22	128	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "achado_imagem_requisicao_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:51.07808	2026-05-24 00:55:51.07808	\N	\N	t
10	5	35	28	181	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "inscricao_programa_beneficiario_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-05-24 00:55:52.430687	2026-05-24 00:55:52.430687	\N	\N	t
11	31	195	5	36	cpf_federado_ida_cmpd	Elo de federação via CPF do paciente/beneficiário. Permite JOIN entre ficha_dermato (IDA MySQL) e perfil_saude (CMPD PostgreSQL) para consultas clínicas cross-hospital.	INTER_CONNECTION	MANUAL	ONE_TO_ONE	FULL	\N	t	t	{"semantic_type": "cpf_paciente", "federation_key": true, "cross_database": true, "left_connection": "IDA - Instituto de Dermatologia Avan\\u00e7ada", "right_connection": "CMPD - Centro de Medicina Preventiva e Diagn\\u00f3stico"}	\N	2026-05-24 00:58:20.451218	2026-05-24 02:52:19.267087	\N	\N	t
12	48	317	77	495	REH↔CDI por CPF	Mesma pessoa: cpf_paciente (REH) = cpf_pessoa (CDI)	INTER_CONNECTION	MANUAL	ONE_TO_ONE	INNER	\N	t	t	{}	\N	2026-06-03 02:41:16.898321	2026-06-03 02:41:16.898321	\N	\N	t
13	77	495	51	341	CDI↔RFA por CPF	Mesma pessoa: cpf_pessoa (CDI) = cpf_cliente (RFA)	INTER_CONNECTION	MANUAL	ONE_TO_ONE	INNER	\N	t	t	{}	\N	2026-06-03 02:41:16.932865	2026-06-03 02:41:16.932865	\N	\N	t
14	46	296	41	258	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "admissao_hospitalar_atendimento_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:39.779663	2026-06-11 01:56:39.779663	\N	\N	t
15	42	265	41	259	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "admissao_hospitalar_leito_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:40.727495	2026-06-11 01:56:40.727495	\N	\N	t
16	41	257	43	271	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "procedimento_realizado_admissao_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:41.379425	2026-06-11 01:56:41.379425	\N	\N	t
17	41	257	44	278	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "prescricao_urgencia_admissao_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:42.198121	2026-06-11 01:56:42.198121	\N	\N	t
18	41	257	45	286	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "sinal_vital_serie_admissao_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:42.961934	2026-06-11 01:56:42.961934	\N	\N	t
19	48	316	46	297	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "atendimento_emergencia_paciente_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:43.769025	2026-06-11 01:56:43.769025	\N	\N	t
20	46	296	47	309	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "classificacao_manchester_atendimento_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:44.659849	2026-06-11 01:56:44.659849	\N	\N	t
21	53	360	52	351	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "fk_item_receita", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:57.839415	2026-06-11 01:56:57.839415	\N	\N	t
22	51	340	53	361	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "fk_receita_cliente", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:56:58.828504	2026-06-11 01:56:58.828504	\N	\N	t
23	68	449	64	419	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "contraste_administrado_ordem_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:57:28.9046	2026-06-11 01:57:28.9046	\N	\N	t
24	68	449	65	426	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "dose_radiacao_ordem_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:57:29.576591	2026-06-11 01:57:29.576591	\N	\N	t
25	68	449	67	441	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "laudo_radiologico_ordem_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:57:30.239418	2026-06-11 01:57:30.239418	\N	\N	t
26	77	494	68	450	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "ordem_exame_paciente_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:57:30.919851	2026-06-11 01:57:30.919851	\N	\N	t
27	66	433	68	451	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "ordem_exame_equip_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:57:31.674826	2026-06-11 01:57:31.674826	\N	\N	t
28	77	494	78	507	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "convenio_vinculo_paciente_id_fkey", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:57:33.485571	2026-06-11 01:57:33.485571	\N	\N	t
29	50	334	49	328	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "fk_acomp_programa", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:57:44.108356	2026-06-11 01:57:44.108356	\N	\N	t
30	6	51	4	30	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "fk_marcador_laudo", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:59:04.141013	2026-06-11 01:59:04.141013	\N	\N	t
31	2	9	6	52	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "fk_laudo_solic", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:59:05.299691	2026-06-11 01:59:05.299691	\N	\N	t
32	27	169	25	149	\N	\N	INTRA_CONNECTION	AUTO_FK	ONE_TO_MANY	FULL	1	t	t	{}	{"reason": "foreign_key_constraint", "constraint_name": "fk_evolucao_protocolo", "source": "database_metadata", "cardinality": "one_to_many"}	2026-06-11 01:59:06.522145	2026-06-11 01:59:06.522145	\N	\N	t
33	51	340	54	369	cliente_farmacia→evento_adverso	cliente_id (cross-database dentro do RFA: dispensacao→evento_adverso)	INTRA_CONNECTION	MANUAL	ONE_TO_MANY	FULL	\N	t	t	{}	\N	2026-06-11 02:08:06.493455	2026-06-11 02:08:06.493455	\N	\N	t
34	51	340	55	377	cliente_farmacia→interacao_medicamentosa	cliente_id (cross-database dentro do RFA: dispensacao→interacao_medicamentosa)	INTRA_CONNECTION	MANUAL	ONE_TO_MANY	FULL	\N	t	t	{}	\N	2026-06-11 02:08:06.535669	2026-06-11 02:08:06.535669	\N	\N	t
35	51	340	49	327	cliente_farmacia→acompanhamento_adesao	cliente_id (cross-database dentro do RFA: dispensacao→acompanhamento_adesao)	INTRA_CONNECTION	MANUAL	ONE_TO_MANY	FULL	\N	t	t	{}	\N	2026-06-11 02:08:06.560142	2026-06-11 02:08:06.560142	\N	\N	t
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
20260218_0009
\.


--
-- Data for Name: dataset_storage; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.dataset_storage (id, dataset_id, storage_type, storage_location, file_format, compression, partition_columns, storage_properties) FROM stdin;
\.


--
-- Data for Name: dataset_jobs; Type: TABLE DATA; Schema: workflow; Owner: -
--

COPY workflow.dataset_jobs (id, dataset_id, job_type, airflow_dag_id, status, last_run_start, last_run_end, last_run_duration_seconds, row_count, size_bytes, error_message, job_params) FROM stdin;
\.


--
-- Data for Name: metadata_sync_jobs; Type: TABLE DATA; Schema: workflow; Owner: -
--

COPY workflow.metadata_sync_jobs (id, connection_id, name, airflow_dag_id, job_type, status, last_run_at, last_run_duration_seconds, error_message, job_params, job_results) FROM stdin;
\.


--
-- Data for Name: sync_execution_history; Type: TABLE DATA; Schema: workflow; Owner: -
--

COPY workflow.sync_execution_history (id, job_id, connection_id, execution_start, execution_end, status, catalog_count, schemas_count, table_count, column_count, new_objects_count, updated_objects_count, deleted_objects_count, error_log, execution_details) FROM stdin;
\.


--
-- Name: connection_types_id_seq; Type: SEQUENCE SET; Schema: core; Owner: -
--

SELECT pg_catalog.setval('core.connection_types_id_seq', 6, true);


--
-- Name: data_connections_id_seq; Type: SEQUENCE SET; Schema: core; Owner: -
--

SELECT pg_catalog.setval('core.data_connections_id_seq', 13, true);


--
-- Name: dataset_column_sources_id_seq; Type: SEQUENCE SET; Schema: core; Owner: -
--

SELECT pg_catalog.setval('core.dataset_column_sources_id_seq', 1, false);


--
-- Name: dataset_columns_id_seq; Type: SEQUENCE SET; Schema: core; Owner: -
--

SELECT pg_catalog.setval('core.dataset_columns_id_seq', 1, false);


--
-- Name: dataset_sources_id_seq; Type: SEQUENCE SET; Schema: core; Owner: -
--

SELECT pg_catalog.setval('core.dataset_sources_id_seq', 1, false);


--
-- Name: dataset_versions_id_seq; Type: SEQUENCE SET; Schema: core; Owner: -
--

SELECT pg_catalog.setval('core.dataset_versions_id_seq', 1, false);


--
-- Name: datasets_id_seq; Type: SEQUENCE SET; Schema: core; Owner: -
--

SELECT pg_catalog.setval('core.datasets_id_seq', 5, true);


--
-- Name: group_dataset_permissions_id_seq; Type: SEQUENCE SET; Schema: core; Owner: -
--

SELECT pg_catalog.setval('core.group_dataset_permissions_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: core; Owner: -
--

SELECT pg_catalog.setval('core.groups_id_seq', 1, false);


--
-- Name: organizacoes_id_seq; Type: SEQUENCE SET; Schema: core; Owner: -
--

SELECT pg_catalog.setval('core.organizacoes_id_seq', 1, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: core; Owner: -
--

SELECT pg_catalog.setval('core.roles_id_seq', 1, false);


--
-- Name: user_dataset_permissions_id_seq; Type: SEQUENCE SET; Schema: core; Owner: -
--

SELECT pg_catalog.setval('core.user_dataset_permissions_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: core; Owner: -
--

SELECT pg_catalog.setval('core.users_id_seq', 1, false);


--
-- Name: bronze_column_mappings_id_seq; Type: SEQUENCE SET; Schema: datasets; Owner: -
--

SELECT pg_catalog.setval('datasets.bronze_column_mappings_id_seq', 1, false);


--
-- Name: bronze_executions_id_seq; Type: SEQUENCE SET; Schema: datasets; Owner: -
--

SELECT pg_catalog.setval('datasets.bronze_executions_id_seq', 14, true);


--
-- Name: bronze_persistent_configs_id_seq; Type: SEQUENCE SET; Schema: datasets; Owner: -
--

SELECT pg_catalog.setval('datasets.bronze_persistent_configs_id_seq', 14, true);


--
-- Name: bronze_virtualized_configs_id_seq; Type: SEQUENCE SET; Schema: datasets; Owner: -
--

SELECT pg_catalog.setval('datasets.bronze_virtualized_configs_id_seq', 1, true);


--
-- Name: dataset_bronze_configs_id_seq; Type: SEQUENCE SET; Schema: datasets; Owner: -
--

SELECT pg_catalog.setval('datasets.dataset_bronze_configs_id_seq', 1, false);


--
-- Name: dataset_ingestion_groups_id_seq; Type: SEQUENCE SET; Schema: datasets; Owner: -
--

SELECT pg_catalog.setval('datasets.dataset_ingestion_groups_id_seq', 1, false);


--
-- Name: ingestion_group_tables_id_seq; Type: SEQUENCE SET; Schema: datasets; Owner: -
--

SELECT pg_catalog.setval('datasets.ingestion_group_tables_id_seq', 1, false);


--
-- Name: inter_source_links_id_seq; Type: SEQUENCE SET; Schema: datasets; Owner: -
--

SELECT pg_catalog.setval('datasets.inter_source_links_id_seq', 1, false);


--
-- Name: silver_executions_id_seq; Type: SEQUENCE SET; Schema: datasets; Owner: -
--

SELECT pg_catalog.setval('datasets.silver_executions_id_seq', 24, true);


--
-- Name: silver_normalization_rules_id_seq; Type: SEQUENCE SET; Schema: datasets; Owner: -
--

SELECT pg_catalog.setval('datasets.silver_normalization_rules_id_seq', 2, true);


--
-- Name: silver_persistent_configs_id_seq; Type: SEQUENCE SET; Schema: datasets; Owner: -
--

SELECT pg_catalog.setval('datasets.silver_persistent_configs_id_seq', 7, true);


--
-- Name: silver_virtualized_configs_id_seq; Type: SEQUENCE SET; Schema: datasets; Owner: -
--

SELECT pg_catalog.setval('datasets.silver_virtualized_configs_id_seq', 1, false);


--
-- Name: source_relationships_id_seq; Type: SEQUENCE SET; Schema: datasets; Owner: -
--

SELECT pg_catalog.setval('datasets.source_relationships_id_seq', 1, false);


--
-- Name: recipient_access_logs_id_seq; Type: SEQUENCE SET; Schema: delta_sharing; Owner: -
--

SELECT pg_catalog.setval('delta_sharing.recipient_access_logs_id_seq', 23, true);


--
-- Name: recipients_id_seq; Type: SEQUENCE SET; Schema: delta_sharing; Owner: -
--

SELECT pg_catalog.setval('delta_sharing.recipients_id_seq', 5, true);


--
-- Name: share_schemas_id_seq; Type: SEQUENCE SET; Schema: delta_sharing; Owner: -
--

SELECT pg_catalog.setval('delta_sharing.share_schemas_id_seq', 4, true);


--
-- Name: share_table_files_id_seq; Type: SEQUENCE SET; Schema: delta_sharing; Owner: -
--

SELECT pg_catalog.setval('delta_sharing.share_table_files_id_seq', 1, false);


--
-- Name: share_table_versions_id_seq; Type: SEQUENCE SET; Schema: delta_sharing; Owner: -
--

SELECT pg_catalog.setval('delta_sharing.share_table_versions_id_seq', 1, false);


--
-- Name: share_tables_id_seq; Type: SEQUENCE SET; Schema: delta_sharing; Owner: -
--

SELECT pg_catalog.setval('delta_sharing.share_tables_id_seq', 6, true);


--
-- Name: shares_id_seq; Type: SEQUENCE SET; Schema: delta_sharing; Owner: -
--

SELECT pg_catalog.setval('delta_sharing.shares_id_seq', 4, true);


--
-- Name: column_groups_id_seq; Type: SEQUENCE SET; Schema: equivalence; Owner: -
--

SELECT pg_catalog.setval('equivalence.column_groups_id_seq', 17, true);


--
-- Name: column_mappings_id_seq; Type: SEQUENCE SET; Schema: equivalence; Owner: -
--

SELECT pg_catalog.setval('equivalence.column_mappings_id_seq', 62, true);


--
-- Name: data_dictionary_id_seq; Type: SEQUENCE SET; Schema: equivalence; Owner: -
--

SELECT pg_catalog.setval('equivalence.data_dictionary_id_seq', 16, true);


--
-- Name: semantic_domains_id_seq; Type: SEQUENCE SET; Schema: equivalence; Owner: -
--

SELECT pg_catalog.setval('equivalence.semantic_domains_id_seq', 6, true);


--
-- Name: value_mappings_id_seq; Type: SEQUENCE SET; Schema: equivalence; Owner: -
--

SELECT pg_catalog.setval('equivalence.value_mappings_id_seq', 180, true);


--
-- Name: column_tags_id_seq; Type: SEQUENCE SET; Schema: metadata; Owner: -
--

SELECT pg_catalog.setval('metadata.column_tags_id_seq', 1, false);


--
-- Name: external_catalogs_id_seq; Type: SEQUENCE SET; Schema: metadata; Owner: -
--

SELECT pg_catalog.setval('metadata.external_catalogs_id_seq', 11, true);


--
-- Name: external_columns_id_seq; Type: SEQUENCE SET; Schema: metadata; Owner: -
--

SELECT pg_catalog.setval('metadata.external_columns_id_seq', 850, true);


--
-- Name: external_schemas_id_seq; Type: SEQUENCE SET; Schema: metadata; Owner: -
--

SELECT pg_catalog.setval('metadata.external_schemas_id_seq', 50, true);


--
-- Name: external_tables_id_seq; Type: SEQUENCE SET; Schema: metadata; Owner: -
--

SELECT pg_catalog.setval('metadata.external_tables_id_seq', 132, true);


--
-- Name: federation_connections_id_seq; Type: SEQUENCE SET; Schema: metadata; Owner: -
--

SELECT pg_catalog.setval('metadata.federation_connections_id_seq', 11, true);


--
-- Name: federation_tables_id_seq; Type: SEQUENCE SET; Schema: metadata; Owner: -
--

SELECT pg_catalog.setval('metadata.federation_tables_id_seq', 9, true);


--
-- Name: federations_id_seq; Type: SEQUENCE SET; Schema: metadata; Owner: -
--

SELECT pg_catalog.setval('metadata.federations_id_seq', 6, true);


--
-- Name: relationship_suggestions_id_seq; Type: SEQUENCE SET; Schema: metadata; Owner: -
--

SELECT pg_catalog.setval('metadata.relationship_suggestions_id_seq', 29, true);


--
-- Name: semantic_column_links_id_seq; Type: SEQUENCE SET; Schema: metadata; Owner: -
--

SELECT pg_catalog.setval('metadata.semantic_column_links_id_seq', 1, false);


--
-- Name: table_relationships_id_seq; Type: SEQUENCE SET; Schema: metadata; Owner: -
--

SELECT pg_catalog.setval('metadata.table_relationships_id_seq', 35, true);


--
-- Name: dataset_storage_id_seq; Type: SEQUENCE SET; Schema: storage; Owner: -
--

SELECT pg_catalog.setval('storage.dataset_storage_id_seq', 1, false);


--
-- Name: dataset_jobs_id_seq; Type: SEQUENCE SET; Schema: workflow; Owner: -
--

SELECT pg_catalog.setval('workflow.dataset_jobs_id_seq', 1, false);


--
-- Name: metadata_sync_jobs_id_seq; Type: SEQUENCE SET; Schema: workflow; Owner: -
--

SELECT pg_catalog.setval('workflow.metadata_sync_jobs_id_seq', 1, false);


--
-- Name: sync_execution_history_id_seq; Type: SEQUENCE SET; Schema: workflow; Owner: -
--

SELECT pg_catalog.setval('workflow.sync_execution_history_id_seq', 1, false);


--
-- Name: connection_types connection_types_name_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.connection_types
    ADD CONSTRAINT connection_types_name_key UNIQUE (name);


--
-- Name: connection_types connection_types_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.connection_types
    ADD CONSTRAINT connection_types_pkey PRIMARY KEY (id);


--
-- Name: data_connections data_connections_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.data_connections
    ADD CONSTRAINT data_connections_pkey PRIMARY KEY (id);


--
-- Name: dataset_column_sources dataset_column_sources_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_column_sources
    ADD CONSTRAINT dataset_column_sources_pkey PRIMARY KEY (id);


--
-- Name: dataset_columns dataset_columns_dataset_id_name_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_columns
    ADD CONSTRAINT dataset_columns_dataset_id_name_key UNIQUE (dataset_id, name);


--
-- Name: dataset_columns dataset_columns_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_columns
    ADD CONSTRAINT dataset_columns_pkey PRIMARY KEY (id);


--
-- Name: dataset_sources dataset_sources_dataset_id_table_id_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_sources
    ADD CONSTRAINT dataset_sources_dataset_id_table_id_key UNIQUE (dataset_id, table_id);


--
-- Name: dataset_sources dataset_sources_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_sources
    ADD CONSTRAINT dataset_sources_pkey PRIMARY KEY (id);


--
-- Name: dataset_versions dataset_versions_dataset_id_version_number_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_versions
    ADD CONSTRAINT dataset_versions_dataset_id_version_number_key UNIQUE (dataset_id, version_number);


--
-- Name: dataset_versions dataset_versions_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_versions
    ADD CONSTRAINT dataset_versions_pkey PRIMARY KEY (id);


--
-- Name: datasets datasets_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.datasets
    ADD CONSTRAINT datasets_pkey PRIMARY KEY (id);


--
-- Name: group_dataset_permissions group_dataset_permissions_group_id_dataset_id_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.group_dataset_permissions
    ADD CONSTRAINT group_dataset_permissions_group_id_dataset_id_key UNIQUE (group_id, dataset_id);


--
-- Name: group_dataset_permissions group_dataset_permissions_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.group_dataset_permissions
    ADD CONSTRAINT group_dataset_permissions_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: organizacoes organizacoes_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.organizacoes
    ADD CONSTRAINT organizacoes_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: user_dataset_permissions user_dataset_permissions_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.user_dataset_permissions
    ADD CONSTRAINT user_dataset_permissions_pkey PRIMARY KEY (id);


--
-- Name: user_dataset_permissions user_dataset_permissions_user_id_dataset_id_key; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.user_dataset_permissions
    ADD CONSTRAINT user_dataset_permissions_user_id_dataset_id_key UNIQUE (user_id, dataset_id);


--
-- Name: user_groups user_groups_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.user_groups
    ADD CONSTRAINT user_groups_pkey PRIMARY KEY (user_id, group_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: bronze_column_mappings bronze_column_mappings_ingestion_group_id_external_column_i_key; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_column_mappings
    ADD CONSTRAINT bronze_column_mappings_ingestion_group_id_external_column_i_key UNIQUE (ingestion_group_id, external_column_id);


--
-- Name: bronze_column_mappings bronze_column_mappings_pkey; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_column_mappings
    ADD CONSTRAINT bronze_column_mappings_pkey PRIMARY KEY (id);


--
-- Name: bronze_executions bronze_executions_pkey; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_executions
    ADD CONSTRAINT bronze_executions_pkey PRIMARY KEY (id);


--
-- Name: bronze_persistent_configs bronze_persistent_configs_name_key; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_persistent_configs
    ADD CONSTRAINT bronze_persistent_configs_name_key UNIQUE (name);


--
-- Name: bronze_persistent_configs bronze_persistent_configs_pkey; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_persistent_configs
    ADD CONSTRAINT bronze_persistent_configs_pkey PRIMARY KEY (id);


--
-- Name: bronze_virtualized_configs bronze_virtualized_configs_name_key; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_virtualized_configs
    ADD CONSTRAINT bronze_virtualized_configs_name_key UNIQUE (name);


--
-- Name: bronze_virtualized_configs bronze_virtualized_configs_pkey; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_virtualized_configs
    ADD CONSTRAINT bronze_virtualized_configs_pkey PRIMARY KEY (id);


--
-- Name: dataset_bronze_configs dataset_bronze_configs_dataset_id_key; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.dataset_bronze_configs
    ADD CONSTRAINT dataset_bronze_configs_dataset_id_key UNIQUE (dataset_id);


--
-- Name: dataset_bronze_configs dataset_bronze_configs_pkey; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.dataset_bronze_configs
    ADD CONSTRAINT dataset_bronze_configs_pkey PRIMARY KEY (id);


--
-- Name: dataset_ingestion_groups dataset_ingestion_groups_pkey; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.dataset_ingestion_groups
    ADD CONSTRAINT dataset_ingestion_groups_pkey PRIMARY KEY (id);


--
-- Name: ingestion_group_tables ingestion_group_tables_ingestion_group_id_table_id_key; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.ingestion_group_tables
    ADD CONSTRAINT ingestion_group_tables_ingestion_group_id_table_id_key UNIQUE (ingestion_group_id, table_id);


--
-- Name: ingestion_group_tables ingestion_group_tables_pkey; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.ingestion_group_tables
    ADD CONSTRAINT ingestion_group_tables_pkey PRIMARY KEY (id);


--
-- Name: inter_source_links inter_source_links_bronze_config_id_left_group_id_right_gro_key; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.inter_source_links
    ADD CONSTRAINT inter_source_links_bronze_config_id_left_group_id_right_gro_key UNIQUE (bronze_config_id, left_group_id, right_group_id);


--
-- Name: inter_source_links inter_source_links_pkey; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.inter_source_links
    ADD CONSTRAINT inter_source_links_pkey PRIMARY KEY (id);


--
-- Name: silver_executions silver_executions_pkey; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_executions
    ADD CONSTRAINT silver_executions_pkey PRIMARY KEY (id);


--
-- Name: silver_normalization_rules silver_normalization_rules_name_key; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_normalization_rules
    ADD CONSTRAINT silver_normalization_rules_name_key UNIQUE (name);


--
-- Name: silver_normalization_rules silver_normalization_rules_pkey; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_normalization_rules
    ADD CONSTRAINT silver_normalization_rules_pkey PRIMARY KEY (id);


--
-- Name: silver_persistent_configs silver_persistent_configs_name_key; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_persistent_configs
    ADD CONSTRAINT silver_persistent_configs_name_key UNIQUE (name);


--
-- Name: silver_persistent_configs silver_persistent_configs_pkey; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_persistent_configs
    ADD CONSTRAINT silver_persistent_configs_pkey PRIMARY KEY (id);


--
-- Name: silver_virtualized_configs silver_virtualized_configs_name_key; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_virtualized_configs
    ADD CONSTRAINT silver_virtualized_configs_name_key UNIQUE (name);


--
-- Name: silver_virtualized_configs silver_virtualized_configs_pkey; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_virtualized_configs
    ADD CONSTRAINT silver_virtualized_configs_pkey PRIMARY KEY (id);


--
-- Name: source_relationships source_relationships_left_column_id_right_column_id_key; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.source_relationships
    ADD CONSTRAINT source_relationships_left_column_id_right_column_id_key UNIQUE (left_column_id, right_column_id);


--
-- Name: source_relationships source_relationships_pkey; Type: CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.source_relationships
    ADD CONSTRAINT source_relationships_pkey PRIMARY KEY (id);


--
-- Name: recipient_access_logs recipient_access_logs_pkey; Type: CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.recipient_access_logs
    ADD CONSTRAINT recipient_access_logs_pkey PRIMARY KEY (id);


--
-- Name: recipient_shares recipient_shares_pkey; Type: CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.recipient_shares
    ADD CONSTRAINT recipient_shares_pkey PRIMARY KEY (recipient_id, share_id);


--
-- Name: recipients recipients_identifier_key; Type: CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.recipients
    ADD CONSTRAINT recipients_identifier_key UNIQUE (identifier);


--
-- Name: recipients recipients_pkey; Type: CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.recipients
    ADD CONSTRAINT recipients_pkey PRIMARY KEY (id);


--
-- Name: share_schemas share_schemas_pkey; Type: CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_schemas
    ADD CONSTRAINT share_schemas_pkey PRIMARY KEY (id);


--
-- Name: share_schemas share_schemas_share_id_name_key; Type: CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_schemas
    ADD CONSTRAINT share_schemas_share_id_name_key UNIQUE (share_id, name);


--
-- Name: share_table_files share_table_files_pkey; Type: CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_table_files
    ADD CONSTRAINT share_table_files_pkey PRIMARY KEY (id);


--
-- Name: share_table_files share_table_files_table_id_file_path_key; Type: CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_table_files
    ADD CONSTRAINT share_table_files_table_id_file_path_key UNIQUE (table_id, file_path);


--
-- Name: share_table_versions share_table_versions_pkey; Type: CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_table_versions
    ADD CONSTRAINT share_table_versions_pkey PRIMARY KEY (id);


--
-- Name: share_table_versions share_table_versions_table_id_version_key; Type: CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_table_versions
    ADD CONSTRAINT share_table_versions_table_id_version_key UNIQUE (table_id, version);


--
-- Name: share_tables share_tables_pkey; Type: CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_tables
    ADD CONSTRAINT share_tables_pkey PRIMARY KEY (id);


--
-- Name: share_tables share_tables_schema_id_name_key; Type: CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_tables
    ADD CONSTRAINT share_tables_schema_id_name_key UNIQUE (schema_id, name);


--
-- Name: shares shares_name_key; Type: CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.shares
    ADD CONSTRAINT shares_name_key UNIQUE (name);


--
-- Name: shares shares_pkey; Type: CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.shares
    ADD CONSTRAINT shares_pkey PRIMARY KEY (id);


--
-- Name: column_groups column_groups_pkey; Type: CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.column_groups
    ADD CONSTRAINT column_groups_pkey PRIMARY KEY (id);


--
-- Name: column_mappings column_mappings_group_id_column_id_key; Type: CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.column_mappings
    ADD CONSTRAINT column_mappings_group_id_column_id_key UNIQUE (group_id, column_id);


--
-- Name: column_mappings column_mappings_pkey; Type: CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.column_mappings
    ADD CONSTRAINT column_mappings_pkey PRIMARY KEY (id);


--
-- Name: data_dictionary data_dictionary_name_key; Type: CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.data_dictionary
    ADD CONSTRAINT data_dictionary_name_key UNIQUE (name);


--
-- Name: data_dictionary data_dictionary_pkey; Type: CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.data_dictionary
    ADD CONSTRAINT data_dictionary_pkey PRIMARY KEY (id);


--
-- Name: semantic_domains semantic_domains_name_key; Type: CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.semantic_domains
    ADD CONSTRAINT semantic_domains_name_key UNIQUE (name);


--
-- Name: semantic_domains semantic_domains_pkey; Type: CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.semantic_domains
    ADD CONSTRAINT semantic_domains_pkey PRIMARY KEY (id);


--
-- Name: value_mappings value_mappings_group_id_source_column_id_source_value_key; Type: CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.value_mappings
    ADD CONSTRAINT value_mappings_group_id_source_column_id_source_value_key UNIQUE (group_id, source_column_id, source_value);


--
-- Name: value_mappings value_mappings_pkey; Type: CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.value_mappings
    ADD CONSTRAINT value_mappings_pkey PRIMARY KEY (id);


--
-- Name: column_tags column_tags_column_id_tag_name_tag_type_key; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.column_tags
    ADD CONSTRAINT column_tags_column_id_tag_name_tag_type_key UNIQUE (column_id, tag_name, tag_type);


--
-- Name: column_tags column_tags_pkey; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.column_tags
    ADD CONSTRAINT column_tags_pkey PRIMARY KEY (id);


--
-- Name: external_catalogs external_catalogs_pkey; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_catalogs
    ADD CONSTRAINT external_catalogs_pkey PRIMARY KEY (id);


--
-- Name: external_columns external_columns_pkey; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_columns
    ADD CONSTRAINT external_columns_pkey PRIMARY KEY (id);


--
-- Name: external_columns external_columns_table_id_column_name_key; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_columns
    ADD CONSTRAINT external_columns_table_id_column_name_key UNIQUE (table_id, column_name);


--
-- Name: external_schemas external_schemas_connection_id_schema_name_key; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_schemas
    ADD CONSTRAINT external_schemas_connection_id_schema_name_key UNIQUE (connection_id, schema_name);


--
-- Name: external_schemas external_schemas_pkey; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_schemas
    ADD CONSTRAINT external_schemas_pkey PRIMARY KEY (id);


--
-- Name: external_tables external_tables_pkey; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_tables
    ADD CONSTRAINT external_tables_pkey PRIMARY KEY (id);


--
-- Name: external_tables external_tables_schema_id_table_name_key; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_tables
    ADD CONSTRAINT external_tables_schema_id_table_name_key UNIQUE (schema_id, table_name);


--
-- Name: federation_connections federation_connections_pkey; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.federation_connections
    ADD CONSTRAINT federation_connections_pkey PRIMARY KEY (id);


--
-- Name: federation_tables federation_tables_pkey; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.federation_tables
    ADD CONSTRAINT federation_tables_pkey PRIMARY KEY (id);


--
-- Name: federations federations_pkey; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.federations
    ADD CONSTRAINT federations_pkey PRIMARY KEY (id);


--
-- Name: relationship_suggestions relationship_suggestions_pkey; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.relationship_suggestions
    ADD CONSTRAINT relationship_suggestions_pkey PRIMARY KEY (id);


--
-- Name: semantic_column_links semantic_column_links_pkey; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.semantic_column_links
    ADD CONSTRAINT semantic_column_links_pkey PRIMARY KEY (id);


--
-- Name: table_relationships table_relationships_pkey; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.table_relationships
    ADD CONSTRAINT table_relationships_pkey PRIMARY KEY (id);


--
-- Name: federation_connections uq_federation_connection; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.federation_connections
    ADD CONSTRAINT uq_federation_connection UNIQUE (federation_id, connection_id);


--
-- Name: federation_tables uq_federation_table; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.federation_tables
    ADD CONSTRAINT uq_federation_table UNIQUE (federation_id, table_id);


--
-- Name: relationship_suggestions uq_relationship_suggestion; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.relationship_suggestions
    ADD CONSTRAINT uq_relationship_suggestion UNIQUE (left_column_id, right_column_id);


--
-- Name: semantic_column_links uq_semantic_link; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.semantic_column_links
    ADD CONSTRAINT uq_semantic_link UNIQUE (column_id, linked_column_id);


--
-- Name: table_relationships uq_table_relationship; Type: CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.table_relationships
    ADD CONSTRAINT uq_table_relationship UNIQUE (left_column_id, right_column_id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: dataset_storage dataset_storage_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.dataset_storage
    ADD CONSTRAINT dataset_storage_pkey PRIMARY KEY (id);


--
-- Name: dataset_jobs dataset_jobs_pkey; Type: CONSTRAINT; Schema: workflow; Owner: -
--

ALTER TABLE ONLY workflow.dataset_jobs
    ADD CONSTRAINT dataset_jobs_pkey PRIMARY KEY (id);


--
-- Name: metadata_sync_jobs metadata_sync_jobs_pkey; Type: CONSTRAINT; Schema: workflow; Owner: -
--

ALTER TABLE ONLY workflow.metadata_sync_jobs
    ADD CONSTRAINT metadata_sync_jobs_pkey PRIMARY KEY (id);


--
-- Name: sync_execution_history sync_execution_history_pkey; Type: CONSTRAINT; Schema: workflow; Owner: -
--

ALTER TABLE ONLY workflow.sync_execution_history
    ADD CONSTRAINT sync_execution_history_pkey PRIMARY KEY (id);


--
-- Name: ix_core_data_connections_status; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_core_data_connections_status ON core.data_connections USING btree (status);


--
-- Name: ix_core_data_connections_sync_status; Type: INDEX; Schema: core; Owner: -
--

CREATE INDEX ix_core_data_connections_sync_status ON core.data_connections USING btree (sync_status);


--
-- Name: ix_core_roles_name; Type: INDEX; Schema: core; Owner: -
--

CREATE UNIQUE INDEX ix_core_roles_name ON core.roles USING btree (name);


--
-- Name: ix_core_users_cpf; Type: INDEX; Schema: core; Owner: -
--

CREATE UNIQUE INDEX ix_core_users_cpf ON core.users USING btree (cpf);


--
-- Name: ix_core_users_email; Type: INDEX; Schema: core; Owner: -
--

CREATE UNIQUE INDEX ix_core_users_email ON core.users USING btree (email);


--
-- Name: ix_bronze_exec_config_finished; Type: INDEX; Schema: datasets; Owner: -
--

CREATE INDEX ix_bronze_exec_config_finished ON datasets.bronze_executions USING btree (config_id, finished_at);


--
-- Name: ix_bronze_exec_config_status; Type: INDEX; Schema: datasets; Owner: -
--

CREATE INDEX ix_bronze_exec_config_status ON datasets.bronze_executions USING btree (config_id, status);


--
-- Name: ix_silver_exec_config_finished; Type: INDEX; Schema: datasets; Owner: -
--

CREATE INDEX ix_silver_exec_config_finished ON datasets.silver_executions USING btree (config_id, finished_at);


--
-- Name: ix_silver_exec_config_status; Type: INDEX; Schema: datasets; Owner: -
--

CREATE INDEX ix_silver_exec_config_status ON datasets.silver_executions USING btree (config_id, status);


--
-- Name: ix_ext_catalogs_connection_id; Type: INDEX; Schema: metadata; Owner: -
--

CREATE INDEX ix_ext_catalogs_connection_id ON metadata.external_catalogs USING btree (connection_id);


--
-- Name: ix_ext_columns_table_id; Type: INDEX; Schema: metadata; Owner: -
--

CREATE INDEX ix_ext_columns_table_id ON metadata.external_columns USING btree (table_id);


--
-- Name: ix_ext_schemas_connection_id; Type: INDEX; Schema: metadata; Owner: -
--

CREATE INDEX ix_ext_schemas_connection_id ON metadata.external_schemas USING btree (connection_id);


--
-- Name: ix_ext_tables_connection_id; Type: INDEX; Schema: metadata; Owner: -
--

CREATE INDEX ix_ext_tables_connection_id ON metadata.external_tables USING btree (connection_id);


--
-- Name: data_connections data_connections_connection_type_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.data_connections
    ADD CONSTRAINT data_connections_connection_type_id_fkey FOREIGN KEY (connection_type_id) REFERENCES core.connection_types(id);


--
-- Name: data_connections data_connections_organization_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.data_connections
    ADD CONSTRAINT data_connections_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES core.organizacoes(id);


--
-- Name: dataset_column_sources dataset_column_sources_dataset_column_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_column_sources
    ADD CONSTRAINT dataset_column_sources_dataset_column_id_fkey FOREIGN KEY (dataset_column_id) REFERENCES core.dataset_columns(id) ON DELETE CASCADE;


--
-- Name: dataset_column_sources dataset_column_sources_source_column_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_column_sources
    ADD CONSTRAINT dataset_column_sources_source_column_id_fkey FOREIGN KEY (source_column_id) REFERENCES metadata.external_columns(id) ON DELETE CASCADE;


--
-- Name: dataset_columns dataset_columns_dataset_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_columns
    ADD CONSTRAINT dataset_columns_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES core.datasets(id) ON DELETE CASCADE;


--
-- Name: dataset_sources dataset_sources_dataset_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_sources
    ADD CONSTRAINT dataset_sources_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES core.datasets(id) ON DELETE CASCADE;


--
-- Name: dataset_sources dataset_sources_table_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_sources
    ADD CONSTRAINT dataset_sources_table_id_fkey FOREIGN KEY (table_id) REFERENCES metadata.external_tables(id) ON DELETE CASCADE;


--
-- Name: dataset_versions dataset_versions_dataset_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_versions
    ADD CONSTRAINT dataset_versions_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES core.datasets(id) ON DELETE CASCADE;


--
-- Name: dataset_versions dataset_versions_job_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_versions
    ADD CONSTRAINT dataset_versions_job_id_fkey FOREIGN KEY (job_id) REFERENCES workflow.dataset_jobs(id);


--
-- Name: dataset_versions dataset_versions_previous_version_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.dataset_versions
    ADD CONSTRAINT dataset_versions_previous_version_id_fkey FOREIGN KEY (previous_version_id) REFERENCES core.dataset_versions(id);


--
-- Name: datasets datasets_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.datasets
    ADD CONSTRAINT datasets_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: datasets datasets_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.datasets
    ADD CONSTRAINT datasets_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: group_dataset_permissions group_dataset_permissions_dataset_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.group_dataset_permissions
    ADD CONSTRAINT group_dataset_permissions_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES core.datasets(id) ON DELETE CASCADE;


--
-- Name: group_dataset_permissions group_dataset_permissions_group_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.group_dataset_permissions
    ADD CONSTRAINT group_dataset_permissions_group_id_fkey FOREIGN KEY (group_id) REFERENCES core.groups(id) ON DELETE CASCADE;


--
-- Name: groups groups_organization_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.groups
    ADD CONSTRAINT groups_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES core.organizacoes(id);


--
-- Name: user_dataset_permissions user_dataset_permissions_dataset_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.user_dataset_permissions
    ADD CONSTRAINT user_dataset_permissions_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES core.datasets(id) ON DELETE CASCADE;


--
-- Name: user_dataset_permissions user_dataset_permissions_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.user_dataset_permissions
    ADD CONSTRAINT user_dataset_permissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON DELETE CASCADE;


--
-- Name: user_groups user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.user_groups
    ADD CONSTRAINT user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES core.groups(id) ON DELETE CASCADE;


--
-- Name: user_groups user_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.user_groups
    ADD CONSTRAINT user_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES core.roles(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES core.users(id);


--
-- Name: users users_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: users users_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: users users_organization_id_fkey; Type: FK CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.users
    ADD CONSTRAINT users_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES core.organizacoes(id);


--
-- Name: bronze_column_mappings bronze_column_mappings_external_column_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_column_mappings
    ADD CONSTRAINT bronze_column_mappings_external_column_id_fkey FOREIGN KEY (external_column_id) REFERENCES metadata.external_columns(id) ON DELETE CASCADE;


--
-- Name: bronze_column_mappings bronze_column_mappings_external_table_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_column_mappings
    ADD CONSTRAINT bronze_column_mappings_external_table_id_fkey FOREIGN KEY (external_table_id) REFERENCES metadata.external_tables(id) ON DELETE CASCADE;


--
-- Name: bronze_column_mappings bronze_column_mappings_ingestion_group_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_column_mappings
    ADD CONSTRAINT bronze_column_mappings_ingestion_group_id_fkey FOREIGN KEY (ingestion_group_id) REFERENCES datasets.dataset_ingestion_groups(id) ON DELETE CASCADE;


--
-- Name: bronze_executions bronze_executions_config_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_executions
    ADD CONSTRAINT bronze_executions_config_id_fkey FOREIGN KEY (config_id) REFERENCES datasets.bronze_persistent_configs(id) ON DELETE CASCADE;


--
-- Name: bronze_executions bronze_executions_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_executions
    ADD CONSTRAINT bronze_executions_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: bronze_executions bronze_executions_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_executions
    ADD CONSTRAINT bronze_executions_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: bronze_persistent_configs bronze_persistent_configs_dataset_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_persistent_configs
    ADD CONSTRAINT bronze_persistent_configs_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES core.datasets(id) ON DELETE SET NULL;


--
-- Name: bronze_persistent_configs bronze_persistent_configs_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_persistent_configs
    ADD CONSTRAINT bronze_persistent_configs_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: bronze_persistent_configs bronze_persistent_configs_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_persistent_configs
    ADD CONSTRAINT bronze_persistent_configs_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: bronze_virtualized_configs bronze_virtualized_configs_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_virtualized_configs
    ADD CONSTRAINT bronze_virtualized_configs_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: bronze_virtualized_configs bronze_virtualized_configs_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.bronze_virtualized_configs
    ADD CONSTRAINT bronze_virtualized_configs_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: dataset_bronze_configs dataset_bronze_configs_dataset_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.dataset_bronze_configs
    ADD CONSTRAINT dataset_bronze_configs_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES core.datasets(id) ON DELETE CASCADE;


--
-- Name: dataset_bronze_configs dataset_bronze_configs_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.dataset_bronze_configs
    ADD CONSTRAINT dataset_bronze_configs_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: dataset_bronze_configs dataset_bronze_configs_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.dataset_bronze_configs
    ADD CONSTRAINT dataset_bronze_configs_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: dataset_ingestion_groups dataset_ingestion_groups_bronze_config_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.dataset_ingestion_groups
    ADD CONSTRAINT dataset_ingestion_groups_bronze_config_id_fkey FOREIGN KEY (bronze_config_id) REFERENCES datasets.dataset_bronze_configs(id) ON DELETE CASCADE;


--
-- Name: dataset_ingestion_groups dataset_ingestion_groups_connection_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.dataset_ingestion_groups
    ADD CONSTRAINT dataset_ingestion_groups_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES core.data_connections(id) ON DELETE CASCADE;


--
-- Name: dataset_ingestion_groups dataset_ingestion_groups_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.dataset_ingestion_groups
    ADD CONSTRAINT dataset_ingestion_groups_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: dataset_ingestion_groups dataset_ingestion_groups_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.dataset_ingestion_groups
    ADD CONSTRAINT dataset_ingestion_groups_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: ingestion_group_tables ingestion_group_tables_ingestion_group_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.ingestion_group_tables
    ADD CONSTRAINT ingestion_group_tables_ingestion_group_id_fkey FOREIGN KEY (ingestion_group_id) REFERENCES datasets.dataset_ingestion_groups(id) ON DELETE CASCADE;


--
-- Name: ingestion_group_tables ingestion_group_tables_join_to_table_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.ingestion_group_tables
    ADD CONSTRAINT ingestion_group_tables_join_to_table_id_fkey FOREIGN KEY (join_to_table_id) REFERENCES metadata.external_tables(id);


--
-- Name: ingestion_group_tables ingestion_group_tables_table_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.ingestion_group_tables
    ADD CONSTRAINT ingestion_group_tables_table_id_fkey FOREIGN KEY (table_id) REFERENCES metadata.external_tables(id) ON DELETE CASCADE;


--
-- Name: inter_source_links inter_source_links_bronze_config_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.inter_source_links
    ADD CONSTRAINT inter_source_links_bronze_config_id_fkey FOREIGN KEY (bronze_config_id) REFERENCES datasets.dataset_bronze_configs(id) ON DELETE CASCADE;


--
-- Name: inter_source_links inter_source_links_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.inter_source_links
    ADD CONSTRAINT inter_source_links_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: inter_source_links inter_source_links_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.inter_source_links
    ADD CONSTRAINT inter_source_links_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: inter_source_links inter_source_links_left_group_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.inter_source_links
    ADD CONSTRAINT inter_source_links_left_group_id_fkey FOREIGN KEY (left_group_id) REFERENCES datasets.dataset_ingestion_groups(id) ON DELETE CASCADE;


--
-- Name: inter_source_links inter_source_links_right_group_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.inter_source_links
    ADD CONSTRAINT inter_source_links_right_group_id_fkey FOREIGN KEY (right_group_id) REFERENCES datasets.dataset_ingestion_groups(id) ON DELETE CASCADE;


--
-- Name: silver_executions silver_executions_config_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_executions
    ADD CONSTRAINT silver_executions_config_id_fkey FOREIGN KEY (config_id) REFERENCES datasets.silver_persistent_configs(id) ON DELETE CASCADE;


--
-- Name: silver_executions silver_executions_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_executions
    ADD CONSTRAINT silver_executions_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: silver_executions silver_executions_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_executions
    ADD CONSTRAINT silver_executions_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: silver_normalization_rules silver_normalization_rules_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_normalization_rules
    ADD CONSTRAINT silver_normalization_rules_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: silver_normalization_rules silver_normalization_rules_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_normalization_rules
    ADD CONSTRAINT silver_normalization_rules_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: silver_persistent_configs silver_persistent_configs_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_persistent_configs
    ADD CONSTRAINT silver_persistent_configs_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: silver_persistent_configs silver_persistent_configs_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_persistent_configs
    ADD CONSTRAINT silver_persistent_configs_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: silver_persistent_configs silver_persistent_configs_source_bronze_config_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_persistent_configs
    ADD CONSTRAINT silver_persistent_configs_source_bronze_config_id_fkey FOREIGN KEY (source_bronze_config_id) REFERENCES datasets.bronze_persistent_configs(id) ON DELETE CASCADE;


--
-- Name: silver_persistent_configs silver_persistent_configs_source_bronze_dataset_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_persistent_configs
    ADD CONSTRAINT silver_persistent_configs_source_bronze_dataset_id_fkey FOREIGN KEY (source_bronze_dataset_id) REFERENCES core.datasets(id) ON DELETE CASCADE;


--
-- Name: silver_virtualized_configs silver_virtualized_configs_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_virtualized_configs
    ADD CONSTRAINT silver_virtualized_configs_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: silver_virtualized_configs silver_virtualized_configs_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.silver_virtualized_configs
    ADD CONSTRAINT silver_virtualized_configs_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: source_relationships source_relationships_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.source_relationships
    ADD CONSTRAINT source_relationships_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: source_relationships source_relationships_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.source_relationships
    ADD CONSTRAINT source_relationships_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: source_relationships source_relationships_left_column_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.source_relationships
    ADD CONSTRAINT source_relationships_left_column_id_fkey FOREIGN KEY (left_column_id) REFERENCES metadata.external_columns(id) ON DELETE CASCADE;


--
-- Name: source_relationships source_relationships_left_table_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.source_relationships
    ADD CONSTRAINT source_relationships_left_table_id_fkey FOREIGN KEY (left_table_id) REFERENCES metadata.external_tables(id) ON DELETE CASCADE;


--
-- Name: source_relationships source_relationships_right_column_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.source_relationships
    ADD CONSTRAINT source_relationships_right_column_id_fkey FOREIGN KEY (right_column_id) REFERENCES metadata.external_columns(id) ON DELETE CASCADE;


--
-- Name: source_relationships source_relationships_right_table_id_fkey; Type: FK CONSTRAINT; Schema: datasets; Owner: -
--

ALTER TABLE ONLY datasets.source_relationships
    ADD CONSTRAINT source_relationships_right_table_id_fkey FOREIGN KEY (right_table_id) REFERENCES metadata.external_tables(id) ON DELETE CASCADE;


--
-- Name: recipient_access_logs recipient_access_logs_recipient_id_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.recipient_access_logs
    ADD CONSTRAINT recipient_access_logs_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES delta_sharing.recipients(id);


--
-- Name: recipient_access_logs recipient_access_logs_schema_id_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.recipient_access_logs
    ADD CONSTRAINT recipient_access_logs_schema_id_fkey FOREIGN KEY (schema_id) REFERENCES delta_sharing.share_schemas(id) ON DELETE SET NULL;


--
-- Name: recipient_access_logs recipient_access_logs_share_id_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.recipient_access_logs
    ADD CONSTRAINT recipient_access_logs_share_id_fkey FOREIGN KEY (share_id) REFERENCES delta_sharing.shares(id) ON DELETE SET NULL;


--
-- Name: recipient_access_logs recipient_access_logs_table_id_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.recipient_access_logs
    ADD CONSTRAINT recipient_access_logs_table_id_fkey FOREIGN KEY (table_id) REFERENCES delta_sharing.share_tables(id) ON DELETE SET NULL;


--
-- Name: recipient_shares recipient_shares_recipient_id_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.recipient_shares
    ADD CONSTRAINT recipient_shares_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES delta_sharing.recipients(id);


--
-- Name: recipient_shares recipient_shares_share_id_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.recipient_shares
    ADD CONSTRAINT recipient_shares_share_id_fkey FOREIGN KEY (share_id) REFERENCES delta_sharing.shares(id);


--
-- Name: recipients recipients_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.recipients
    ADD CONSTRAINT recipients_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: recipients recipients_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.recipients
    ADD CONSTRAINT recipients_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: share_schemas share_schemas_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_schemas
    ADD CONSTRAINT share_schemas_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: share_schemas share_schemas_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_schemas
    ADD CONSTRAINT share_schemas_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: share_schemas share_schemas_share_id_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_schemas
    ADD CONSTRAINT share_schemas_share_id_fkey FOREIGN KEY (share_id) REFERENCES delta_sharing.shares(id) ON DELETE CASCADE;


--
-- Name: share_table_files share_table_files_table_id_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_table_files
    ADD CONSTRAINT share_table_files_table_id_fkey FOREIGN KEY (table_id) REFERENCES delta_sharing.share_tables(id) ON DELETE CASCADE;


--
-- Name: share_table_versions share_table_versions_table_id_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_table_versions
    ADD CONSTRAINT share_table_versions_table_id_fkey FOREIGN KEY (table_id) REFERENCES delta_sharing.share_tables(id) ON DELETE CASCADE;


--
-- Name: share_tables share_tables_dataset_id_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_tables
    ADD CONSTRAINT share_tables_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES core.datasets(id);


--
-- Name: share_tables share_tables_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_tables
    ADD CONSTRAINT share_tables_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: share_tables share_tables_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_tables
    ADD CONSTRAINT share_tables_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: share_tables share_tables_schema_id_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.share_tables
    ADD CONSTRAINT share_tables_schema_id_fkey FOREIGN KEY (schema_id) REFERENCES delta_sharing.share_schemas(id) ON DELETE CASCADE;


--
-- Name: shares shares_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.shares
    ADD CONSTRAINT shares_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: shares shares_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.shares
    ADD CONSTRAINT shares_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: shares shares_organization_id_fkey; Type: FK CONSTRAINT; Schema: delta_sharing; Owner: -
--

ALTER TABLE ONLY delta_sharing.shares
    ADD CONSTRAINT shares_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES core.organizacoes(id);


--
-- Name: column_groups column_groups_data_dictionary_term_id_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.column_groups
    ADD CONSTRAINT column_groups_data_dictionary_term_id_fkey FOREIGN KEY (data_dictionary_term_id) REFERENCES equivalence.data_dictionary(id);


--
-- Name: column_groups column_groups_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.column_groups
    ADD CONSTRAINT column_groups_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: column_groups column_groups_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.column_groups
    ADD CONSTRAINT column_groups_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: column_groups column_groups_semantic_domain_id_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.column_groups
    ADD CONSTRAINT column_groups_semantic_domain_id_fkey FOREIGN KEY (semantic_domain_id) REFERENCES equivalence.semantic_domains(id);


--
-- Name: column_mappings column_mappings_column_id_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.column_mappings
    ADD CONSTRAINT column_mappings_column_id_fkey FOREIGN KEY (column_id) REFERENCES metadata.external_columns(id) ON DELETE CASCADE;


--
-- Name: column_mappings column_mappings_group_id_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.column_mappings
    ADD CONSTRAINT column_mappings_group_id_fkey FOREIGN KEY (group_id) REFERENCES equivalence.column_groups(id) ON DELETE CASCADE;


--
-- Name: column_mappings column_mappings_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.column_mappings
    ADD CONSTRAINT column_mappings_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: column_mappings column_mappings_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.column_mappings
    ADD CONSTRAINT column_mappings_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: data_dictionary data_dictionary_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.data_dictionary
    ADD CONSTRAINT data_dictionary_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: data_dictionary data_dictionary_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.data_dictionary
    ADD CONSTRAINT data_dictionary_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: data_dictionary data_dictionary_semantic_domain_id_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.data_dictionary
    ADD CONSTRAINT data_dictionary_semantic_domain_id_fkey FOREIGN KEY (semantic_domain_id) REFERENCES equivalence.semantic_domains(id);


--
-- Name: semantic_domains semantic_domains_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.semantic_domains
    ADD CONSTRAINT semantic_domains_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: semantic_domains semantic_domains_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.semantic_domains
    ADD CONSTRAINT semantic_domains_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: semantic_domains semantic_domains_parent_domain_id_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.semantic_domains
    ADD CONSTRAINT semantic_domains_parent_domain_id_fkey FOREIGN KEY (parent_domain_id) REFERENCES equivalence.semantic_domains(id);


--
-- Name: value_mappings value_mappings_group_id_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.value_mappings
    ADD CONSTRAINT value_mappings_group_id_fkey FOREIGN KEY (group_id) REFERENCES equivalence.column_groups(id) ON DELETE CASCADE;


--
-- Name: value_mappings value_mappings_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.value_mappings
    ADD CONSTRAINT value_mappings_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: value_mappings value_mappings_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.value_mappings
    ADD CONSTRAINT value_mappings_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: value_mappings value_mappings_source_column_id_fkey; Type: FK CONSTRAINT; Schema: equivalence; Owner: -
--

ALTER TABLE ONLY equivalence.value_mappings
    ADD CONSTRAINT value_mappings_source_column_id_fkey FOREIGN KEY (source_column_id) REFERENCES metadata.external_columns(id) ON DELETE CASCADE;


--
-- Name: column_tags column_tags_column_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.column_tags
    ADD CONSTRAINT column_tags_column_id_fkey FOREIGN KEY (column_id) REFERENCES metadata.external_columns(id) ON DELETE CASCADE;


--
-- Name: column_tags column_tags_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.column_tags
    ADD CONSTRAINT column_tags_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: column_tags column_tags_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.column_tags
    ADD CONSTRAINT column_tags_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: external_catalogs external_catalogs_connection_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_catalogs
    ADD CONSTRAINT external_catalogs_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES core.data_connections(id) ON DELETE CASCADE;


--
-- Name: external_catalogs external_catalogs_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_catalogs
    ADD CONSTRAINT external_catalogs_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: external_catalogs external_catalogs_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_catalogs
    ADD CONSTRAINT external_catalogs_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: external_columns external_columns_fk_referenced_column_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_columns
    ADD CONSTRAINT external_columns_fk_referenced_column_id_fkey FOREIGN KEY (fk_referenced_column_id) REFERENCES metadata.external_columns(id);


--
-- Name: external_columns external_columns_fk_referenced_table_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_columns
    ADD CONSTRAINT external_columns_fk_referenced_table_id_fkey FOREIGN KEY (fk_referenced_table_id) REFERENCES metadata.external_tables(id);


--
-- Name: external_columns external_columns_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_columns
    ADD CONSTRAINT external_columns_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: external_columns external_columns_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_columns
    ADD CONSTRAINT external_columns_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: external_columns external_columns_image_connection_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_columns
    ADD CONSTRAINT external_columns_image_connection_id_fkey FOREIGN KEY (image_connection_id) REFERENCES core.data_connections(id);


--
-- Name: external_columns external_columns_table_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_columns
    ADD CONSTRAINT external_columns_table_id_fkey FOREIGN KEY (table_id) REFERENCES metadata.external_tables(id) ON DELETE CASCADE;


--
-- Name: external_schemas external_schemas_catalog_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_schemas
    ADD CONSTRAINT external_schemas_catalog_id_fkey FOREIGN KEY (catalog_id) REFERENCES metadata.external_catalogs(id) ON DELETE CASCADE;


--
-- Name: external_schemas external_schemas_connection_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_schemas
    ADD CONSTRAINT external_schemas_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES core.data_connections(id) ON DELETE CASCADE;


--
-- Name: external_schemas external_schemas_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_schemas
    ADD CONSTRAINT external_schemas_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: external_schemas external_schemas_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_schemas
    ADD CONSTRAINT external_schemas_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: external_tables external_tables_connection_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_tables
    ADD CONSTRAINT external_tables_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES core.data_connections(id) ON DELETE CASCADE;


--
-- Name: external_tables external_tables_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_tables
    ADD CONSTRAINT external_tables_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: external_tables external_tables_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_tables
    ADD CONSTRAINT external_tables_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: external_tables external_tables_schema_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.external_tables
    ADD CONSTRAINT external_tables_schema_id_fkey FOREIGN KEY (schema_id) REFERENCES metadata.external_schemas(id) ON DELETE CASCADE;


--
-- Name: federation_connections federation_connections_connection_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.federation_connections
    ADD CONSTRAINT federation_connections_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES core.data_connections(id) ON DELETE CASCADE;


--
-- Name: federation_connections federation_connections_federation_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.federation_connections
    ADD CONSTRAINT federation_connections_federation_id_fkey FOREIGN KEY (federation_id) REFERENCES metadata.federations(id) ON DELETE CASCADE;


--
-- Name: federation_tables federation_tables_federation_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.federation_tables
    ADD CONSTRAINT federation_tables_federation_id_fkey FOREIGN KEY (federation_id) REFERENCES metadata.federations(id) ON DELETE CASCADE;


--
-- Name: federation_tables federation_tables_table_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.federation_tables
    ADD CONSTRAINT federation_tables_table_id_fkey FOREIGN KEY (table_id) REFERENCES metadata.external_tables(id) ON DELETE CASCADE;


--
-- Name: federations federations_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.federations
    ADD CONSTRAINT federations_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: federations federations_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.federations
    ADD CONSTRAINT federations_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: relationship_suggestions relationship_suggestions_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.relationship_suggestions
    ADD CONSTRAINT relationship_suggestions_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: relationship_suggestions relationship_suggestions_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.relationship_suggestions
    ADD CONSTRAINT relationship_suggestions_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: relationship_suggestions relationship_suggestions_left_column_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.relationship_suggestions
    ADD CONSTRAINT relationship_suggestions_left_column_id_fkey FOREIGN KEY (left_column_id) REFERENCES metadata.external_columns(id) ON DELETE CASCADE;


--
-- Name: relationship_suggestions relationship_suggestions_left_table_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.relationship_suggestions
    ADD CONSTRAINT relationship_suggestions_left_table_id_fkey FOREIGN KEY (left_table_id) REFERENCES metadata.external_tables(id) ON DELETE CASCADE;


--
-- Name: relationship_suggestions relationship_suggestions_right_column_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.relationship_suggestions
    ADD CONSTRAINT relationship_suggestions_right_column_id_fkey FOREIGN KEY (right_column_id) REFERENCES metadata.external_columns(id) ON DELETE CASCADE;


--
-- Name: relationship_suggestions relationship_suggestions_right_table_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.relationship_suggestions
    ADD CONSTRAINT relationship_suggestions_right_table_id_fkey FOREIGN KEY (right_table_id) REFERENCES metadata.external_tables(id) ON DELETE CASCADE;


--
-- Name: semantic_column_links semantic_column_links_column_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.semantic_column_links
    ADD CONSTRAINT semantic_column_links_column_id_fkey FOREIGN KEY (column_id) REFERENCES metadata.external_columns(id) ON DELETE CASCADE;


--
-- Name: semantic_column_links semantic_column_links_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.semantic_column_links
    ADD CONSTRAINT semantic_column_links_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: semantic_column_links semantic_column_links_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.semantic_column_links
    ADD CONSTRAINT semantic_column_links_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: semantic_column_links semantic_column_links_linked_column_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.semantic_column_links
    ADD CONSTRAINT semantic_column_links_linked_column_id_fkey FOREIGN KEY (linked_column_id) REFERENCES metadata.external_columns(id) ON DELETE CASCADE;


--
-- Name: table_relationships table_relationships_id_usuario_atualizacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.table_relationships
    ADD CONSTRAINT table_relationships_id_usuario_atualizacao_fkey FOREIGN KEY (id_usuario_atualizacao) REFERENCES core.users(id);


--
-- Name: table_relationships table_relationships_id_usuario_criacao_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.table_relationships
    ADD CONSTRAINT table_relationships_id_usuario_criacao_fkey FOREIGN KEY (id_usuario_criacao) REFERENCES core.users(id);


--
-- Name: table_relationships table_relationships_left_column_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.table_relationships
    ADD CONSTRAINT table_relationships_left_column_id_fkey FOREIGN KEY (left_column_id) REFERENCES metadata.external_columns(id) ON DELETE CASCADE;


--
-- Name: table_relationships table_relationships_left_table_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.table_relationships
    ADD CONSTRAINT table_relationships_left_table_id_fkey FOREIGN KEY (left_table_id) REFERENCES metadata.external_tables(id) ON DELETE CASCADE;


--
-- Name: table_relationships table_relationships_right_column_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.table_relationships
    ADD CONSTRAINT table_relationships_right_column_id_fkey FOREIGN KEY (right_column_id) REFERENCES metadata.external_columns(id) ON DELETE CASCADE;


--
-- Name: table_relationships table_relationships_right_table_id_fkey; Type: FK CONSTRAINT; Schema: metadata; Owner: -
--

ALTER TABLE ONLY metadata.table_relationships
    ADD CONSTRAINT table_relationships_right_table_id_fkey FOREIGN KEY (right_table_id) REFERENCES metadata.external_tables(id) ON DELETE CASCADE;


--
-- Name: dataset_storage dataset_storage_dataset_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.dataset_storage
    ADD CONSTRAINT dataset_storage_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES core.datasets(id) ON DELETE CASCADE;


--
-- Name: dataset_jobs dataset_jobs_dataset_id_fkey; Type: FK CONSTRAINT; Schema: workflow; Owner: -
--

ALTER TABLE ONLY workflow.dataset_jobs
    ADD CONSTRAINT dataset_jobs_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES core.datasets(id) ON DELETE CASCADE;


--
-- Name: metadata_sync_jobs metadata_sync_jobs_connection_id_fkey; Type: FK CONSTRAINT; Schema: workflow; Owner: -
--

ALTER TABLE ONLY workflow.metadata_sync_jobs
    ADD CONSTRAINT metadata_sync_jobs_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES core.data_connections(id) ON DELETE CASCADE;


--
-- Name: sync_execution_history sync_execution_history_connection_id_fkey; Type: FK CONSTRAINT; Schema: workflow; Owner: -
--

ALTER TABLE ONLY workflow.sync_execution_history
    ADD CONSTRAINT sync_execution_history_connection_id_fkey FOREIGN KEY (connection_id) REFERENCES core.data_connections(id) ON DELETE CASCADE;


--
-- Name: sync_execution_history sync_execution_history_job_id_fkey; Type: FK CONSTRAINT; Schema: workflow; Owner: -
--

ALTER TABLE ONLY workflow.sync_execution_history
    ADD CONSTRAINT sync_execution_history_job_id_fkey FOREIGN KEY (job_id) REFERENCES workflow.metadata_sync_jobs(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict datafabric_seed_snapshot

